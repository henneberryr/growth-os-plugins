# Growth OS for Coaching & Consulting -- Quick Start

Guided setup that builds an AI marketing workspace for your coaching or consulting practice in one session.

## What It Does

The Quick Start collects your practice assets (website, LinkedIn, testimonials, presentations, lead magnets), then walks you through creating your core operational files: services document with engagements and pricing approach, client persona with pain/pleasure quotes, brand voice guide (with expertise signaling approach), personalized morning routine with LinkedIn engagement check and discovery call prep, and tailored client growth ideas. When it's done, Claude knows your practice, your clients, your voice, and your daily rhythm, and you have a prioritized list of ideas for growing your client base.

Built specifically for coaching and consulting: executive coaches, business coaches, life coaches, leadership coaches, management consultants, strategy consultants, and boutique consulting firms. Uses a 10-stage Coaching & Consulting Client Journey framework (not a generic marketing funnel) that maps to how coaching and consulting clients actually discover, evaluate, engage with, and refer practitioners.

## How to Use

1. Install the plugin in Claude Cowork
2. Say "quick start", "set up my workspace", or type `/quick-start`
3. Follow the guided interview. Claude will ask questions, crawl your website, process your uploads, and build each document with your input

The setup takes 30-60 minutes depending on how much context you provide. You can stop at any point and pick up later with "continue setup."

## Components

| Component | Type | Description |
|-----------|------|-------------|
| quick-start-coaching-consulting | Skill | 7-phase guided workspace builder with practice asset intake, document creation, and workflow setup |
| /quick-start | Command | Starts or resumes the Quick Start process |
| /upgrade | Command | Adds new features to an existing workspace without re-running setup |

## Skills Included

### Quick Start for Coaching & Consulting

The core skill that powers the entire guided setup. It has 7 steps (Getting to Know Your Practice, Mapping Your Services, Defining Your Ideal Client, Capturing Your Voice, Building Your Daily Gameplan, Wiring It All Together, Growth Ideas for Your Practice) plus optional Tier 2 enhancements (Practice Info with credentials and methodology, Brand Design with photography guidelines, Content Rules with FTC compliance).

**Trigger phrases:** "quick start", "run the quick start", "set up my workspace", "build my workspace", "get started", "continue setup", "good morning" (if Quick Start is incomplete)

## Coaching & Consulting-Specific Features

- **Client Journey framework** with 10 stages: Problem Aware, Solution Aware, Expert Search, Trust Building, Discovery Call, Proposal Review, Engagement Start, Active Engagement, Results and Completion, Referral and Renewal
- **6 practice patterns:** Solo Coach (Life/Wellness), Executive/Leadership Coach, Business/Growth Coach, Solo Consultant, Boutique Consulting Firm, Group Program/Mastermind Creator
- **Platform discovery:** LinkedIn, podcast appearances, speaking profiles, ICF directory, professional associations, Facebook groups, YouTube
- **Expertise signaling approach** in brand voice guides: how to balance authority with approachability and avoid guru energy
- **Morning routine with LinkedIn check:** Engagement monitoring, discovery call prep, and suggested daily actions
- **FTC compliance rules:** Testimonial accuracy, income claim disclosure, no outcome guarantees, credential verification, client confidentiality

## Example Practices

The plugin includes two complete example sets that Claude uses as quality benchmarks:

1. **Catalyst Coaching** -- Solo executive/leadership coaching practice in Austin, TX (service-based)
2. **Meridian Consulting** -- Boutique operational efficiency consulting firm in Charlotte, NC (consulting-firm-based)

## Requirements

- Claude Cowork desktop app
- A practice website or an aspirational practice website to model from
- Google Calendar MCP connector (optional, for calendar in morning routine)

## Examples

**Starting fresh:**
> User: "Let's set up my workspace."
> Claude: Asks your name and whether you have an established practice or are building one, then begins collecting assets.

**Resuming a previous session:**
> User: "Continue setup."
> Claude: Reads progress.md, finds where you left off, and picks up from the next incomplete step.

**After completion:**
> User: "Good morning."
> Claude: Runs your personalized morning routine with LinkedIn check, discovery call prep, tasks, and suggested actions.

**Getting growth ideas:**
> User: "Growth ideas" or "Show me the growth ideas."
> Claude: Displays your saved growth ideas organized by marketing objective (Client Acquisition, Lead Conversion, Revenue Growth, Retention and Referrals).

**Working on a task:**
> User: "/tasks"
> Claude: Shows your task list with copy-paste prompts. Pick a task, paste the prompt, and Claude executes it with full practice context.

**Adding enhancements after setup:**
> User: "Enhance my workspace."
> Claude: Walks you through optional additions: practice info (with credentials and methodology), brand design guide (with photography guidelines), and content rules (with FTC compliance).

## Troubleshooting

**"Quick start isn't picking up where I left off."**
Check that `progress.md` exists in your workspace root. If it was accidentally deleted, the plugin will start fresh. Your core documents (services, persona, voice) are still intact in the `core/` folder.

**"The morning routine doesn't include my calendar."**
The calendar section requires a Google Calendar MCP connector. If it's not connected, the routine skips that section and tells you. Reconnect the MCP tool and try again.

**"I want to redo a section of the setup."**
Open `progress.md` and uncheck the step you want to redo. The next time you say "continue setup," Claude will re-run that phase. Your existing files will be used as a starting draft.

**"The growth ideas feel too generic."**
Growth ideas are only as specific as the context you provided during setup. The more assets you shared (website, LinkedIn posts, testimonials, proposals), the more targeted the ideas. You can regenerate ideas anytime by saying "generate new growth ideas" after adding more context to your core documents.

**"I want to change my brand voice."**
Edit `core/brand-voice.md` directly, or say "let's update my voice guide" and Claude will walk you through it. Paste in a writing sample (LinkedIn post, email to a prospect, article draft) for the best results.

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0.0 | March 2026 | Initial coaching and consulting release. Forked from Growth OS Quick Start v2.0 with full customization: Coaching & Consulting Client Journey framework with 10 industry-specific stages, 6 practice type patterns, example practices (executive coach + boutique consulting firm), client persona with coaching/consulting-specific pain points, brand voice with expertise signaling approach, morning routine with LinkedIn engagement check and discovery call prep, and compliance rules for FTC, testimonials, credentials, and client confidentiality. |
