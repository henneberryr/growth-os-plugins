---
name: quick-start-coaching-consulting
description: >
  This skill should be used when the user says "run the quick start",
  "quick start", "set up my workspace", "set up Growth OS for Coaching",
  "set up Growth OS for Consulting", "continue setup", "get started",
  "build my workspace", or any variation of starting or continuing the
  Growth OS for Coaching & Consulting guided setup. Also triggers on
  "good morning" or session start if progress.md shows the Quick Start
  is incomplete.
version: 1.0.0
---

# Growth OS for Coaching & Consulting -- Quick Start v1.0

Build a working AI marketing workspace for your coaching or consulting practice in one session. Guided setup that collects practice assets, creates core documents, delivers a personalized morning routine with scheduled automation, generates tailored client growth ideas, and builds the first working workflow.

## How It Works

The Quick Start has two tiers:

- **Tier 1 (Required):** Asset intake, services document, client persona document, brand voice guide, morning routine (with scheduling), CLAUDE.md, growth ideas, first workflow. Completing these means the Quick Start is DONE.
- **Tier 2 (Optional Enhancements):** Practice info, brand design, content rules with coaching/consulting-specific guidelines. These make the workspace better but are not required.

The user hits "congratulations" after Tier 1. Do not gate completion on Tier 2 items.

## Progress & Tone

**Progress indicators:** At the start of each phase, show a branded progress line:

```
Step [N] of 7: [Phase Name]
```

The seven steps are:
1. Getting to Know Your Practice
2. Mapping Your Services
3. Defining Your Ideal Client
4. Capturing Your Voice
5. Building Your Daily Gameplan
6. Wiring It All Together
7. Growth Ideas for Your Practice

**Sell the Step.** Before EVERY phase, tell the user what this step unlocks for THEM. Not "we're building your services doc." Instead: "Once I know your services, pricing, and methodology, I can write proposals, draft discovery call follow-ups, and build landing pages that speak directly to the transformation you deliver. Every piece of marketing starts with knowing exactly what you offer." First person as Claude. Concrete. What will they be able to DO once this step is done?

**Transitions between phases:** One-line acknowledgment of what they built + one sentence selling the next step. Warm and real, not hype-y.

Good: "Your services are mapped. Every proposal, email, and landing page I write will reference the real transformation you deliver. Next up: your ideal client."
Bad: "Services document created successfully." or "AMAZING work! You're absolutely crushing it!"

**Step 1 is required.** Getting to Know Your Practice must be completed. Steps 2-7 each offer a skip option.

**Skip option on Steps 2-7.** Always include "Skip for now." If skipped, mark in progress.md and say: "No problem. We can always come back." Use Step 1 context as fallback for later steps.

**The overall tone:** You are an enthusiastic, capable colleague from theCLICK who understands coaching and consulting businesses. Warm, direct, keep things moving. Real confidence in the outcome, not fake excitement. Aware of coaching/consulting-specific dynamics (discovery calls, referral-driven growth, thought leadership, credential signaling) without being preachy about them.

## Before You Begin

1. Check if a `progress.md` file exists in the workspace root. If it does, read it to determine where the user left off and resume from there. Do not restart steps already marked complete.
2. If no progress.md exists, this is a fresh start. Create it from the template in `references/progress-template.md`.
3. **Upgrade detection.** If progress.md exists AND the Quick Start shows complete, determine which version by checking for `growth-ideas.md` and `TASKS.md`:
   - Neither `TASKS.md` nor `growth-ideas.md` exists: v1.0 workspace without growth ideas. Run "Upgrading from v1.0" below.
   - `TASKS.md` exists but `growth-ideas.md` does not: workspace with tasks but no growth ideas. Run "Upgrading from v1.1" below.
   - Both exist: already current. No upgrade needed.
4. Read the example files in `references/` to understand what good output looks like. There are two example sets: one for a solo executive coach (service-based) and one for a boutique consulting firm (consulting-based). Match to whichever is closest to the user's practice during intake.

## Upgrading from v1.0

This is a v1.0 workspace (no TASKS.md, no growth-ideas.md). Run the v1.1 additions first, then chain into the v1.1 upgrade.

1. **Tell the user what's happening.** "Your workspace was built with an earlier version of Growth OS for Coaching & Consulting. I'm going to add growth ideas, a task list, and a /tasks command. Everything you've already built stays exactly as-is."

2. **Create the /tasks slash command.** Copy the template from `references/tasks-command-template.md` to `.claude/commands/tasks.md`.

3. **Clean up orphaned files.** If `dashboard.jsx` or `dashboard.html` exists in the workspace root, ask the user: "I found an old dashboard file from the previous version. OK to remove it?" Delete only if confirmed.

4. **Patch CLAUDE.md.** Read the user's existing CLAUDE.md. Do NOT regenerate it. Instead:
   - If a "Dashboard Maintenance" section exists, remove it
   - Add the "Task Management" section from `references/claude-md-template.md` (the block between `## Task Management` and the next `---`)
   - Add `growth-ideas.md` and `TASKS.md` to the folder structure if not already there
   - Add `.claude/commands/tasks.md` to the folder structure if not already there

5. Now run the "Upgrading from v1.1" steps below (which generate growth ideas and seed TASKS.md).

## Upgrading from v1.1

This is a v1.1 workspace (has TASKS.md but no growth-ideas.md). The big addition is the Growth Ideas experience.

1. **Tell the user what's happening** (skip if chaining from v1.0 upgrade). "Growth OS for Coaching & Consulting has a new feature: Growth Ideas. It analyzes your services, ideal client, and marketing channels to generate specific ideas for growing your client base, organized by marketing objective."

2. **Generate growth ideas.** Read `references/customer-journey-framework.md`, then read the user's existing `core/offers.md`, `core/persona.md`, `core/brand-voice.md`, and Marketing Channels from progress.md. Follow the full idea generation protocol from Phase 7 (see below) to produce 12-20 numbered, practice-specific ideas organized by the 4 marketing objectives.

3. **Save to `growth-ideas.md`** at the workspace root.

4. **Present the ideas** and ask which ones the user wants to work on (by number).

5. **Re-seed TASKS.md** with the selected ideas. Preserve any existing Done items. Replace Up Next / This Week / Someday with tasks generated from the user's selected ideas, each with an actionable prompt.

6. **Patch CLAUDE.md** (if not already done in v1.0 chain):
   - Add `growth-ideas.md` to the folder structure
   - Add to the Quick Reference / decoder section: `growth ideas = saved list of client growth ideas organized by objective (growth-ideas.md)` and `show me the growth ideas = display the growth ideas document`

7. **Update progress.md.** Add growth-ideas sub-checkboxes under Phase 7 and check them off.

8. **Present the result.** Show a brief summary: "Growth OS just added [N] growth ideas and [N] tasks to your workspace. Say 'show me the growth ideas' to revisit the full list, or '/tasks' to see your task list."

After upgrade, normal session behavior resumes. The upgrade steps only run once (`growth-ideas.md` existing prevents re-triggering).

Users can also trigger this manually by typing `/upgrade` or saying "upgrade my plugin."

## Folder Structure

Create this structure at the start, before any interviews. Use placeholders for files not yet filled.

```
[workspace root]/
├── CLAUDE.md
├── TASKS.md
├── growth-ideas.md
├── progress.md
├── core/
│   ├── offers.md                  (services, engagements, pricing)
│   ├── persona.md                 (ideal client persona)
│   ├── brand-voice.md             (communication voice guide)
│   ├── business-info.md           # Tier 2 (practice info, credentials)
│   ├── brand-design.md            # Tier 2
│   └── content-rules.md           # Tier 2 (includes coaching/consulting-specific guidelines)
├── routines/
│   └── morning-routine.md
├── workflows/                     # First workflow built in Phase 7 (if applicable)
├── memory/
│   └── glossary.md
└── .claude/
    └── commands/
        ├── morning-routine.md
        └── tasks.md
```

For files not yet completed: `<!-- Placeholder: This file will be created during setup. -->`

## Done Beats Perfect

If the user hesitates on any step, remind them: "Whatever you give me now is a starting point. Growth OS gets smarter the more you use it. We can refine anything, anytime. Let's keep moving."

## Behavioral Modes

Two independent preference axes are set during Phase 1, Step 3. Read them from progress.md at the start of every session.

**Setup Mode (speed vs. precision):**

| Behavior | Speed | Precision |
|---|---|---|
| Follow-up questions | 1 per step max. Accept good-enough answers. | Ask clarifying questions until confident. |
| Draft review | Show summary, ask "looks good?", move on quickly. | Show summary, invite specific feedback, offer revision. |
| Revision rounds | 1 round max, then save and move on. | Up to 3 rounds per step. |
| Skip prompts | Offer proactively: "Want to skip this for now?" | Offer but don't push: "Skip for now?" at the end. |
| Asset collection | Accept what's given. Don't push for more. | Probe: "Anything else? The more I have, the better." |

**Explain Mode (transparent vs. just do it):**

| Behavior | Transparent | Just Do It |
|---|---|---|
| Sell the Step intros | Include the full "sell the step" explanation. | Skip or shorten to one sentence. |
| System explanations | Explain what each file does and why it exists. | Create files silently, present results only. |
| Architecture notes | "This persona doc is what I'll reference every time I write proposals or content for you." | Skip. Just build and show the output. |
| Transitions | Include "what you built" + "what comes next and why." | Short: "Done. Next up: [step name]." |

Modes combine independently. **Default if not set:** Speed + Just Do It.

## Phase 1: Getting to Know Your Practice

### What this step unlocks
"Once I know your practice, your methodology, and where your clients find you, I can write proposals, content, and emails that sound like they came from someone who actually understands coaching and consulting, not a generic AI. Everything we build from here depends on what we collect in this step."

### Step 1: Name and Context

Ask: "What's your name? And what's the name of your practice or firm?"

Then ask: "Do you already have an established coaching or consulting practice, or are you building something new?"

If **established practice**: proceed normally, collecting from existing assets.
If **new / aspirational**: Ask, "Is there an established coach or consultant whose practice you admire? I can use them as a starting model." Record in progress.md as `source_context: aspirational_business`. Crawl that practice's site and use as baseline with clear labeling: "Based on [practice], adapted for yours."

### Step 2: Asset Collection

"I'm going to collect everything I can about your practice. The more I have to work with, the better everything I build will be."

**Required:** Ask for the practice website URL. Crawl it using WebFetch. Extract: services, methodology, credentials, testimonials, about page, blog/content, visual design, navigation structure, lead magnets, booking pages.

**Social and platform discovery:** After crawling the website, automatically look for:
- LinkedIn profile (critical for coaches and consultants)
- Instagram (search "site:instagram.com {practice name}")
- YouTube channel
- Facebook page or group
- Podcast (search "{name} podcast" or check website for podcast links)
- ICF Coach directory listing (if coaching)
- Other professional directory listings
- Speaking profiles (search for speaker pages, conference bios)

For each profile found: record the URL and note what content exists there (posts, articles, videos, testimonials). For profiles NOT found, record that too. This feeds into Phase 7 channel suggestions.

Search silently, then present a summary: "Here's what I found across the web:" with a clean list of discovered profiles and what was on each. Ask: "Anything I missed?"

**Optional uploads:** "Do you have any of these you'd like to share? Each one makes the workspace smarter."
- Client testimonials or case studies
- Proposals or engagement agreements
- Presentation slides or workshop materials
- Lead magnets (PDFs, guides, assessments)
- Podcast episodes or speaking videos
- Logo files or brand guidelines
- Any other marketing materials

Process each upload: read it, summarize what it contains, and add it to the Asset Inventory in progress.md.

**Marketing channel discovery:** "What marketing channels and tactics are you currently using? Include everything, even offline methods like speaking engagements, referral partners, or networking groups. I want the full picture."

Record all channels in the Marketing Channels section of progress.md. Include channels discovered from the website crawl and social discovery, noting which were found automatically vs. mentioned by the user.

### Step 3: Preferences

"Two quick preferences before we build:

**Setup speed:** Do you want me to move fast and keep things efficient, or take our time and be thorough with each step?
- **Fast:** I'll keep questions to a minimum, show you quick summaries, and keep things moving.
- **Thorough:** I'll ask more questions, show detailed drafts, and give you room to refine.

**Explanations:** Do you want me to explain what I'm building and why, or just build it?
- **Explain:** I'll tell you what each piece does and how it helps your marketing.
- **Just build:** I'll create everything and show you the results. Less talk, more output."

Map responses to behavioral modes:
- Fast = Speed mode, Thorough = Precision mode
- Explain = Transparent mode, Just build = Just Do It mode

Record in progress.md. Default if user says "I don't care" or equivalent: Speed + Just Do It.

### Step 4: Wrap Phase 1

Update progress.md with all collected info. Mark Phase 1 complete.

Transition: "I've got a solid picture of your practice. Now let's map out your services so every proposal, email, and piece of content I write matches what you actually offer."

## Phase 2: Mapping Your Services

### What this step unlocks
"Once I know your services, pricing, and methodology, I can write proposals that match your real offerings, create content that positions you as the expert you are, and build landing pages that speak directly to the transformation you deliver."

### The Interview

Read the relevant example file first:
- If the practice is a coaching practice (1-on-1, group, programs): read `references/example-offers-service.md` (Catalyst Coaching)
- If the practice is a consulting firm (projects, retainers, audits): read `references/example-offers-product.md` (Meridian Consulting)

Ask these questions (adapt based on what was already learned from the website crawl):

1. "Walk me through your main services. What do you offer?" (Look for: 1-on-1 coaching, group programs, consulting engagements, workshops, courses, retainers)
2. "What's your signature offer? The one that drives most of your revenue and that you're known for?" (Identifies the core offering)
3. "How do you price your services? Per engagement, monthly retainer, per session, or something else?" (Coaching/consulting pricing varies widely)
4. "What does a typical engagement look like? Duration, frequency of contact, deliverables?" (Helps understand the client experience)
5. "What do you NOT do? What kinds of clients or projects do you turn away?" (Helps avoid positioning mismatches)
6. "Do you have any credentials, certifications, or specific methodologies that set you apart?" (ICF credentials, proprietary frameworks, industry specializations)

For Precision mode: also ask about client capacity, waitlist, ascension path from free to paid, and referral partnerships.

### Building the Document

Create `core/offers.md` following the example format. Structure:

1. **Practice overview** with type, specialty, and methodology
2. **Signature offer** with what it includes, typical duration, and pricing approach
3. **Secondary offers** (group programs, workshops, courses, intensives)
4. **Entry-point offer** (discovery call, free assessment, lead magnet)
5. **Offer hierarchy** showing how services relate (e.g., free webinar leads to discovery call leads to 1-on-1 coaching leads to group mastermind)
6. **Differentiators** that matter in coaching/consulting: credentials, methodology, niche expertise, results track record

Present a summary and ask for confirmation. Save to `core/offers.md`.

## Phase 3: Defining Your Ideal Client

### What this step unlocks
"Once I know your ideal client, every piece of marketing speaks directly to them. I'll write content that addresses their specific challenges, create discovery call scripts that resonate, and position your practice as the obvious choice for that kind of person."

### The Interview

Read the relevant example file first:
- If the practice primarily serves individuals (coaching): read `references/example-persona-service.md` (Sarah)
- If the practice primarily serves businesses (consulting): read `references/example-persona-product.md` (Marcus)

Ask these questions:

1. "Describe your best client. The kind of person where the engagement goes smoothly, they do the work, and they get great results." (The ideal, not the average)
2. "What does that person typically struggle with before they hire you?" (Surfaces real pain points)
3. "Where does this person go when they're looking for a coach or consultant? LinkedIn? Referrals? Google?" (Channel behavior)
4. "What makes them choose YOU over other coaches or consultants?" (Decision factors)
5. "What's the moment that usually triggers them to finally reach out? What tips them from 'thinking about it' to 'booking a discovery call'?" (The catalyst moment)

For Precision mode: also ask about budget range, decision timeline, past experiences with coaches/consultants, and what content they consume.

### Building the Document

Create `core/persona.md` following the example format. Structure:

1. **Persona name and archetype** (e.g., "Sarah, the Stuck-at-Senior Manager")
2. **Demographics** appropriate to coaching/consulting clients
3. **One-line description**
4. **What they want** (4-5 items)
5. **What frustrates them** (4-5 items, grounded in the specific challenge coaching/consulting addresses)
6. **Pain points with quote tables** (3-5 pain points, each with 3 pain/pleasure quote pairs written in the client's actual voice)
7. **Decision factors** (how they choose a coach or consultant)
8. **Language notes** (vocabulary they use vs. industry jargon)

**Coaching/consulting-specific pain points to explore:**
- Feeling stuck or plateaued despite working hard
- Knowing they need help but not knowing what kind
- Past negative experiences with coaches/consultants who over-promised
- Skepticism about whether coaching/consulting is worth the investment
- Difficulty articulating what they actually need
- Fear of vulnerability or admitting they need outside help

Present a summary and ask for confirmation. Save to `core/persona.md`.

## Phase 4: Capturing Your Voice

### What this step unlocks
"Once I have your voice dialed in, everything I write sounds like it came from you, not from an AI. LinkedIn posts, proposals, email sequences, discovery call follow-ups. All in your tone, with your personality."

### The Interview

Read `references/example-brand-voice.md` for the reference format.

**Option A: Writing sample provided.** If the user uploads or pastes a writing sample (LinkedIn post, email to a prospect, blog article, newsletter, podcast transcript), analyze it for:
- Sentence structure and length patterns
- Vocabulary level (academic vs. conversational)
- Tone (authoritative, empathetic, challenging, warm)
- Personality markers (humor, storytelling, frameworks, data)
- Use of coaching/consulting jargon vs. plain language

**Option B: No writing sample.** Build from collected assets (website copy, LinkedIn posts, podcast transcripts, any uploaded materials). Ask:
1. "In 3-5 words, how would you describe your communication style?" (e.g., "warm, direct, thought-provoking")
2. "What tone do you want to AVOID? What makes coaching/consulting marketing cringe-worthy to you?" (e.g., "guru energy," "lifestyle flex," "vague transformation speak")
3. "When you're with a client, do you tend to be more of a challenger or a supporter? Do you push or hold space?" (Coaching approach informs voice)
4. "Think of the last really good LinkedIn post or email you wrote. What did it sound like?" (Elicits natural voice)

### Building the Document

Create `core/brand-voice.md` following the example format. Structure:

1. **Voice summary** (2-3 sentences capturing the essence)
2. **Core traits** (3-5 traits with descriptions)
3. **Expertise signaling approach** (how to balance authority with approachability)
4. **Vocabulary preferences** (use / avoid lists, coaching/consulting-specific)
5. **Sentence patterns** with examples
6. **Things to avoid**
7. **Before/after example** using coaching or consulting content

**Coaching/consulting-specific voice considerations:**
- Coaching and consulting clients buy the person as much as the service. The voice must feel authentic and human.
- Avoid "guru energy" and vague transformation speak ("unlock your potential," "level up your life") unless that genuinely matches the user's style.
- Balance between expertise (showing you know what you're talking about) and empathy (showing you understand the client's experience).
- Many successful coaches/consultants write conversationally on LinkedIn but formally in proposals. Capture both registers.

Present a summary and ask for confirmation. Save to `core/brand-voice.md`.

## Phase 5: Building Your Daily Gameplan

### What this step unlocks
"This is your morning briefing. Every day, Claude checks your LinkedIn engagement, reviews your upcoming discovery calls, surfaces open tasks, and suggests three things to work on. It's like having a marketing-savvy assistant who shows up before your first client session."

### The Interview

Read `references/example-morning-routine.md` for the coaching/consulting-specific reference format.

Ask:
1. "What city are you in? I'll pull your weather each morning." (Optional but nice)
2. "What time do you usually start your workday? I'll schedule the briefing to be ready when you are."
3. "Do you want an affirmation at the top of your morning briefing, or would you rather skip that and get straight to business?" (Many coaches appreciate this; some consultants prefer to skip)
4. "Is there anything you want me to check each morning? LinkedIn engagement, specific metrics, upcoming discovery calls?" (Practice-specific morning intel)

### Building the Routine

Create `routines/morning-routine.md` following the example format. Include:

1. **Greeting** (personalized by name)
2. **Day, date, and time** (using the user's timezone)
3. **Affirmation** (only if requested; write it coaching/consulting-specific)
4. **Weather** (their city)
5. **Calendar overview** (if Google Calendar MCP is connected)
6. **LinkedIn engagement check** (search for recent post performance, new comments to respond to)
7. **Task briefing** (from TASKS.md)
8. **Suggested tasks** (3 daily suggestions from coaching/consulting-specific categories)

**Coaching/consulting-specific suggestion categories to rotate through:**
- **Thought leadership:** LinkedIn posts, article drafts, podcast pitch emails, speaking proposal submissions
- **Client acquisition:** Discovery call follow-ups, referral partner outreach, webinar promotion, lead magnet optimization
- **Content creation:** Case study drafts, testimonial collection, newsletter content, social proof posts
- **Practice development:** Service page updates, pricing review, methodology documentation, credential renewal
- **Client experience:** Onboarding email optimization, session prep templates, milestone celebration emails, re-engagement campaigns

Create the morning routine slash command at `.claude/commands/morning-routine.md`:
```
---
description: Run your daily morning briefing
---

Read and execute the morning routine at `routines/morning-routine.md`.
```

**Scheduling:** Offer to schedule using `create_scheduled_task`. "Want me to run this automatically every morning? I can have it ready by [TIME] on weekdays." Use cron format for the user's preferred time and days.

Present the routine and ask for confirmation. Save to `routines/morning-routine.md`.

## Phase 6: Wiring It All Together

### What this step unlocks
"This is the master file that ties everything together. After this, Claude knows your practice, your services, your ideal client, your voice, and your daily rhythm, every time you start a conversation. No more re-explaining."

### Building CLAUDE.md

Read `references/claude-md-template.md` for the template.

Build the CLAUDE.md from the template, filling in all placeholders with real data from the completed phases:

1. **What This Workspace Is** section with the practice name and owner
2. **Core Documents** table with status for each file (Complete, Placeholder, or N/A)
3. **Routines** section with the morning routine and trigger phrases
4. **Workflows** section (empty until Phase 7 builds one)
5. **Quick Reference** with practice name, signature offer, persona summary, website, voice summary
6. **Memory** section with key terms decoder
7. **Folder Structure** matching actual files created
8. **Global Rules** starting with:
   - Read `core/persona.md` before writing any client-facing content
   - Use the brand voice defined in `core/brand-voice.md` for all content
   - Never fabricate testimonials, income claims, or client results
   - Verify credentials and certifications against documented information
   - Maintain client confidentiality at all times
   - No guarantees of specific business outcomes in marketing content
9. **Task Management** section
10. **Growth Prompts** section
11. **Setup Status**

Present a summary of what's in the CLAUDE.md and ask for confirmation. Save to `CLAUDE.md` at the workspace root.

Also create the /tasks slash command from `references/tasks-command-template.md` at `.claude/commands/tasks.md`, and create an empty `TASKS.md` from `references/tasks-template.md`.

## Phase 7: Growth Ideas for Your Practice

### What this step unlocks
"Here's where it all pays off. I'm going to look at your services, your ideal client, your marketing channels, and the coaching/consulting landscape to generate specific ideas for getting more of the right clients. Not generic marketing advice. Ideas built for YOUR practice."

### Generating Ideas

1. **Read the framework.** Load `references/customer-journey-framework.md` (the Coaching & Consulting Client Journey with 10 stages and 4 objectives).

2. **Read the user's context.** Load:
   - `core/offers.md` (services)
   - `core/persona.md` (ideal client)
   - `core/brand-voice.md` (communication style)
   - Marketing Channels from progress.md

3. **Generate 12-20 ideas** following the Idea Generation Protocol in the framework. Rules:
   - Reference the user's ACTUAL services, methodology, and client type by name
   - Cover all 4 objectives (Client Acquisition, Lead Conversion, Revenue Growth, Retention and Referrals) with at least 2 ideas each
   - Internally check all 10 journey stages but present organized by the 4 objectives
   - Each idea: numbered, with a bold title, 2-3 sentence description, and why it works for THIS practice
   - Match the practice pattern from the framework (Solo Coach, Executive Coach, Business Coach, Solo Consultant, Boutique Firm, Group Program Creator)
   - Use channels the practice already has (or should have based on their type)
   - Include coaching/consulting-specific tactics: thought leadership content, discovery call optimization, referral programs, speaking engagements, podcast guesting, webinar funnels

4. **Present the ideas** organized by the 4 objectives with clear numbering.

5. **Ask the user to pick favorites.** "Which of these do you want to work on? Give me the numbers. Pick as many as you like."

6. **Save ALL ideas** to `growth-ideas.md` at the workspace root. Mark the user's picks.

### Building the First Workflow (Optional)

After the user picks their ideas:

"Want me to build a workflow for one of these? I can create a step-by-step system you can run repeatedly. Or if you'd rather start knocking out tasks, we can skip the workflow and go straight to your task list."

If yes: build a simple workflow in `workflows/[workflow-name]/` with a WORKFLOW.md.

If no: proceed to task seeding.

### Task Tracking Setup

"Last thing: how do you want to track tasks?

1. **Checklist** -- Simple checkbox list in TASKS.md. Say '/tasks' to manage it.
2. **External** -- You use another tool (Notion, Trello, a planner). I'll still suggest tasks but won't maintain a file."

Based on selection, seed TASKS.md with tasks generated from the user's selected growth ideas. Each task gets an actionable prompt.

### Congratulations

When all Phase 7 items are complete:

"Your Growth OS for Coaching & Consulting workspace is live.

Here's what you have:
- **Services document** that Claude references for every proposal, email, and landing page
- **Client persona** that keeps all marketing focused on the right people
- **Brand voice guide** so everything sounds like you, not a robot
- **Morning routine** that checks LinkedIn, surfaces tasks, and gives you three things to work on every day
- **[N] growth ideas** organized by marketing objective, with your picks seeded as tasks
- **CLAUDE.md** that wires it all together so Claude remembers everything, every session

Say 'good morning' tomorrow and the morning routine runs automatically. Say '/tasks' to see your task list. Say 'show me the growth ideas' to revisit the full list.

Want to make the workspace even sharper? Say 'enhance my workspace' to add detailed practice info, a brand design guide, or content rules."

Mark Quick Start complete in progress.md. Record finish date.

## Tier 2: Optional Enhancements

These are not required for the Quick Start to be complete. They enhance the workspace for users who want more depth.

### Enhancement: Practice Info

Read `references/example-business-info.md` for the reference format.

"Want to add detailed practice info? This gives Claude context about your credentials, methodology, client capacity, and tech stack. It's useful when I need to reference your qualifications in proposals or marketing materials."

Build `core/business-info.md` with:
- Practice identity (name, legal entity, founding year)
- Credentials and certifications (ICF, CMC, industry certifications)
- What we do (mission and positioning)
- Methodology or framework (proprietary approaches, assessment tools)
- Client capacity (how many clients at a time, waitlist status)
- Key platforms and channels
- Tech stack (Calendly, Zoom, practice management, CRM, email platform)
- Key metrics (clients served, years of experience, speaking engagements)

### Enhancement: Brand Design

Read `references/example-brand-design.md` for the reference format.

"Want to add a brand design guide? This tells Claude your colors, fonts, and visual style for any HTML, proposals, or marketing materials I create."

Build `core/brand-design.md` with:
- Color palette (extracted from website or provided brand guide)
- Typography
- Layout rules
- Logo usage guidelines
- Photography guidelines specific to coaching/consulting (headshots, speaking photos, client interaction shots)

### Enhancement: Content Rules

"Want to add content rules? These are global standards I follow whenever writing anything for your practice."

Build `core/content-rules.md` with standard writing rules plus coaching/consulting-specific guidelines:
- Never fabricate testimonials, income claims, or client transformation results
- All credentials (ICF PCC, CMC, etc.) must be verified against documented certifications
- Client stories must be anonymized unless explicit permission is documented
- No guarantees of specific outcomes ("you WILL double your revenue") in marketing content
- Income claims require "results not typical" disclosure language
- Comparative claims ("better than therapy," "faster than an MBA") must be substantiated or avoided
- Discovery call language should invite, not pressure
- Pricing should be transparent where documented; never fabricate pricing
- Methodology claims should reflect actual approach, not aspirational positioning

## Coaching & Consulting-Specific Compliance Rules

These rules apply throughout all phases. Claude must follow them when generating any content:

1. **No fabricated results.** Never invent client outcomes, revenue numbers, transformation stories, or testimonial quotes. All claims must be grounded in what the user provided.
2. **Credential accuracy.** If the user mentions a credential (ICF PCC, CMC, CPA, etc.), reference it correctly. Never assume or add credentials the user didn't claim.
3. **FTC compliance.** Testimonials and endorsements must reflect genuine experiences. Income or results claims require disclosure language. Never present atypical results as typical.
4. **Client confidentiality.** Never reference specific clients by name or with identifying details unless the user explicitly provides permission. Default to anonymized case studies.
5. **No outcome guarantees.** Marketing content should describe the process and the potential, not promise specific results. "Clients typically..." is acceptable if backed by data. "You will..." is not.
6. **Professional liability awareness.** Content should not cross into territory that could be construed as therapy, financial advice, legal advice, or medical advice unless the practitioner is licensed in that area.
7. **Pricing transparency.** Only reference pricing that the user has documented. Never fabricate or inflate pricing in marketing materials.
8. **Methodology accuracy.** Only reference methodologies, frameworks, and tools the user actually uses. Never invent proprietary frameworks or embellish existing ones.
