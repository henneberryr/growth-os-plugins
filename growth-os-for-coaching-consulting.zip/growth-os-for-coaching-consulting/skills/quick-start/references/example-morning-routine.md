You are running Rachel's morning routine. Execute each step below in order, presenting everything in a single warm, flowing response.

## Step 1: Greeting
Greet Rachel by name with a warm, energized good morning. Keep it natural and uplifting. Vary the greeting so it doesn't feel robotic day to day.

## Step 2: Day and Date
Tell Rachel what day of the week it is, the full date, and the current time. Use the Bash tool to run `TZ='America/Chicago' date` to get the accurate current day, date, and time in Central Time.

## Step 3: Affirmation
Transition with something like "Before we dive in, take a breath and read this out loud:" Then present the following affirmation in a clean, readable format:

---

Every client I serve becomes living proof of the work I do. I trust my methodology, I trust my experience, and I trust that showing up with genuine expertise creates a practice that grows itself. Today I will focus on the work that matters and let go of the noise.

---

After the affirmation, add one brief encouraging line, then move on.

**Note for the Quick Start Skill:** This affirmation is written to resonate across coaching and consulting practice types. When building the morning routine during setup, personalize it based on the practice's identity. A life coach might prefer "Every person I guide is one step closer to the life they deserve." A business consultant might prefer "Every system I build outlasts the engagement that created it." A group program creator might prefer something about community and collective growth. Adapt to fit.

## Step 4: Today's Weather
Use the WebSearch tool to search for "weather today Austin Texas" and then use WebFetch on a detailed forecast page to get specifics. Present today's weather as a clean summary:

- High / Low
- Feels like
- Sky conditions
- Chance of precipitation
- Wind

Use short, scannable lines. Just the data.

## Step 5: Calendar Overview
Use any available Google Calendar MCP tools to pull calendar events. Present:

**Today's Schedule:**
List each meeting/event with time, title, and attendees. If no events, say "No meetings today."

**Upcoming Discovery Calls:** Highlight any discovery calls in the next 48 hours. For each one, note: name, time, and suggest reviewing the intake form or LinkedIn profile before the call.

**Tomorrow's Schedule:**
Same format. If nothing, say so.

If Google Calendar tools are not available, skip this step and let Rachel know the calendar connector may need to be reconnected.

## Step 6: LinkedIn Engagement Check
Use the WebSearch tool to check for recent LinkedIn activity. Search for Rachel's LinkedIn profile and recent posts. If any posts have received new comments or engagement:
- Highlight posts with notable activity
- Suggest 1-2 comments to respond to
- Note if any connection requests or messages should be reviewed

If you cannot access LinkedIn data, skip and note: "LinkedIn check skipped. You can review your notifications directly."

## Step 7: Task Briefing
Check for any task files in the workspace. If a TASKS.md or similar exists, present the top open items. If not, skip this section.

Present open tasks sorted by priority, with due dates highlighted if any are today or overdue.

## Step 8: Suggested Tasks
Read all files in the workspace (core docs, any workflows, any recent outputs). Based on the current state of the practice's marketing, the client persona's pain points, any active workflows, and what hasn't been done recently, suggest 3 specific tasks Rachel could tackle today. Present them as numbered options, each with a one-sentence description of what it is and why it matters right now.

Coaching/consulting-specific suggestion categories to rotate through:
- **Thought leadership:** LinkedIn articles, opinion posts, framework posts, podcast pitch emails, speaking proposal submissions, newsletter content
- **Client acquisition:** Discovery call follow-ups, referral partner outreach, webinar promotion, lead magnet optimization, assessment funnel updates
- **Content creation:** Case study drafts, testimonial collection, client spotlight posts, blog articles, social proof content
- **Practice development:** Service page updates, pricing review, methodology documentation, credential showcasing, proposal template refinement
- **Client experience:** Onboarding email optimization, session prep templates, milestone celebration emails, re-engagement campaigns, alumni outreach

These should feel like a smart marketing colleague saying "here's what I'd work on today if I were you." Vary the suggestions day to day. Don't repeat the same three every morning.

## Step 9: Wrap-Up
Close with a quick summary: "[N] meetings today, [N] discovery calls this week, [N] open tasks, 3 suggested tasks above. What do you want to start with?"

---

## Notes for the Quick Start Skill

This example shows a fully built morning routine for an executive coaching practice. When building a routine during the Quick Start, adapt based on what the user told you:

- **Affirmation section** is optional. Only include if the user requested it.
- **Weather section** uses the city they provided. Swap the timezone in the Bash command to match.
- **Calendar section** only works if Google Calendar MCP tools are connected. If not connected, note that and skip. Discovery call highlighting is coaching/consulting-specific and should always be included if calendar is available.
- **LinkedIn Engagement Check** is critical for coaches and consultants. Include it by default. Ask during setup: "Want me to check your LinkedIn engagement each morning?" If declined, skip.
- **Task section** only works if task files exist. For new workspaces, this section will be empty on day one but becomes useful as the workspace grows.
- **Suggested Tasks** section is always included. Even on day one, Claude can suggest tasks based on what was set up during the Quick Start. Rotate through coaching/consulting-specific categories: thought leadership, client acquisition, content creation, practice development, and client experience.
- **Scheduling:** After building the routine, offer to schedule it using `create_scheduled_task`. Example cron for 7:30am weekdays in the user's local timezone: `30 7 * * 1-5`. The cron is evaluated in the user's local machine timezone, not UTC.
