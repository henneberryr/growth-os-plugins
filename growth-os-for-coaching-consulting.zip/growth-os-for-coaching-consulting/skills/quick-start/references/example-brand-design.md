# Brand Design Guide -- Catalyst Coaching

> This document defines the visual identity for all design output. Claude reads this before producing HTML, proposals, emails, or any visual assets.

Last updated: March 2026

---

## Design Philosophy

Warm, professional, and human. The design should feel like a conversation with a trusted advisor: approachable but polished. Not corporate-stiff, not Instagram-casual. White space conveys clarity. Photography conveys authenticity. Every element reinforces trust and expertise.

## Color Palette

### Primary Colors

| Name | Hex | RGB | Usage |
|---|---|---|---|
| Deep Teal | #1A5C5C | 26, 92, 92 | Primary brand color. Headers, buttons, accents |
| Dark Charcoal | #2D2D2D | 45, 45, 45 | Primary text color |
| White | #FFFFFF | 255, 255, 255 | Backgrounds |

### Secondary Colors

| Name | Hex | RGB | Usage |
|---|---|---|---|
| Soft Sage | #E8F0EC | 232, 240, 236 | Callout backgrounds, section dividers |
| Warm Cream | #F9F6F2 | 249, 246, 242 | Card backgrounds, testimonial sections |
| Medium Gray | #6B7B8D | 107, 123, 141 | Secondary text, captions |

### Accent Colors

| Name | Hex | Usage |
|---|---|---|
| Warm Gold | #D4A853 | CTAs, key highlights, credibility markers |
| Soft Blue | #4A90B8 | Links, secondary actions |
| Error Red | #D94F4F | Errors, critical items |

## Typography

| Role | Font | Weight | Size |
|---|---|---|---|
| Headings | Inter | Bold (700) | H1: 36px, H2: 28px, H3: 22px |
| Body | Inter | Regular (400) | 16px, line-height 1.7 |
| Small text | Inter | Regular (400) | 14px |
| Pull quotes | Inter | Medium Italic (500i) | 20px |

## Layout Rules

- Maximum content width: 720px for long-form content, 960px for landing pages
- Section padding: 56px vertical
- Card border-radius: 12px
- Card shadow: 0 2px 8px rgba(0,0,0,0.06)
- Button border-radius: 8px
- Button padding: 14px 28px
- Testimonial cards: Warm Cream background with subtle left border in Deep Teal

## Photography Guidelines

Coaching and consulting marketing relies heavily on the practitioner's personal brand. Photography guidelines:

- **Headshots:** Professional but approachable. Slight smile, direct eye contact, clean background. Should feel like the person you'd want as your advisor, not a corporate ID badge.
- **Speaking photos:** At events, on stage, or in workshop settings. Shows credibility and authority. Natural lighting preferred.
- **Coaching session imagery:** If showing a coaching session, never show the client's face. Focus on hands, notebooks, the setting. Respect confidentiality even in stock imagery.
- **Environmental shots:** Coffee shop, office, walking meeting. Show the human behind the practice. Lifestyle without being lifestyle-brand.
- **Never use:** Stock photos of handshakes, generic "business meeting" images, or staged group photos. These undermine the personal brand.

## Logo Usage

- Primary logo: teal on light backgrounds
- Inverted logo: white on teal or dark backgrounds
- Minimum clear space: 1x the height of the logo mark on all sides
- Never stretch, rotate, or change the logo colors

## Do's and Don'ts

**Do:**
- Use generous white space for readability and breathing room
- Lead with photography on about and service pages
- Keep layouts clean, warm, and scannable
- Use testimonials prominently with real names (with permission)
- Use Deep Teal as an accent, not a dominant color

**Don't:**
- Use stock photos of generic business people
- Clutter pages with too many CTAs or competing visuals
- Use bright, flashy colors or gradients
- Put text over busy backgrounds
- Use more than 3 colors in a single layout

---

## Notes for the Quick Start Skill

This is a Tier 2 enhancement, not part of the core Quick Start. When a user asks to "enhance my workspace" with brand design:

1. Pull colors, fonts, and visual style from the website crawl and any uploaded brand assets.
2. If a brand guide PDF was uploaded during intake, use it as the primary source.
3. If no brand assets exist, generate a reasonable design system from the website's existing colors and fonts.
4. Always include: color palette with hex codes, typography choices, layout rules, and photography guidelines.
5. **Coaching/consulting-specific:** Always include photography guidelines. Personal brand photography is the most important visual asset for coaches and consultants. Headshots, speaking photos, and environmental imagery should feel authentic and professional, never corporate-generic.
