# Practice Information -- Catalyst Coaching

> This document is referenced by skills and workflows that need practice context. Keep it updated when anything material changes.

Last updated: March 2026

---

## Practice Identity

- **Brand name:** Catalyst Coaching
- **Tagline:** Leadership development for people who build things.
- **Legal entity:** Catalyst Coaching LLC (Texas, founded 2019)
- **Founded by:** Rachel Torres
- **Website:** https://catalystcoaching.example.com
- **Email:** rachel@catalystcoaching.example.com
- **Location:** Austin, TX (serves clients nationwide via Zoom)

## Credentials & Certifications

- **ICF Professional Certified Coach (PCC):** 800+ coaching hours
- **Corporate background:** 15 years in corporate leadership, VP of Operations at a Fortune 500 company
- **Additional training:** Co-Active Coaching certification, Leadership Circle Profile certified practitioner
- **Speaking:** Keynote speaker at 10+ industry conferences annually

## What We Do

Catalyst Coaching is an executive and leadership coaching practice that helps mid-level managers and emerging leaders break through career plateaus and develop the skills, presence, and confidence for senior leadership roles. The practice combines evidence-based coaching with practical corporate experience.

## Mission

Most leadership development programs are generic, theoretical, and disconnected from the realities of corporate life. Catalyst Coaching exists because the leap from Director to VP requires a fundamentally different set of skills, and nobody teaches them. We do.

## Methodology

**The Catalyst Framework:** A 6-phase development process.
1. Clarity -- What do you actually want, and why?
2. Assessment -- Where are you now? (Leadership Circle Profile, 360 feedback)
3. Capability -- What skills need to develop? (executive communication, strategic thinking, stakeholder management)
4. Practice -- Deliberate skill-building with real-world application between sessions
5. Confidence -- Integrating new behaviors until they feel natural
6. Trajectory -- Building a 12-month forward roadmap for continued development

## Client Capacity

- Maximum 1-on-1 coaching clients: 15 at a time
- Current active clients: 12
- Waitlist: Typically 2-4 people
- Group program: 2 cohorts per year (spring and fall), 8-12 per cohort

## Key Platforms & Channels

| Channel | Purpose |
|---|---|
| Website | Service pages, blog, assessment lead magnet, booking |
| LinkedIn | Primary content platform, thought leadership, client acquisition |
| Email newsletter | Monthly leadership insights, engagement announcements |
| Podcast guesting | 6-8 guest appearances per year on leadership/business podcasts |
| Speaking | 10+ keynotes and workshops per year at corporate and industry events |

## Tech Stack

| Tool | Role |
|---|---|
| Calendly | Discovery call and session scheduling |
| Zoom | Coaching sessions and group program delivery |
| ConvertKit | Email marketing and newsletter |
| Voxer | Between-session client communication |
| Google Workspace | Business operations, calendar, documents |
| Claude (Cowork) | AI workspace for content and marketing operations |
| Canva | Social media graphics |
| Leadership Circle Profile | 360 assessment tool for coaching clients |

## Key Metrics

- Years coaching: 7
- Clients served: 200+ (individual coaching)
- Group program alumni: 120+
- Keynotes delivered: 60+
- LinkedIn followers: 8,400
- Email subscribers: 2,100
- Average client engagement: 7 months
- Client satisfaction: 9.4/10 (post-engagement survey)

---

## Notes for the Quick Start Skill

This is a Tier 2 enhancement, not part of the core Quick Start. When a user asks to "enhance my workspace" with practice info:

1. Draft from ALL collected assets (website crawl, LinkedIn, uploads, and the already-completed services and persona docs).
2. Ask about anything missing: credentials, methodology, client capacity, tech stack, speaking history.
3. This file is a reference for Claude, not a marketing document. Write it as clean, factual reference material.
4. Cross-reference `core/offers.md` and `core/persona.md` rather than duplicating content.
5. **Coaching/consulting-specific sections to always include:** Credentials and certifications, methodology or framework, client capacity. These are frequently referenced in proposals, content, and marketing materials.
