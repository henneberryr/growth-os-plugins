# Ideal Client Persona -- Catalyst Coaching

> This document defines who we create content for, what language resonates with them, and what motivates them to act. Claude reads this before writing any client-facing content.

Last updated: March 2026

---

## Meet Sarah

**Full archetype:** Sarah, the Stuck-at-Senior-Manager

**Demographics:** 34-45 years old. Director or Senior Manager at a company with 200-2,000 employees. Has been in the role for 2-4 years. Household income $140K-$220K. Lives in a mid-to-large metro area. MBA or equivalent experience. Reports to a VP or C-suite executive. Manages a team of 5-15 people. Dual-income household, often with young children.

**One-line description:** A high-performing mid-level leader who has hit a career ceiling and knows she needs to develop differently to reach the next level, but can't figure out how on her own.

---

## What Sarah Wants

- To stop feeling like she's running in place while less qualified peers get promoted
- A clear roadmap for what "executive presence" actually means and how to develop it
- Honest, direct feedback from someone outside her company who has no agenda
- To become the kind of leader her team deserves, not just a manager who checks boxes
- To feel confident in rooms where she currently feels like an imposter

## What Frustrates Sarah

- She's done all the "right things" (MBA, performance reviews, leadership books) and still feels stuck at the same level
- Her company's leadership development program was a two-day offsite with generic personality assessments and no follow-up
- She knows she needs coaching but the industry feels full of people with a weekend certification and a motivational Instagram account
- Previous mentors gave well-meaning but generic advice ("just be yourself," "speak up more") that didn't help
- She can't talk about feeling stuck with her boss (shows weakness) or her peers (shows vulnerability) or her partner (they don't fully get it)

---

## Pain Points with Quote Tables

Each pain point includes quotes written in Sarah's voice, showing what she says when struggling (pain) and what she would say once the problem is solved (pleasure).

### Pain Point 1: Career plateau despite strong performance

| Pain Quote | Pleasure Quote |
|---|---|
| "I get 'exceeds expectations' on every review and still get passed over for the VP role. What am I missing?" | "I finally understood that what got me here won't get me there. The skills I needed to develop were completely different from the skills I'd been rewarded for." |
| "I watch people with less experience and weaker results get promoted. It's not a performance problem. It's something else." | "My coach helped me see what 'something else' was: strategic visibility, executive communication, and stakeholder management. Nobody had ever been that direct with me." |
| "I work harder every year and the gap between where I am and where I want to be just stays the same." | "For the first time in years, I can see a clear path to the next role. Not hope. A plan. With specific skills to develop and specific actions to take." |

### Pain Point 2: Imposter syndrome in senior settings

| Pain Quote | Pleasure Quote |
|---|---|
| "I'm in the room with the C-suite and I freeze. I have the insights but I can't find the words fast enough." | "I walked into the board presentation prepared and calm. I delivered my recommendations and fielded questions without spiraling. That's new." |
| "Every time I get invited to a strategy meeting, I spend more energy worrying about how I sound than actually contributing." | "I stopped trying to sound like what I thought a VP should sound like and started leading with my actual expertise. It landed completely differently." |
| "I know I'm qualified. I just can't shake the feeling that everyone's going to figure out I don't belong there." | "My coach pointed out that imposter syndrome was actually a sign I was growing into bigger rooms. That reframe changed everything." |

### Pain Point 3: No trusted feedback loop

| Pain Quote | Pleasure Quote |
|---|---|
| "My boss says 'great job' and moves on. My team says what I want to hear. I have no idea where my real gaps are." | "My coach gave me feedback that was uncomfortable and specific and exactly what I needed. Nobody else in my life does that." |
| "I read every leadership book. I've done the DISC, the StrengthsFinder, the 360. I have data. What I don't have is someone who helps me DO something with it." | "We took my 360 results and built an actual development plan. Not a shelf document. A working plan with weekly actions." |
| "I need someone who's been where I'm going, not a peer who's just as stuck as I am." | "Rachel has sat in the seats I'm aiming for. When she says 'this is what matters at the VP level,' I believe her because she's lived it." |

### Pain Point 4: Skepticism about coaching

| Pain Quote | Pleasure Quote |
|---|---|
| "I looked into coaching and the first thing I found was a TikTok life coach with a ring light and a 'manifest your best life' tagline. That's not what I need." | "Catalyst Coaching was the opposite of what I expected. No woo. No motivational posters. Just structured, evidence-based development with someone who gets corporate." |
| "Twelve thousand dollars is a lot. How do I know this isn't just paying someone to ask me 'how does that make you feel' for six months?" | "Three months in, I got the promotion I'd been circling for two years. The ROI wasn't even close. It was the best professional investment I've made." |
| "My company offers coaching through a platform with random matchmaking. I did two sessions and it felt like talking to a chatbot." | "Having a coach who actually knows my industry, my company dynamics, and my specific challenges made all the difference. It's not generic." |

---

## Decision Factors (How Sarah Chooses a Coach)

1. **Relevant experience** (has the coach actually led at the level I'm trying to reach?)
2. **Credibility signals** (ICF certification, corporate background, specific client results)
3. **Chemistry on the discovery call** (does this person get me? Do I trust them?)
4. **Specificity of approach** (clear methodology, not vague promises of "transformation")
5. **Social proof from similar clients** (testimonials from people in similar roles and industries)
6. **Investment clarity** (transparent pricing, clear what's included, no hidden upsells)

## Language Notes

- Sarah says "career growth" and "leadership development," not "personal transformation" or "manifesting"
- She says "coach" and "engagement," not "healer" or "journey"
- She responds to evidence, specificity, and corporate credibility
- She's allergic to guru energy, lifestyle flex, and vague promises
- She reads Harvard Business Review, follows leadership accounts on LinkedIn, and listens to business podcasts
- She'll research a coach's background thoroughly before booking a discovery call
- Her partner is involved in the decision (it's a significant household investment)
