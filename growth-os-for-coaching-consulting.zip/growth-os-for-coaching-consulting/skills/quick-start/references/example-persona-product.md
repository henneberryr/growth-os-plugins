# Ideal Client Persona -- Meridian Consulting

> This document defines who we create content for, what language resonates with them, and what motivates them to act. Claude reads this before writing any client-facing content.

Last updated: March 2026

---

## Meet Marcus

**Full archetype:** Marcus, the Founder Who Can't Let Go

**Demographics:** 38-55 years old. Founded or co-founded a small business doing $1M-$5M in annual revenue. 10-30 employees. Has been running the company for 5-15 years. Based in the Southeast US but open to virtual consulting. Industry varies (professional services, light manufacturing, healthcare practices, technology services). Works 60+ hours/week. Household income $200K-$400K (but much of it is tied up in the business).

**One-line description:** A business owner who built a company from nothing but has become the bottleneck, and knows he needs outside help to build the systems that let the business grow without depending on him for everything.

---

## What Marcus Wants

- To stop being the answer to every question and the solution to every problem in his own company
- Systems and processes that work even when he's not in the room
- A leadership team that can actually lead, not just manage tasks he delegates
- Revenue growth without proportional growth in his working hours
- Someone who understands small business operations and can help him build for the next stage, not someone selling Fortune 500 playbooks

## What Marcus Frustrates

- He's tried hiring COO-level people twice. The first one brought corporate bureaucracy. The second one couldn't handle the ambiguity of a growing company. Both were expensive failures.
- Every "business consultant" he's talked to either sells a $50K engagement with no clear deliverables, or sells a $500 course that's too generic to be useful
- His accountant and attorney give narrow advice. Nobody looks at the whole picture: operations, team, systems, and growth together.
- He reads business books (EOS, Scaling Up, E-Myth) and agrees with the frameworks but can't implement them while also running the day-to-day
- He knows the company's success is a bottleneck problem (him), but he doesn't know how to fix it without breaking what's already working

---

## Pain Points with Quote Tables

Each pain point includes quotes written in Marcus's voice, showing what he says when struggling (pain) and what he would say once the problem is solved (pleasure).

### Pain Point 1: Founder bottleneck

| Pain Quote | Pleasure Quote |
|---|---|
| "I took a week off and came back to 200 emails, three client fires, and a team that waited for me to make every decision." | "I was out for two weeks. When I got back, everything had run smoothly. My ops manager handled everything I used to handle. That's when I knew the systems were working." |
| "I know I'm the bottleneck. I just don't know how to remove myself without everything falling apart." | "Meridian helped me identify exactly which decisions I should be making and which ones I was holding onto out of habit. We built an authority matrix in week two." |
| "Everyone tells me to 'delegate more.' Nobody tells me HOW to delegate when there's no process to delegate TO." | "Now there's a documented process for every core function. I don't delegate tasks. I delegate outcomes. The SOPs handle the rest." |

### Pain Point 2: Operational chaos disguised as hustle

| Pain Quote | Pleasure Quote |
|---|---|
| "We're growing, but it feels like we're duct-taping everything together. Nothing is systematic." | "For the first time, I can see every project, every process, and every bottleneck in one view. The chaos is gone." |
| "We use 15 different tools and none of them talk to each other. Our 'system' is a series of workarounds." | "Meridian cut our tool stack in half and built integrations between what remained. Data flows automatically now instead of being manually copied between spreadsheets." |
| "I know we're losing money in operational inefficiency. I just can't quantify where." | "The diagnostic showed us we were spending $180K a year on rework and redundant processes. We've already cut that by 60%." |

### Pain Point 3: Team that manages but doesn't lead

| Pain Quote | Pleasure Quote |
|---|---|
| "I have managers, but they all escalate to me. None of them own their decisions." | "My team now runs their departments. They escalate exceptions, not decisions. I went from 15 direct reports functionally to 4." |
| "I promoted my best technicians to management and they have no idea how to manage people." | "Meridian built management training into the implementation. My shop floor lead now runs weekly team meetings and handles performance conversations. I stay out of it." |
| "I can't afford to hire a VP of Operations at $150K+. But I can't keep doing it all myself." | "Instead of hiring a $150K COO, I spent $35K with Meridian and built the systems a COO would have built. Now when I do hire that role, they'll have something to manage." |

### Pain Point 4: Skepticism about consultants

| Pain Quote | Pleasure Quote |
|---|---|
| "Last consultant gave me a 60-page report and a $15K invoice. Not one recommendation was specific enough to act on." | "Meridian's report was 12 pages with 5 priorities, each with a specific action plan, timeline, and owner. I started implementing the next week." |
| "I don't need someone to tell me what's wrong. I need someone to help me fix it." | "They didn't just diagnose. They rolled up their sleeves and built the systems alongside my team. By day 30, we had three new processes running." |
| "Consultants love frameworks. I need someone who understands what it's like to run a business with 20 employees and no safety net." | "James has built and run a real business. He gets the constraints. He doesn't suggest things I'd need a 50-person team to execute." |

---

## Decision Factors (How Marcus Chooses a Consultant)

1. **Relevant experience** with small businesses at a similar stage (not Fortune 500 downsized)
2. **Clear methodology** with a specific process, not vague "strategic advisory"
3. **Implementation capability** (will they help build, or just advise?)
4. **Referrals from other business owners** he trusts
5. **Transparent pricing** with clear scope and deliverables
6. **Track record of measurable results** (not just testimonials, but specific outcomes)

## Language Notes

- Marcus says "my business" and "my company," not "my venture" or "my enterprise"
- He says "systems" and "processes," not "frameworks" or "operating models" (though he's read the books)
- He says "employees" and "team," not "talent" or "human capital"
- He thinks in terms of revenue, margin, and time. Every investment needs to pay for itself.
- He respects people who have built real businesses, not just consulted on them
- He reads Inc., listens to business podcasts, and belongs to local business groups (YPO, EO, Vistage, or local chamber)
- He's direct and wants direct answers. Don't waste his time with setup and context. Get to the point.
