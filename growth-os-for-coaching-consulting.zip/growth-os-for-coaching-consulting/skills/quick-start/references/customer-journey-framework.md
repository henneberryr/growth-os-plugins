# Coaching & Consulting Client Journey Framework
## Internal Reference for Coaching & Consulting Growth Idea Generation

> This file is read by Claude during Phase 7 idea generation. It is NOT shown to the user.
> It provides the thinking structure for generating coaching/consulting-specific growth ideas.

---

## The Four Marketing Objectives

Every coaching and consulting marketing activity serves one of four objectives. Use these as the organizing categories for user-facing output.

| Objective | Practice Goal | What Success Looks Like |
|-----------|-------------|------------------------|
| **Client Acquisition** | Get discovered by people who need your expertise | More of the right prospects find your practice and understand why you're the right fit |
| **Lead Conversion** | Turn inquiries into signed engagements | Growing discovery call bookings, higher close rate on proposals, shorter decision timelines |
| **Revenue Growth** | Increase engagement value and expand offerings | Larger average engagement size, group programs filling, upsells to premium tiers, retainer clients |
| **Retention and Referrals** | Keep clients engaged and turn them into advocates | Re-engagements, referral leads, testimonials, speaking invitations, case study participation |

---

## The 10 Coaching & Consulting Client Journey Stages

Each stage maps to one objective. Use ALL 10 stages as a checklist when generating ideas to ensure full-funnel coverage. The user sees the 4 objectives; you use the 10 stages internally.

### CLIENT ACQUISITION (Stages 1-3)

**Stage 1: Problem Aware**
The potential client recognizes they have a challenge: they're stuck in their career, their business hit a plateau, their team is underperforming, or they can't figure out the next step on their own. They haven't started looking for a coach or consultant yet. They might be searching "how to get unstuck in my career" or "why can't I scale past $2M."

*Claude's job:* Generate ideas that get the practice in front of people during this early awareness phase. Thought leadership content that names the problem, validates the feeling, and hints at a path forward without being salesy.

**Stage 2: Solution Aware**
The potential client has realized that outside help exists and could be valuable. They're exploring whether coaching, consulting, a course, a mastermind, or something else is the right fit. They might be searching "executive coaching vs. mentoring" or "do I need a business consultant."

*Claude's job:* Generate ideas that educate the prospect on what coaching or consulting actually involves. Content that demystifies the engagement, sets expectations, and positions the practice's specific approach.

**Stage 3: Expert Search**
The potential client is now actively looking for the right coach or consultant. They're browsing LinkedIn, asking their network for recommendations, reading articles by thought leaders, checking credentials, and evaluating multiple options. This is where they build their short list.

*Claude's job:* Generate ideas that ensure the practice shows up and stands out during the search. LinkedIn thought leadership, podcast appearances, speaking engagements, directory listings, strong website with clear positioning, social proof.

### LEAD CONVERSION (Stages 4-6)

**Stage 4: Trust Building**
The potential client has found the practice and is evaluating whether to reach out. They're reading articles, watching videos, checking testimonials, reviewing credentials, and assessing whether this person "gets" their situation. Coaching and consulting are trust purchases, so this stage is critical.

*Claude's job:* Generate ideas that build deep trust before the discovery call. Case studies, methodology explanations, "my approach" content, behind-the-scenes of how engagements work, client testimonial videos, credential showcases.

**Stage 5: Discovery Call**
The client has booked a discovery call (or consultation, or strategy session). This is the critical conversion point. The quality of the call, the follow-up, and the proposal determine whether they become a client.

*Claude's job:* Generate ideas that improve the discovery call experience. Pre-call prep materials, call frameworks, post-call follow-up sequences, proposal templates, "what to expect" content that reduces friction.

**Stage 6: Proposal Review**
The client has received a proposal and is making their decision. They may be comparing multiple coaches or consultants, discussing with a partner or team, or wrestling with the investment. Price sensitivity is highest here.

*Claude's job:* Generate ideas that help close during the proposal phase. Proposal presentation improvements, follow-up timing, case studies that address ROI concerns, handling the "I need to think about it" conversation, payment plan options.

### REVENUE GROWTH (Stage 7)

**Stage 7: Engagement Start**
The client has signed and the work begins. The onboarding experience sets the tone for the entire engagement. This is also the moment to establish expectations and introduce additional services.

*Claude's job:* Generate ideas that maximize engagement value at the start. Welcome sequences, onboarding packages, session prep templates, "while we're starting" conversations about group programs or additional services.

### RETENTION AND REFERRALS (Stages 8-10)

**Stage 8: Active Engagement**
The client is in the middle of the engagement. Communication, progress tracking, and the quality of the work determine whether they'll become a long-term advocate. Most client churn in coaching happens when momentum stalls.

*Claude's job:* Generate ideas that improve the client experience during the engagement. Progress milestone celebrations, mid-point check-ins, session recap emails, resource sharing, keeping momentum alive.

**Stage 9: Results and Completion**
The engagement is wrapping up. The final sessions, the reflection on progress, and the transition plan determine the lasting impression. This is the highest-leverage moment for generating testimonials and referrals.

*Claude's job:* Generate ideas that turn completed engagements into marketing assets. Testimonial request timing and templates, case study creation, results documentation, celebration moments, "what's next" conversations.

**Stage 10: Referral and Renewal**
The engagement is complete and the client is either an active promoter or just... done. Referral programs, periodic check-ins, and staying top-of-mind turn past clients into a reliable source of new business.

*Claude's job:* Generate ideas that activate the referral network. Referral incentive programs, alumni communities, periodic value-add check-ins, anniversary celebrations, "I'm opening spots" notifications, JV partnerships with complementary practitioners.

---

## Idea Generation Protocol

When generating growth ideas for a specific coaching or consulting practice:

1. **Read the practice's context first:** offers.md (services), persona.md (ideal client), brand-voice.md (communication style), and marketing channels from progress.md.

2. **Walk through all 10 stages.** For each stage, ask: "Given this practice's services, ideal client, and current channels, what specific action would move the needle here?" Skip stages that don't apply, but check every one.

3. **Generate 12-20 ideas.** Each idea must:
   - Reference the practice's actual services, methodology, or client type by name
   - Be specific enough that the user can start on it this week
   - Include a brief "why this matters for your practice" rationale
   - Match the practice's current channel capabilities (don't suggest podcast guesting if they've never been on a podcast, but DO suggest starting a podcast pitch campaign if it's appropriate)

4. **Organize by the 4 objectives** (Client Acquisition, Lead Conversion, Revenue Growth, Retention and Referrals) with at least 2 ideas per objective.

5. **Match the practice pattern.** Use the patterns below to weight suggestions appropriately. A solo life coach gets different ideas than a boutique consulting firm.

6. **Include a mix of:**
   - Quick wins (can do this week)
   - Medium projects (1-2 weeks)
   - Bigger initiatives (ongoing systems)

---

## Coaching & Consulting Practice Patterns

When generating ideas, match the practice to the closest pattern and weight suggestions accordingly.

### Pattern 1: Solo Coach (Life/Wellness)
Life coaches, health coaches, relationship coaches, mindset coaches. Clients are individuals seeking personal transformation. Marketing is personal-brand-heavy and relationship-driven. Testimonials and before/after stories are everything.

**Key channels:** Instagram, Facebook groups, referrals, workshops, webinars, podcast guesting
**Key content:** Transformation stories, motivational posts, free assessments, mini-workshops, behind-the-scenes of coaching sessions (anonymized)
**Key metrics:** Discovery calls booked, conversion rate, client retention, testimonial count, email list size

### Pattern 2: Executive/Leadership Coach
Executive coaches, leadership development coaches, C-suite advisors. Clients are professionals funded by their employer or making a significant personal investment. Credentialing (ICF), corporate experience, and thought leadership matter. Sales cycles are longer.

**Key channels:** LinkedIn (primary), speaking engagements, corporate referrals, HR partnerships, professional associations
**Key content:** Thought leadership articles, frameworks, research-backed insights, case studies (anonymized), keynote clips, assessment tools
**Key metrics:** Corporate contracts signed, speaking engagements, LinkedIn engagement rate, referral rate from HR/talent

### Pattern 3: Business/Growth Coach
Business coaches, growth coaches, revenue coaches, entrepreneur coaches. Clients are business owners who want to grow revenue, build systems, or escape the founder trap. Results-oriented, often uses group formats (masterminds, cohorts).

**Key channels:** LinkedIn, Facebook groups, webinars, podcasts (both guesting and hosting), referral partnerships, affiliate programs
**Key content:** Revenue-focused case studies, tactical how-to content, "this is what I'd do if I were you" posts, client spotlight interviews, group program launches
**Key metrics:** Revenue per client, group program fill rate, referral rate, lead magnet conversion, webinar attendance

### Pattern 4: Solo Consultant
Independent management consultants, strategy consultants, marketing consultants, HR consultants, IT consultants. Clients are businesses buying expertise for a specific project or ongoing advisory. Credibility comes from experience and results, not certifications.

**Key channels:** LinkedIn, referral network (primary), industry conferences, professional associations, content marketing
**Key content:** Industry analysis, case studies, methodology explanations, opinion pieces on trends, "lessons from the field" posts
**Key metrics:** Proposal win rate, average engagement value, referral rate, repeat client rate, utilization rate

### Pattern 5: Boutique Consulting Firm
Small consulting firms (2-15 people) with specialized focus. Clients are mid-market companies or specific industries. Has team members, processes, and potentially junior consultants. Brand is the firm, not just the founder.

**Key channels:** LinkedIn (firm + personal brands), industry events, RFP networks, referral partnerships, thought leadership publications
**Key content:** Firm-branded case studies, team expertise showcases, industry reports, white papers, webinar series, client ROI documentation
**Key metrics:** Pipeline value, proposal win rate, revenue per consultant, client retention, brand awareness in target industry

### Pattern 6: Group Program / Mastermind Creator
Coaches or consultants whose primary revenue comes from group programs, masterminds, cohort-based courses, or membership communities. Scalable model with launch cycles and community dynamics.

**Key channels:** Email list (primary), webinars, social media (Instagram, LinkedIn, Facebook), podcast, affiliate partnerships, JV launches
**Key content:** Launch content (open/close enrollment), student/member spotlights, behind-the-scenes of the program, free training as lead magnets, waitlist campaigns
**Key metrics:** Launch revenue, fill rate per cohort, member retention, LTV per member, email list size, webinar conversion rate
