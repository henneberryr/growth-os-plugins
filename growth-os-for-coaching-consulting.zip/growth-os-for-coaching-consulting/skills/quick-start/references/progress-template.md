# Growth OS for Coaching & Consulting -- Quick Start Progress

> This file tracks your setup progress across sessions. Claude reads it at the start of every session to know where you left off.

Started: [DATE]
Last updated: [DATE]

---

## Setup Info

- **User name:** [NAME]
- **Practice name:** [PRACTICE_NAME]
- **Practice type:** [coaching / consulting / both]
- **Source context:** [own_practice / aspirational_practice]
- **Aspirational practice (if applicable):** [PRACTICE_NAME_OR_N/A]
- **Setup mode:** [speed / precision]
- **Explain mode:** [transparent / just_do_it]

---

## Tier 1: Core Setup (Required)

- [ ] **Getting to Know Your Practice**
  - [ ] Preferences set (setup mode + explain mode)
  - [ ] Website crawled
  - [ ] LinkedIn profile discovered
  - [ ] Social profiles discovered
  - [ ] Podcast / speaking appearances discovered
  - [ ] Assets uploaded and processed
  - [ ] Marketing channels recorded
- [ ] **Mapping Your Services** -- Services, engagements, pricing approach, credentials (`core/offers.md`)
- [ ] **Defining Your Ideal Client** -- Ideal client with pain/pleasure quotes (`core/persona.md`)
- [ ] **Capturing Your Voice** -- Writing style guide from sample or assets (`core/brand-voice.md`)
- [ ] **Building Your Daily Gameplan** -- Personalized daily briefing with LinkedIn check and discovery call prep (`routines/morning-routine.md`)
  - [ ] Scheduled via `create_scheduled_task` (time: [TIME], days: [DAYS])
- [ ] **Wiring It All Together** -- CLAUDE.md operational guide ties it all together
- [ ] **Growth Ideas for Your Practice** -- Growth ideas generated, favorites selected, task tracking set up
  - [ ] Growth ideas generated and presented
  - [ ] User selected favorites
  - [ ] First workflow built (if applicable)
  - [ ] Task tracking set up (format: [checklist/objective/external])
  - [ ] TASKS.md created and seeded
  - [ ] /tasks slash command created
- [ ] **Quick Start Complete** -- All Tier 1 items finished

## Tier 2: Enhancements (Optional)

- [ ] **Practice Info** -- Full practice context with credentials, methodology, capacity (`core/business-info.md`)
- [ ] **Brand Design** -- Visual identity guide with photography guidelines (`core/brand-design.md`)
- [ ] **Content Rules** -- Global writing standards with FTC/testimonial compliance rules (`core/content-rules.md`)

---

## Asset Inventory

Track what was collected during intake so later phases can reference it.

| Asset | Source | Notes |
|---|---|---|
| Website crawl | [URL] | [what was found] |
| LinkedIn profile | [URL or N/A] | [posts, articles, engagement] |
| Instagram | [URL or N/A] | [what was found] |
| YouTube | [URL or N/A] | [what was found] |
| Facebook | [URL or N/A] | [what was found] |
| Podcast appearances | [URLs or N/A] | [episodes, topics] |
| Speaking profile | [URL or N/A] | [events, topics] |
| ICF / directory listing | [URL or N/A] | [profile details] |
| [uploaded file 1] | User upload | [what it contained] |
| [uploaded file 2] | User upload | [what it contained] |

---

## Marketing Channels & Tactics

Track every marketing channel and tactic discovered during setup, whether from the website crawl, platform discovery, uploaded assets, or conversation. Even if Claude cannot access the platform, record that the practice uses it. This feeds into workflow suggestions (Phase 7) and the CLAUDE.md.

| Channel / Tactic | Source | Notes |
|---|---|---|
| [e.g., LinkedIn] | Website crawl | [profile link, post frequency] |
| [e.g., Podcast guesting] | User mentioned | [6-8 appearances per year] |
| [e.g., Speaking engagements] | Website crawl | [speaking page found] |
| [e.g., Email newsletter] | Website crawl | [ConvertKit opt-in found] |
| [e.g., Referral network] | User mentioned | [informal, past client referrals] |

---

## Growth Ideas (from Phase 7)

The user selected these ideas from the growth ideas list. Others are saved in `growth-ideas.md` for future reference.

| # | Idea | Objective | Status |
|---|------|-----------|--------|
| [N] | [Idea title] | [Client Acquisition/Lead Conversion/Revenue Growth/Retention and Referrals] | [Selected / Workflow built / Task created] |

---

## Session Log

| Date | Steps Completed | Status | Notes |
|---|---|---|---|
| [DATE] | [e.g., Steps 1-3] | [In Progress / Complete] | [What happened, any items deferred] |
