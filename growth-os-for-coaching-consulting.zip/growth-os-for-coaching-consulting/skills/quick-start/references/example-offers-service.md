# Services & Pricing -- Catalyst Coaching

> This document is the reference Claude reads whenever it needs to understand what the practice offers, who it serves, and how to position it. Keep it updated when services or pricing change.

Last updated: March 2026

---

## Practice Overview

**Catalyst Coaching** is a solo executive and leadership coaching practice run by Rachel Torres. Based in Austin, TX, serving clients nationwide via Zoom. Specializes in helping mid-level managers and emerging leaders break through career plateaus, develop executive presence, and transition into senior leadership roles.

**Credentials:** ICF Professional Certified Coach (PCC), 800+ coaching hours. Former VP of Operations at a Fortune 500 company with 15 years of corporate leadership experience.

**Methodology:** The Catalyst Framework -- a 6-phase process that moves clients from clarity (what do I actually want?) through capability (what skills do I need?) to confidence (how do I show up differently?). Combines evidence-based coaching techniques with practical leadership tools.

---

## Signature Offer: Executive Coaching Engagement

**What it is:** A 6-month 1-on-1 executive coaching engagement designed for mid-level leaders ready to step into senior roles.

**Who it's for:** Directors, senior managers, and VPs at companies with 100-5,000 employees who are high performers but feel stuck at their current level.

**Pricing:** $12,000 for the full engagement (or 6 monthly payments of $2,200)

**What's included:**
- Intake assessment (Catalyst Leadership Assessment + 360 feedback review)
- 24 coaching sessions (twice monthly, 60 minutes each)
- Unlimited Voxer/email support between sessions
- Personalized leadership development plan
- Mid-point progress review with revised goals
- Completion session with 12-month forward roadmap

**Positioning:** "This isn't a motivational pep talk. It's a structured process for becoming the leader your team needs you to be. You'll leave with a clear roadmap, new capabilities, and the confidence to go after the role you've been circling."

---

## Secondary Offer: Leadership Accelerator (Group Program)

**What it is:** A 12-week group coaching program for emerging leaders (cohort of 8-12 people).

**Who it's for:** High-potential individual contributors and new managers who want to develop leadership skills before they're in the big seat. Also a good fit for companies investing in leadership pipeline development.

**Pricing:** $3,500 per participant (corporate rates available for 3+ participants from the same company)

**What's included:**
- 12 weekly group coaching sessions (90 minutes)
- Catalyst Leadership Assessment
- Peer coaching triads (small group accountability)
- Leadership toolkit (templates, frameworks, exercises)
- Private community for the cohort
- One 1-on-1 session with Rachel

**Positioning:** "The skills that got you promoted won't get you promoted again. This is where you build the leadership toolkit for the next level." Run twice per year (spring and fall cohorts).

---

## Entry-Point Offer: VIP Strategy Day

**What it is:** A single-day intensive (virtual or in-person) for leaders who need clarity and a plan fast.

**Who it's for:** Leaders facing a major transition: new role, reorganization, career crossroads, or preparing for a big presentation/pitch.

**Pricing:** $2,500

**What's included:**
- Pre-day questionnaire and assessment review
- Full-day session (4 hours of focused coaching, working lunch)
- Detailed action plan delivered within 48 hours
- Two 30-minute follow-up calls over the next month

**Positioning:** "When you need a breakthrough this month, not a 6-month program."

---

## Free Offer (Lead Generation)

### Free Leadership Assessment

**What it is:** A 15-minute self-assessment that evaluates leadership presence across 6 dimensions (strategic thinking, communication, influence, decision-making, team development, self-management). Delivered as a PDF with a personalized results summary.

**Who it's for:** Any leader who wants to understand their strengths and growth edges. Leads to a discovery call invitation.

**Positioning:** "Find out where you stand as a leader in 15 minutes. No fluff, no generic advice. Your actual strengths and the one thing holding you back." About 30% of assessment takers book a discovery call.

---

### Discovery Call

**What it is:** A free 30-minute call to explore whether coaching is the right fit. Rachel diagnoses the core challenge, shares how she'd approach it, and makes a recommendation (which is not always "hire me").

**Positioning:** "No sales pitch. Just a real conversation about where you are and what it would take to get where you want to go." About 50% of discovery calls convert to a paid engagement.

---

## Offer Hierarchy

```
Free Leadership Assessment -> Discovery Call -> VIP Strategy Day ($2,500) or Executive Coaching ($12,000) or Leadership Accelerator ($3,500)
```

The assessment is the primary lead magnet. Discovery calls convert to either the VIP Day (for urgent needs) or the full coaching engagement (for sustained development). The Leadership Accelerator fills via corporate referrals and alumni of individual coaching. All content should ultimately build trust and demonstrate Rachel's coaching approach so the discovery call feels like a natural next step.

---

## Key Metrics to Reference

- Active 1-on-1 coaching clients: 12 (capacity: 15)
- Leadership Accelerator cohort size: 10 per cohort, 2x/year
- Discovery calls per month: 8-12
- Discovery call conversion rate: 50%
- Average client engagement length: 7 months (many extend beyond the initial 6)
- Client re-engagement rate: 25% (return for a second engagement within 2 years)
- Referral rate: 60% of new clients come from past client referrals
- LinkedIn followers: 8,400
- Email list: 2,100
