# Services & Pricing -- Meridian Consulting

> This document is the reference Claude reads whenever it needs to understand what the firm offers, who it serves, and how to position it. Keep it updated when services or pricing change.

Last updated: March 2026

---

## Firm Overview

**Meridian Consulting** is a boutique operational efficiency consulting firm based in Charlotte, NC, serving clients across the Southeast. Founded by James Park. Specializes in helping small and mid-sized businesses ($1M-$10M revenue) streamline operations, build scalable systems, and break through the founder bottleneck.

**Team:** James (founder, lead consultant), two senior consultants, one operations analyst.

**Methodology:** The Meridian Operating System -- a proprietary diagnostic and implementation framework that maps a company's people, process, and technology against growth stage requirements. Identifies the 3-5 constraints holding the business back, then builds the systems to remove them.

---

## Service Tier 1: Operational Diagnostic

**What it is:** A comprehensive assessment of a company's operations, systems, team structure, and growth constraints. Delivered as a detailed report with prioritized recommendations.

**Who it's for:** Business owners who know something is broken but can't pinpoint what. Often triggered by a growth plateau, rising overhead, or the founder spending 70+ hours a week in the business.

**Pricing:** $7,500

**What's included:**
- Discovery interviews with founder, leadership team, and key employees
- Process mapping of core workflows (sales, fulfillment, finance, hiring)
- Technology audit (tools, integrations, data flow)
- Organizational structure assessment
- Prioritized constraint report with recommended initiatives
- 90-minute presentation of findings and recommendations

**Positioning:** "Before you hire another person, buy another tool, or launch another initiative, find out what's actually holding you back." The diagnostic often reveals that the solution is different from what the owner assumed. About 70% of diagnostic clients proceed to an implementation engagement.

---

## Service Tier 2: Implementation Engagement (90 Days)

**What it is:** Hands-on implementation of the top 3-5 priorities identified in the diagnostic. Meridian's team works alongside the client's team to build the systems, document the processes, and train the people.

**Who it's for:** Companies that have completed the diagnostic (or an equivalent assessment) and are ready to execute.

**Pricing:** $25,000-$50,000 (based on scope and team involvement)

**What's included:**
- Dedicated Meridian consultant on-site 2 days/week (or virtual equivalent)
- Process design, documentation, and SOPs for priority areas
- Technology selection and configuration (if needed)
- Team training and change management
- Weekly progress reports
- 30-day post-implementation support

**Positioning:** "We don't just tell you what to fix. We build the systems with you." Implementation is the highest-revenue service and the primary value driver.

---

## Service Tier 3: Monthly Advisory Retainer

**What it is:** Ongoing strategic advisory for companies that have completed the implementation phase and want continued access to Meridian's expertise.

**Who it's for:** Owners and leadership teams navigating growth, hiring decisions, new market entry, or ongoing operational challenges.

**Pricing:**
- **Standard:** $3,500/month (2 advisory calls/month, email support, quarterly operations review)
- **Premium:** $6,000/month (weekly advisory calls, Slack access, quarterly on-site strategy day)

**Positioning:** "You don't need a full-time COO. You need a strategic partner who knows your business and is one call away." Retainers provide recurring revenue and keep Meridian embedded in the client's growth.

---

## Service Tier 4: Strategic Planning Workshops

**What it is:** Facilitated half-day or full-day planning sessions for leadership teams. Annual planning, quarterly resets, or team alignment workshops.

**Who it's for:** Companies at any stage, but especially those going through transitions (growth, new leadership, market shift).

**Pricing:** $5,000 (half-day) / $8,000 (full-day)

**What's included:**
- Pre-workshop discovery calls with key stakeholders
- Custom agenda and facilitation materials
- Facilitated session with structured exercises
- Post-workshop summary with action items and accountability plan

**Positioning:** "Get your entire leadership team aligned on the same page, with clear priorities and an accountability structure, in one day."

---

## Free Offer (Lead Generation)

### Free Growth Constraint Assessment

**What it is:** A 20-question online self-assessment that identifies the most likely operational constraint holding a business back (founder bottleneck, process chaos, team misalignment, technology gaps, or financial visibility). Delivers a personalized one-page results summary with one actionable recommendation.

**Who it's for:** Business owners at $1M-$10M who feel the strain of growth but aren't sure where to focus.

**Positioning:** "Find out what's really capping your growth in 10 minutes. One constraint. One recommendation. Zero sales pressure." About 25% of assessment completers book a free consultation.

---

### Free Consultation

**What it is:** A free 45-minute call where James reviews the assessment results, asks deeper diagnostic questions, and makes a candid recommendation (which might be "you don't need us, here's what to do on your own").

**Positioning:** "A real conversation about your business, not a sales presentation." About 60% of consultations convert to a diagnostic engagement.

---

## Service Hierarchy

```
Free Assessment -> Free Consultation -> Operational Diagnostic ($7,500) -> Implementation ($25K-$50K) -> Monthly Retainer ($3,500-$6,000/mo)
Strategic Planning Workshops ($5K-$8K) serve as entry points for new relationships and ongoing touchpoints for existing clients.
```

The assessment and consultation are the primary lead generation tools. The diagnostic builds trust and demonstrates Meridian's methodology. Implementation is the core revenue driver. Retainers provide recurring revenue and keep the relationship active.

---

## Key Metrics to Reference

- Active retainer clients: 8
- Implementation projects per year: 10-14
- Diagnostic assessments per year: 20-25
- Diagnostic-to-implementation conversion: 70%
- Average implementation engagement: $35,000
- Annual revenue: $1.2M
- Repeat client rate: 55%
- Referral rate: 50% of new diagnostic clients come from referrals
- Client industries: professional services, light manufacturing, healthcare practices, technology services
