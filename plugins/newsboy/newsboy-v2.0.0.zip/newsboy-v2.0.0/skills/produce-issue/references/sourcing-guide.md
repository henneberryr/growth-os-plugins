# Newsboy Sourcing Guide

> How to find, evaluate, and present great source material for newsletter blocks.

**Version**: 1.0.0
**Part of**: Newsboy plugin by theCLICK

---

## The Job of Sourcing

Sourcing isn't just "find stuff." It's editorial curation — you're deciding what deserves your reader's attention. The quality of the sourcing stage determines the ceiling for the entire issue. Great sources produce great blocks. Thin sources produce filler.

---

## Source Tier Standards

Every claim in the newsletter must be traceable to a credible source. Sources are tiered. Higher tiers are always preferred.

> These tiers use business/tech media as examples. Adapt for your niche — the principle is the same across industries: primary sources and major established outlets (Tier 1), credible niche publications (Tier 2), and unverified or low-credibility sources (Tier 3, always avoid).

### Tier 1 — Always acceptable
- **Primary sources:** Official company blogs, press releases, SEC filings, published research from the organization itself (e.g., Meta's blog, Google Cloud blog, OpenAI announcements)
- **Major news outlets:** Reuters, Bloomberg, WSJ, NYT, Financial Times, AP, BBC
- **Top-tier tech/business press:** TechCrunch, Wired, The Verge, Ars Technica, MIT Technology Review, Fortune, Forbes
- **Respected trade publications:** Marketing Dive, Digiday, AdWeek, Ad Age, Search Engine Land, MarTech, The Information

### Tier 2 — Acceptable with a Tier 1 cross-reference
- **Industry blogs and analyst reports:** HubSpot, Jasper, Supermetrics, Klaviyo (when publishing their own data)
- **Respected niche outlets:** Social Media Today, Content Marketing Institute, Search Engine Journal, Marketing Brew, Retail Dive, Consumer Goods Technology
- **Credible tech blogs:** 404 Media, Futurism, Interesting Engineering, Decrypt

### Tier 3 — Not acceptable as a sole source
- Aggregator sites, SEO content farms, no-name blogs, press release syndication sites, anything that looks like it was written to rank rather than to inform
- If a stat only appears at Tier 3, it doesn't make the newsletter. Period.

### Tier Rules
- **News Stories and Data Points** must link to Tier 1 sources. If the best available source is Tier 2, a Tier 1 cross-reference is required.
- **Custom/wild card blocks** (humor, weird stories) may link to Tier 2 sources, but must be verified by at least 2 independent sources.
- **Trivia** source must be verifiable. Tier 1 or Tier 2 acceptable.
- **During fact-check,** if a claim's source falls below these standards, the source must be upgraded or the claim removed.
- **In the research document,** tag each candidate's source tier so the user can see source quality at a glance.

---

## "Find It" Mode — External Sourcing

### Search Strategy

For each "find it" block, run **2-3 targeted searches** using different angles:

1. **Niche-specific search**: Use the block's Source section keywords + the newsletter's niche. Example for a marketing newsletter's News Story block: `"small business marketing" news 2026`

2. **Source-specific search**: Search the specific sites listed in the block's skill file. Example: `site:marketingbrew.com` or `site:hubspot.com/blog`

3. **Broader angle search**: Search for the underlying topic without niche keywords to catch stories from adjacent industries. Example: `"AI marketing tools" small business`

### When Results Are Thin

If a niche is narrow or the news cycle is quiet:

- **Expand the time window.** Look back 2-3 weeks instead of just this week. A story from 10 days ago that the reader hasn't seen is better than a weak story from yesterday.
- **Look for trend pieces** instead of breaking news. "State of X" reports, industry surveys, and data releases are always available and often more valuable than daily headlines.
- **Check adjacent niches.** A story about e-commerce marketing might be relevant to a general small business audience. Adapt the angle.
- **Use the "prompt me" fallback.** If external sourcing genuinely can't produce 3 quality candidates, tell the user: "The news is quiet this week for [topic]. Want to write something original instead?" Switch the block to "prompt me" mode for this issue.

### When Nothing Works

If you've expanded the time window, checked adjacent niches, and still can't find 3 quality candidates:

1. **Ask the user for direction.** "The news is quiet for [topic] this week. Is there a different angle you'd like to cover, or a story you've seen that I should look at?"
2. **Offer to switch modes.** "Want to write something original instead? I can prompt you with a question for this block."
3. **Offer to skip.** "We can skip [block name] for this issue and come back next time. No issue needs every block every time."
4. **Never present thin candidates.** If you can't find quality, say so. Presenting filler trains the user to expect low standards.

### Evaluating Candidates

Score every candidate against these four criteria before presenting it:

**Relevance** — Does this matter to this specific audience? A story about enterprise AI adoption is not relevant to a solopreneur audience, even if it's interesting. The block's selection filter (from the skill file) is the first test. If it doesn't pass the filter, don't present it.

**Freshness** — Is this recent enough to feel current? For news blocks, aim for content from the past 7-14 days. For resource roundups and tool spotlights, freshness matters less — a great tool is great regardless of when it was reviewed.

**Actionability** — Can the reader DO something with this? The best newsletter content isn't just informative — it gives the reader a move to make. Prioritize stories that have a clear "so what" for the audience.

**Credibility** — Is the source outlet trustworthy? Prefer primary sources (the company's own announcement, the original research paper) over secondhand reporting. If you can't verify a claim, flag it as unverified when presenting candidates.

### Presenting Candidates

For each "find it" block, present **3-5 story candidates** in a table:

| # | Headline | Source Outlet | Date | Why it fits |
|---|----------|--------|------|-------------|
| 1 | ... | ... | ... | One sentence connecting it to the audience |

The "Why it fits" column is critical — it's your editorial judgment. Don't just describe the story; explain why this audience should care about it.

**Lead with your recommendation.** Bold or star the candidate you think is strongest: "My pick is #2 — it's the most actionable and ties in well with [another block in this issue]."

### Avoiding Repetition

Before presenting candidates, check the issue log for:
- Stories from the same source featured in the last 3 issues
- Topics covered in the last 2 issues (even from different sources)
- The same company or product featured recently

Variety builds trust. If the reader keeps seeing HubSpot articles, they'll wonder if you only read one blog.

---

## "Prompt Me" Mode — Drawing Out the User's Ideas

### The Art of the Good Prompt

The block's skill file contains a default prompt. Use it as a starting point, but adapt it to the current issue. Good prompts are:

- **Specific, not vague.** "What happened in your business this week?" is too open. "What's one thing a client said to you recently that surprised you?" gives the brain something to grab onto.
- **Multiple-choice when possible.** Offer 3-4 angles: "A tough decision you made, something that didn't go as planned, a customer interaction that surprised you, or something you're excited about."
- **Connected to the issue.** If you've already sourced a news story about AI tools, prompt the personal block with: "This issue features a story about AI in marketing. Have you been experimenting with any AI tools? What's your take?"

### When the User Is Stuck

If the user says "I don't know" or "nothing comes to mind":

1. **Try a different angle.** Instead of "what happened this week?", ask "what's something you've been thinking about lately that your audience would find interesting?"
2. **Offer to skip.** "No worries — we can skip [block name] for this issue and come back to it next time."
3. **Suggest a topic from context.** If you've already sourced other blocks, suggest a connection: "Your news story this issue is about [topic]. Want to share your own experience with that?"

---

## "Here's Something" Mode — Working with User-Provided Material

### Material Types and How to Handle Them

**Voice memo transcripts**: These are messy — full of filler words, half-finished thoughts, and tangents. Your job:
- Extract the 1-2 core ideas buried in the ramble
- Identify the strongest narrative thread
- Preserve the user's natural phrasing and vocabulary (this IS their voice)
- Discard everything that doesn't serve the block's purpose

**Social media posts or comments**: These are compressed thoughts — tight but shallow. Your job:
- Expand the core idea to newsletter depth (a tweet becomes 3 paragraphs)
- Add the context and reasoning that got cut for social media brevity
- Ask the user: "You wrote [post]. What's the backstory? What would you add if you had more space?"

**Client emails or conversations**: These contain real-world proof points. Your job:
- Generalize the specific case into a lesson others can learn from
- Anonymize unless the user explicitly says to name the client
- Find the "so what" — what does this interaction teach the reader?

**Notes, journal entries, or drafts**: These are raw thinking. Your job:
- Identify the strongest idea (there may be several — pick one per block)
- Structure it: setup → tension/insight → takeaway
- Ask the user which direction to take if the material has multiple angles

### The Transformation Principle

The user has already done the hard work — they've had the thought, the experience, the insight. Claude's job in "here's something" mode is NOT to rethink their material. It's to:

1. **Find the thread** — What's the core idea?
2. **Build the structure** — Arrange it according to the block's Format section
3. **Polish the voice** — Match the newsletter's vibe while preserving the user's natural patterns
4. **Add context if needed** — The user knows their audience; sometimes Claude needs to make the connection explicit for readers

---

## Cross-Block Sourcing

### Think in Themes

Before sourcing individual blocks, scan the lineup and ask: "Is there a theme that could connect 2-3 blocks this issue?"

A themed issue is more cohesive and memorable. If the news story is about email marketing, the homework could be an email audit, and the behind the scenes could be about the user's own email strategy.

Don't force it. If the theme doesn't naturally emerge, that's fine — variety also works. But when a theme presents itself, lean into it.

### The Sourcing Pass

Source ALL blocks before drafting ANY. This lets you:
- Spot thematic connections across blocks
- Avoid redundancy (two blocks accidentally covering the same angle)
- Make informed suggestions for "prompt me" blocks based on what "find it" blocks already found

---

## Image Sourcing

Images add personality and visual breaks to newsletter blocks. During production, provide descriptive image placeholders for every block that benefits from a visual element.

### What to Recommend

For each image placeholder, suggest what type of image would work:
- **News stories**: A relevant visual that sets the tone — could be a screenshot, a reaction GIF, a stock photo, or a meme
- **Data points**: The number itself IS the visual. No image needed unless the stat benefits from a chart or graph
- **Trivia**: Usually doesn't need an image — the question format provides visual interest
- **Behind the scenes / personal blocks**: A real photo from the creator works best here
- **Wild card / humor blocks**: This is where playful, unexpected images shine

### Image Placeholders

Use this format in drafts: `[Image: brief description of what would work here]`

During assembly, collect all image placeholders into the production notes so the user can fill them before sending. The user chooses their own images — Claude recommends the type and vibe, not specific files.

---

*Reference document for the Newsboy plugin's produce-issue skill. Read at the start of every production cycle alongside the newsletter philosophy.*
