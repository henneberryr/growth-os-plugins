---
name: produce-issue
description: >
  This skill should be used when the user wants to "produce a newsletter issue",
  "write this week's newsletter", "create a new issue", "make my newsletter",
  "let's produce an issue", or "run newsletter production". Also triggers
  on the /newsboy-produce command. It reads the user's newsletter configuration
  and runs the seven-stage production workflow to output a publish-ready document.
version: 2.0.0
---

# Produce Issue

Produce a single newsletter issue from start to finish. Read the user's configuration, run the seven-stage production workflow, and output a polished, publish-ready markdown document.

## Before Anything Else: Read Reference Files and Configuration

### 1. Read Reference Files

Read these reference files at the start of every production cycle:

- `${CLAUDE_PLUGIN_ROOT}/references/newsletter-philosophy.md` — editorial judgment foundation. Pay particular attention to: relevance over recency, actionability, avoiding the echo chamber, depth over breadth.

- `${CLAUDE_PLUGIN_ROOT}/references/block-template-library.md` — fully written examples of every block type. Use these as the quality standard when drafting. Match the depth, voice quality, and structural precision shown in the examples.

- `${CLAUDE_PLUGIN_ROOT}/skills/produce-issue/references/sourcing-guide.md` — how to find, evaluate, and present source material. Covers search strategy, candidate evaluation, handling thin niches, "here's something" material types, and cross-block thematic sourcing.

### 2. Load Configuration Files

Use Glob to find and read all configuration files from the user's workspace:

- **`**/newsboy/newsletter-identity.md`** — Name, audience, niche, vibe, cadence, promise, content orientation, voice notes. Reference throughout production for voice, editorial, and audience decisions.

- **`**/newsboy/assembly-blueprint.md`** — Block order, opener format, closer format, transition style, subject line style, production mode, document format. The master production config.

- **`**/newsboy/blocks/*.md`** — One skill file per block. Each contains Source → Structure → Format → Polish instructions. Read ALL block files. Produce them in the order specified by the assembly blueprint.

- **`**/newsboy/issue-log.md`** (if it exists) — Previous issues, stories featured, dates. Check this to avoid repeating content and to find continuity opportunities. If it doesn't exist yet, this is the first issue.

If any required file is missing (identity, blueprint, or block files), stop and tell the user: "Your newsletter isn't fully set up yet. Run `/newsboy-setup` first."

**Note on file location:** The `newsboy/` folder may be at the workspace root or nested inside an organizational folder (e.g., `workflows/newsboy/`). All Glob patterns use `**/newsboy/` wildcards, so the plugin finds the files regardless of placement. When creating new files (issue subfolders, issue log), write them relative to wherever the existing `newsboy/` folder lives.

### 3. Review Previous Issue (Issue 2+)

If this is not the first issue, read the most recent issue's draft from `**/newsboy/issues/[latest]/draft.md`. This provides:
- **Voice calibration** — Match the tone and personality established in prior issues
- **Format reference** — See how blocks were structured and what worked
- **Content continuity** — Know what was recently covered to avoid repetition and find follow-up opportunities

This is especially valuable in the first 3–5 issues while the newsletter's voice is being established.

### 4. Determine Production Mode and Issue Number

Read the production mode from the assembly blueprint. The user can override at any time by saying "switch to express" or "switch to hands-on."

Determine the issue number: check the issue log for the highest issue number, or Glob `**/newsboy/issues/*/` for existing issue folders and increment. If neither exists, this is Issue 1. If reading a previous issue draft (from Step 3), compare its issue number to confirm you've found the latest.

Acknowledge at the start: "Producing [newsletter name] Issue [N] in [hands-on/express] mode. Let's go."

---

## First Issue Guidance

If this is Issue 1, apply these additional principles:

**Set the tone and coach them to invest in this issue.** "This is your first issue — and I want to be upfront: the best thing you can do right now is go slow. Take your time reviewing each block. Tell me what you like and what feels off. Every adjustment you make on this first issue gets baked into your setup, which means Issue 2 will be dramatically faster and smoother. Think of this first issue as building the machine — future issues are just running it."

**Reinforce this throughout production.** At natural pause points (after presenting source candidates, after the first block draft, during final review), gently remind them: "Take your time here — anything you want to change about how this works, tell me now. I'll update the instructions so it's automatic next time." or "The more feedback you give on this first issue, the less you'll need to give on the next one."

**Offer a lighter option.** If the lineup has 5+ blocks, suggest: "For your first issue, want to start with [N-1] blocks and add [dropped block] next time? Totally up to you."

**Extra voice attention.** With no production history to match, lean heavily on the identity doc's Vibe and Voice Notes fields. If no voice sample was provided during setup, pay close attention to how the user communicates during this production session — their chat messages reveal their natural voice.

**More checkpoints.** Even in express mode, add an extra pause after drafting the first block to confirm voice and tone: "Here's your first block — does this feel like your newsletter? If the voice is off, tell me now and I'll adjust everything before we keep going. This is the moment where one piece of feedback saves you ten corrections later."

---

## Issue Continuity

Before sourcing, check the issue log for continuity opportunities:

- **Homework follow-ups**: If the previous issue assigned homework, the opener or a block can reference it: "Last week I asked you to [X]. How'd it go?"
- **Prediction check-ins**: If a previous issue made a prediction, and you find news related to it during sourcing, call it out.
- **Series potential**: If the user's "prompt me" blocks keep touching the same theme, suggest a mini-series: "This is the third time you've talked about [topic] — want to make it a 3-part series?"
- **Subject line learning**: Note which subject line the user chose in the issue log. Over time, patterns emerge.

**Pattern recognition (3+ issues)**: After 3+ issues exist in the log, look for production patterns: blocks that consistently get skipped (consider removing or replacing them), topics that generate the most reader engagement (lean into them), voice adjustments that stick (update the identity doc). Surface one observation per production cycle — not a laundry list.

Don't force continuity. If nothing connects naturally, move on — variety also works.

---

## The Seven Production Stages

### How the Modes Differ

**Hands-on mode** — Pause after Source for user selections. Present each block draft individually for review. Present the assembled issue for final approval. More touchpoints, more control.

**Express mode** — Run Source, pause for the mandatory source selection checkpoint, then run Draft + Fact-Check + Voice Pass + Assemble back-to-back. Present the complete assembled issue for review. Fewer stops, faster.

**Both modes require two mandatory checkpoints:**
1. **Source selection** — The user picks which stories/topics/material to feature. Claude never decides what goes in the newsletter autonomously.
2. **Final review** — The user reads and approves the assembled issue before delivery. No auto-deliver.

---

## Stage 1: Source

Gather raw material for ALL blocks in one consolidated pass. Don't work through blocks one at a time — collect everything together, then present it together. Refer to the sourcing guide for detailed strategy.

### For "Find it" Blocks

For each block whose skill file specifies `Default mode: find it`:

1. Read the block's Source section for specific instructions (sites to scan, selection filters, relevance criteria)
2. Use WebSearch to find candidates following the sourcing guide's search strategy (niche-specific, source-specific, and broader angle searches)
3. Check the issue log to avoid repeating stories featured in recent issues
4. Compile 3-5 candidates per block, evaluating each for relevance, freshness, actionability, and credibility
5. Lead with your recommendation — bold or star the candidate you think is strongest

### For "Prompt me" Blocks

For each block whose skill file specifies `Default mode: prompt me`:

1. Read the block's Source section for the prompt or question to ask
2. Ask the user. Use the exact prompt from the skill file, or adapt it to connect to other blocks in this issue (see sourcing guide's cross-block thematic sourcing)
3. If the user is stuck, offer suggestion angles from the skill file, or connect to another block's topic

### For "Here's something" Blocks

For each block whose skill file specifies `Default mode: here's something`:

1. Ask: "Do you have anything you want to use for [block name]? A transcript, notes, a social post, a voice memo — anything works."
2. If the user provides material, handle it according to the sourcing guide's material type guidance:
   - **Voice memo transcripts**: Extract the 1-2 core ideas, preserve the user's natural phrasing, discard filler
   - **Social media posts**: Expand the compressed thought to newsletter depth, ask for the backstory
   - **Client emails/conversations**: Generalize the specific case, anonymize unless told otherwise
   - **Notes or drafts**: Identify the strongest single idea, ask the user to choose a direction if multiple angles exist
3. If the user doesn't have anything, fall back to "prompt me" mode: "No worries — let me ask you something instead."

### Present Source Candidates — MANDATORY CHECKPOINT #1

Create a comprehensive research document for all "find it" candidates and present all sourcing results in one consolidated view.

For **"find it" blocks**, create a detailed research document (`.md` file) saved to the issue subfolder with this structure for each candidate:

- **Headline and source** (with link)
- **Summary** (3-5 sentences)
- **Why [persona] cares** (2-3 sentences explaining relevance to your newsletter audience)
- **Date published**
- **Source tier** (tag: first-party, established, emerging, niche)

For **"Data Point" candidates** in research docs: the stat, full context (where it comes from, what it measures), source with link, and persona relevance (1-2 sentences).

For **"Trivia" candidates**: proposed clue, answer, and link to source.

Present a consolidated summary view:

```
## Source Candidates for [Newsletter Name] Issue [N]

### [Block Name] — [Block Type] (find it)
Research document created: [link to research.md]
★ My pick: [candidate title] — [one sentence why]

### [Block Name] — [Block Type] (prompt me)
Waiting for your input: [the prompt question]

### [Block Name] — [Block Type] (here's something)
Received: [brief summary of what the user provided]
Angle I'm seeing: [the narrative/takeaway you identified]
```

For "find it" blocks, the user MUST select which candidate to feature. For "prompt me" blocks, the user MUST provide raw material. For "here's something" blocks, confirm the angle before drafting.

After all selections are made, confirm: "Here's what we're working with for this issue: [Block 1] — [source summary], [Block 2] — [source summary]... Ready to draft?"

---

## Stage 2: Draft

Produce all blocks according to their individual skill files. Reference the block template library examples as the quality standard for each block type.

### For Each Block

Follow the block's skill file through Structure → Format → Polish:

1. **Structure** — Organize the raw material according to the block's Structure section. Identify the angle, key points, narrative arc, or action steps.

2. **Format** — Write the block following the exact format structure in the block's Format section. Every element listed should appear in the draft.

3. **Polish** — Apply voice and tone rules from BOTH the block's Polish section AND the newsletter identity's Vibe and Voice Notes fields. The block's Polish rules are specific; the identity's Vibe is the baseline. Check length targets. Run quality checks listed in the Polish section.

4. **Headline linking** — All News Story headlines and curated-content headlines must be hyperlinks to the primary source article. The headline IS the link.

5. **Image placeholders** — For blocks that include images, add descriptive placeholders: `[Image: brief description of what would work here]`. During assembly, collect all image placeholders into the production notes so the user can fill them before sending.

### Hands-on Mode: Block-by-Block Review

Present each drafted block individually, in assembly order. After each block:

- If the user approves → move to the next block
- If the user requests edits → revise and re-present
- If the user wants a different direction → rework from their new angle
- If the user wants to skip this block → note it as skipped for this issue, exclude from assembly

### Express Mode: Draft All, Hold for Fact-Check

Draft all blocks without stopping. Do not present individual blocks. Hold them for Stage 3 (Fact-Check).

---

## Stage 3: Fact-Check

Independently verify every stat, number, factual claim, name/title/company, date, and link against original sources. Do NOT trust the draft — go back to original sources using WebSearch and WebFetch.

Fact-checking targets external claims: statistics, numbers, company names, titles, dates, and source links. Personal stories, user-provided opinions, and original commentary from "prompt me" and "here's something" blocks are trusted as the author's own voice. If an author's personal block references an external fact (e.g., "I read that 73% of marketers..."), verify that specific claim.

### Fact-Check Protocol

Use a dedicated subagent (Agent tool) to run fact-checking:

1. **Review each block** — Scan for every factual claim: statistics, numbers, names, titles, company affiliations, dates, quotes, and links.

2. **Verify against sources** — For each claim, use WebSearch and WebFetch to independently verify it against the original source. Do not rely on the draft's cited source. During verification, confirm that all cited sources meet Tier 1 standards as defined in the sourcing guide. If a source falls below Tier 1, attempt to find a Tier 1 source for the same claim. If no Tier 1 source exists, flag the claim for the user.

3. **Produce a Fact-Check Report** — Create a report saved to the issue subfolder (`fact-check.md`) with:
   - ✅ **Verified** — Claim is accurate and source is live
   - ⚠️ **Flagged** — Claim is unclear, source is paywalled/outdated, or context is missing
   - ❌ **Failed** — Claim is inaccurate or source is dead

4. **Fix issues before the user sees it** — Any ⚠️ or ❌ items get corrected in the draft:
   - **✅ to ✅**: No changes needed
   - **⚠️**: Rewrite the claim with verified context, or remove if it can't be verified
   - **❌**: Remove the claim or rewrite entirely with accurate information

5. **Dead sources and paywalled content** — If a source is inaccessible and the claim can't be verified independently, remove or rewrite the claim.

### Hands-on Mode: Fact-Check After Block Review

Fact-checking runs after all blocks are drafted and reviewed. Present fact-check results to the user: "Fact-check complete. [N] items verified, [M] items flagged and fixed. Here are the corrected blocks." Then proceed to the Voice Pass.

### Express Mode: Fact-Check Before Assembly

Fact-checking runs automatically after drafting. The Voice Pass runs immediately after fact-checking. The draft presented to the user in Stage 5 is already fact-checked and voice-polished.

---

## Stage 4: Voice Pass

Rewrite every block through the user's brand voice. The facts are locked from Stage 3. This stage is purely about voice, tone, and personality.

### Why This Is a Dedicated Pass

Drafting (Stage 2) focuses on getting the structure and information right. Fact-checking (Stage 3) focuses on accuracy and may rewrite passages for correctness. Neither stage is optimized for voice. Corrections from fact-check are especially prone to voice drift because they're written for precision, not personality. The Voice Pass fixes all of this in one sweep.

### Voice Pass Protocol

1. **Load voice sources.** Read the following in order of specificity (most specific wins):
   - The user's brand voice file if one exists in their workspace (Glob for `**/brand-voice*.md` or `**/core/brand-voice*.md`). This is the primary voice authority.
   - The newsletter identity's Vibe and Voice Notes fields (from `**/newsboy/newsletter-identity.md`, already loaded).
   - Each block's Polish section for block-specific voice rules.
   - The most recent previous issue draft (if it exists) as a calibration reference for how the voice has been applied in practice.

2. **Rewrite every block.** For each block in assembly order:
   - Read the block draft as it stands after fact-check corrections.
   - Rewrite for voice: sentence rhythm, vocabulary, tone, humor, formality, personality, signature moves. Apply the brand voice file's rules as the governing standard.
   - **Do not change facts, stats, names, links, dates, or any claim verified in Stage 3.** The information layer is frozen. Only the expression layer changes.
   - **Do not change the block's structure or format.** The elements defined in the block's Format section (headlines, bullet counts, section headers) stay intact. The Voice Pass rewrites the prose within those elements.
   - Match length targets from each block's Polish section. If a rewrite runs long, tighten the language rather than cutting content.

3. **Check for voice consistency across blocks.** After rewriting all blocks individually, read them back-to-back. The newsletter should feel like one person wrote all of it, not a patchwork. Adjust any block that feels tonally disconnected from the others.

4. **Flag voice ambiguity.** If the user has no brand voice file and provided no writing sample during Discovery (Voice Notes say "Voice will calibrate through production"), flag this once: "I don't have a brand voice reference yet, so I'm matching the vibe and tone from your newsletter identity. If anything sounds off, tell me and I'll dial it in. A writing sample would help a lot for future issues."

### Hands-on Mode

Present each voice-passed block alongside the pre-voice version so the user can see what changed: "Here's [block name] after the voice pass. I tightened the sentences, added [personality trait], and matched your [voice characteristic]. Compare with the previous version below if you want to see the diff."

After all blocks: "Voice pass complete. All [N] blocks are rewritten in your brand voice. Ready to assemble the full issue."

### Express Mode

Run the Voice Pass automatically after fact-check, without stopping. The assembled issue the user sees in Stage 5 is already voice-polished.

---

## Stage 5: Assemble

Combine all approved, fact-checked blocks into the full newsletter document.

### Assembly Steps

1. **Blocks** — Arrange all approved blocks in the order specified by the assembly blueprint. Separate blocks with horizontal rules. Each block opens with its section header.

2. **Opener** — Draft AFTER all blocks are finalized. Follow the blueprint's opener format. Reference 2-3 highlights from THIS issue. If continuity is relevant (homework follow-up, prediction check-in), weave it into the opener.

3. **Closer** — Follow this structure:
   - **Quick wrap** — One short line to close (e.g., "That's the week."). Do NOT restate or summarize the stories.
   - **Reply CTA** — Make a joke or playful reference to one of the stories to invite a reply. Keep it fun, not formal. Mix this up every issue.
   - **Sign-off** — Follow whatever the user configured in their assembly blueprint.
   - **Metadata** — Add social links and referral block if applicable. Add placeholder: `[Unsubscribe link — handled by email platform]`

4. **Subject lines** — Generate 3 options with preview text. Follow the blueprint's style. Subject lines should be **5-7 words max** — tight, punchy, curiosity-driven, no filler. Each option should take a different angle on the issue's content. If an option exceeds 7 words, cut it.

5. **Production notes** — Add to the top of the document using HTML comments (see Document Format below).

### Present for Final Review — MANDATORY CHECKPOINT #2

**Hands-on mode**: "Here's the complete issue assembled — opener, blocks, closer, and subject line options. Everything has been fact-checked and voice-passed. Take a look and let me know if anything needs adjustment."

**Express mode**: "Here's your complete issue — fact-checked and written in your brand voice. Read through and let me know what you'd like to change — I can adjust any block, the opener, closer, or subject lines."

Handle feedback: "Ship it" → deliver. Specific edits → revise and re-present. Larger rewrites → rework.

---

## Proactive Change Detection (All Stages)

**This applies throughout the entire production workflow, not just during review.**

When a user requests a change — to a block's format, to the voice, to how sourcing works, to subject line style, to anything — pay attention to whether the change is **issue-specific** or **permanent**.

**Issue-specific changes**: "Make this headline shorter" or "Use a different story for Block 2." These apply to this issue only. Execute them without updating configuration files.

**Permanent changes**: "I don't like how the closer works" or "The voice is too formal" or "I always want three bullet points instead of five" or "Don't use that kind of source." These should be baked into the setup files so they apply to every future issue.

**How to detect permanent changes:** Look for language that implies a general preference: "always," "never," "I don't like when," "from now on," "going forward," "can we make it so that." Also look for the user making the same correction twice — if they shortened the bullets last issue and they're shortening them again, that's a pattern.

**When you detect a permanent change, ask:**
"That sounds like something you'd want every issue, not just this one. Want me to update your [block config / assembly blueprint / voice notes] so this happens automatically from now on?"

If they say yes, make the update immediately — edit the relevant config file and confirm what you changed. If they say no, just apply it to this issue.

**Be proactive but not annoying.** Ask once per change. If the user is in the flow and making rapid edits, batch your config-update suggestions: "You made a few changes I think should be permanent — want me to update your setup so [X], [Y], and [Z] happen automatically?"

---

## Stage 6: Deliver

Output the finished newsletter and update the production log.

### Document Format

Write the finished issue as a markdown file:

```markdown
<!-- PRODUCTION NOTES — DELETE THIS SECTION BEFORE SENDING

Subject line options:
1. [Option 1] — Preview: [preview text]
2. [Option 2] — Preview: [preview text]
3. [Option 3] — Preview: [preview text]

Image placeholders to fill:
- [List each image placeholder and its location]

Notes: [Any flags — links to verify, facts to check, etc.]

END PRODUCTION NOTES -->

# [Newsletter Name] — Issue [NNN]

[Opener]

---

#### [CATEGORY LABEL]

## [Story Headline](https://source-link.com)

### Why It Matters

[Explanation of relevance]

---

#### [CATEGORY LABEL]

## [Story Headline](https://source-link.com)

### Why It Matters

[Explanation of relevance]

---

#### [Block Name Header]

[Block content]

---

[...remaining blocks...]

---

[Closer]
```

**Heading hierarchy:**
- **Category labels** (e.g., AD TECH, AI TOOLS): h4 (`####`)
- **Story headlines**: h2 (`##`), hyperlinked to source article
- **"Why It Matters"**: h3 (`###`)
- **Block headers for non-story blocks**: h4 (`####`)

### File Location

1. Use Glob to check `**/newsboy/issues/*/` for existing issue folders
2. Determine the next issue number (if `002/` is the latest, next is `003/`)
3. Create the issue subfolder: `newsboy/issues/NNN/` (zero-padded three digits)
4. Write files to the subfolder:
   - `newsboy/issues/NNN/draft.md` — Full newsletter draft (already fact-checked)
   - `newsboy/issues/NNN/research.md` — Source candidates from Stage 1
   - `newsboy/issues/NNN/fact-check.md` — Verification report from Stage 3

### Update the Issue Log

Append to `newsboy/issue-log.md` (create if it doesn't exist):

```markdown
## Issue [NNN] — [YYYY-MM-DD]

Blocks produced: [list of block names in order]
Stories/topics featured: [list of headlines or topics used in each block]
Subject line chosen: [which option the user picked, or "not yet decided"]
Production mode: [hands-on / express]
Skipped blocks: [any blocks skipped for this issue, or "none"]
Notes: [observations — what the user changed, what worked well, voice adjustments, etc.]
```

### Wrap Up

Tell the user their issue is ready. Provide the file path. Keep it brief:

"Issue [N] of [newsletter name] is ready. The complete draft is in `newsboy/issues/NNN/draft.md`. Pick a subject line, fill in any image placeholders, and paste the content into your email platform. You're good to send."
