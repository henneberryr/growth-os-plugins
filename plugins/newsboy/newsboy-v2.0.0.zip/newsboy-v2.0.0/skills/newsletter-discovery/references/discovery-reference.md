# Newsboy Discovery Reference

> Block selection defaults, block count guidance, and naming safeguards for the Newsletter Discovery skill.

**Version**: 1.1.0
**Part of**: Newsboy plugin by theCLICK

---

## Express Setup Block Selection Defaults

Every newsletter gets one promotion block (Self-Promo) — they need a way to monetize.

**Curator-leaning**: News Story + Resource Roundup or Tool Spotlight + Quick Tip + Self-Promo

**Original-thinker-leaning**: Deep Dive + Behind the Scenes + Homework or Quick Tip + Self-Promo

**Mix**: News Story + Deep Dive or Hot Take + Quick Tip + Behind the Scenes + Self-Promo

Name each block in the newsletter's voice. Present the complete lineup for confirmation before proceeding.

**Important:** When naming blocks, never use existing newsletter or media brand names (e.g., 'The Rundown,' 'Morning Brew,' 'The Hustle,' 'TLDR'). Use original names that match the newsletter's voice.

---

## Block Count Guidance

Recommend 4-5 blocks for starters. Every block added is time committed every issue:

- **3 blocks**: Minimal but sustainable. Good for busy people or high-effort blocks (multiple Deep Dives).
- **4-5 blocks**: The sweet spot. Enough variety to keep it interesting, manageable to produce consistently.
- **6-7 blocks**: Ambitious. Works for weekly newsletters with a dedicated production slot. Risk of burnout.
- **8+ blocks**: Only for daily newsletters or teams. Not recommended for solo creators starting out.

Frame it as: "Start with 4-5. You can always add more once you've got the rhythm. Every block you add is time you commit every issue."

---

## Block Naming Safeguards

When naming blocks during selection:

1. **Never use existing newsletter or media brand names.** Do not name a block "The Rundown," "Morning Brew," "The Hustle," "TLDR," "The Skimm," or any other established newsletter brand.

2. **Use original names that reflect the user's voice and newsletter personality.** Good names feel like they belong to the newsletter's vibe. A casual tech newsletter might have "The Download" and "Real Talk." A serious finance newsletter might have "Market Signal" and "The Bottom Line."

3. **Make names intuitive.** The name should hint at what the block contains. A reader should be able to guess what kind of content is in "Quick Win" or "By the Numbers" without explanation.

---

*Reference document for the Newsboy plugin's newsletter-discovery skill. Read during setup alongside the block template library and newsletter philosophy.*
