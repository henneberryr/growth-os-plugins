---
name: newsletter-builder
description: >
  This skill configures content blocks and creates the assembly blueprint
  for a newsletter. It reads the identity and block lineup from Newsletter
  Discovery, configures each block's production process, and builds the
  master playbook for ongoing issue production. Triggers after Discovery
  completes, or when block-lineup.md exists but blocks/ and assembly-blueprint.md
  do not.
version: 2.0.0
---

# Newsletter Builder

Turn a confirmed block lineup into production-ready configuration. By the end of this skill, every block will have a skill file defining how it gets sourced, structured, formatted, and polished — and the assembly blueprint will define how blocks come together into a complete newsletter issue.

**This skill reads two files from Newsletter Discovery:**
1. `newsboy/newsletter-identity.md` — who the newsletter is for and what it sounds like
2. `newsboy/block-lineup.md` — which blocks were selected, with custom names and notes

**This skill produces:**
1. One block skill file per block in `newsboy/blocks/[block-name].md`
2. `newsboy/assembly-blueprint.md` — the master assembly playbook

---

## Before Anything Else: Read Reference Files

Read ALL of these before beginning:

1. `${CLAUDE_PLUGIN_ROOT}/references/block-template-library.md` — 21 proven block types with descriptions, format structures, and fully written examples. Use these as configuration templates.

2. `${CLAUDE_PLUGIN_ROOT}/references/newsletter-philosophy.md` — editorial philosophy: curation, original thinking, the block model, sourcing modes, editorial judgment.

3. `${CLAUDE_PLUGIN_ROOT}/skills/newsletter-builder/references/builder-reference.md` — key configuration questions by block type, express review format, assembly blueprint template, block order principles, reconfiguration guide.

---

## Detect Existing State

Before asking any questions, use Glob to scan for existing Newsboy files:

- Glob for `**/newsboy/newsletter-identity.md` → **Required.** If not found, tell the user: "I need your newsletter identity first. Run `/newsboy-setup` to start Discovery, then come back to the Builder."
- Glob for `**/newsboy/block-lineup.md` → **Required.** If not found, tell the user: "I need your block lineup first. Run `/newsboy-setup` to complete Discovery, then come back to the Builder."
- Glob for `**/newsboy/blocks/*.md` → If found, some or all blocks are already configured. Read them.
- Glob for `**/newsboy/assembly-blueprint.md` → If found, assembly is already complete. Read it.

**If both required files exist AND blocks + blueprint exist** → Builder is already complete. Tell the user: "Your newsletter is fully configured with [N] blocks. Want to reconfigure anything, or jump to production with `/newsboy-produce`?"

**If both required files exist AND some blocks exist but not all (or no blueprint)** → pick up where they left off. Tell the user which blocks are configured and which still need work.

**If both required files exist AND no blocks or blueprint exist** → start fresh from Step 1.

Read the identity and lineup files. Extract: newsletter name, audience, vibe, content orientation, cadence, block list with custom names and types, and any user notes from selection.

---

## Opening: Set the Tone

When starting the Builder, acknowledge the transition from Discovery:

"Great — you've got your identity and block lineup locked in. Now we're going to configure each block and build your assembly blueprint. This is where we turn your selections into production instructions — the exact format, sourcing process, and quality standards for every block.

This takes about 10-15 minutes. By the end, your newsletter will have a complete production playbook. Nothing here is set in stone — if something doesn't feel right as we go, tell me and I'll adjust."

---

## The Setup Mode Fork

Use AskUserQuestion to offer two configuration paths:

**Hands-on configuration** — "We walk through each block one at a time. I'll show you how each one works, ask a few key questions, and configure it based on your answers. Full control. Takes 15-20 minutes."

**Express configuration** — "I configure all blocks with smart defaults based on your identity and selections. You review the complete setup and tell me what to change. Much faster — takes about 5-10 minutes."

"Most people start with express and tweak from there. What feels better?"

---

## Step 1 — Block Configuration

For each block in the lineup, define the Source → Structure → Format → Polish pipeline. Each configuration produces a **block skill file**.

**The key insight**: The configuration interview IS skill authoring. When the user defines how a news story gets sourced and formatted, they're writing the production instructions for every future issue. They don't need to know this — keep everything in plain, conversational language.

### Hands-on Configuration

For each block in the lineup:

1. **Arrive pre-configured.** Use the block template library + newsletter identity to pre-fill Format and Polish. Start from the template, not from zero.

2. **Present the block in plain language.** Never show the raw skill file format during the interview. Instead, say something like: "Here's how [block name] will work: I'll search [sources] for the top stories each week. I'll pick the best candidate and structure it with a category label, a punchy headline linked to the source, 3-5 bullet points summarizing the facts, and a 'Why It Matters' section where I interpret what it means for your audience. The finished block will run about [length] words. Does that work, or would you change something?"

3. **Surface 1-3 key decisions** that are genuinely specific to this user's newsletter. See builder-reference.md for the key questions by block type. Don't ask 15 questions — only ask what actually changes the output.

4. **Invite preferences.** After presenting each block's configuration, ask: "Anything you'd want to tweak about how this block works? Maybe a different format, different length, specific sources you trust? The more you tell me now, the better every issue will be."

5. **Write the skill file behind the scenes.** The user speaks in plain language. You write the structured skill file. Confirm: "Got it. [Block name] is configured."

6. **Celebrate each block.** After configuring each block: "[Block name] is done. That's [N] of [total] configured. [Remaining] to go."

### Express Configuration

Generate all block skill files automatically with sensible defaults based on the identity, content orientation, and block types selected. Present the complete lineup using the express review format from builder-reference.md:

"Here's what I've built for [newsletter name]:

**Your Blocks:**
1. **[Name]** ([Type]) — [one sentence: what this block does + default sourcing mode]
2. **[Name]** ([Type]) — [one sentence]
3. ...

Does anything feel off? This is the best time to shape how each block works — any preferences you share now get baked in for every future issue."

Show full skill file details only if the user asks to see them for a specific block.

### The Three Sourcing Modes

Every block has a default sourcing mode. During configuration, confirm the default and note alternatives:

- **Find it** — Claude searches externally. Default for: News Story, Resource Roundup, Tool Spotlight, Data Point, Stat of the Week.
- **Prompt me** — Claude asks the user a targeted question. Default for: Behind the Scenes, Hot Take, Deep Dive, Q&A, Reader Spotlight.
- **Here's something** — The user brings existing material (voice memos, social posts, notes). Available as an alternative for almost all block types. This is how repurposing works.

### Block Skill File Format

Write one file per block to `newsboy/blocks/[block-name].md` (kebab-case filenames):

```
# [Custom Block Name]

Type: [template type from library]
Newsletter: [newsletter name]

## Source

Default mode: [find it / prompt me / here's something]
Alternative modes: [list any other modes this block supports]

[Specific sourcing instructions]

## Structure

[How raw material gets organized and shaped]

## Format

[Exact structure of the finished block — element by element, in order]

## Polish

Voice: [voice and tone rules specific to this block]
Length: [word count target or range]
Quality checks: [specific things to verify]
```

### Milestone Celebration

After all blocks are configured:

"All [N] blocks are configured and ready for production. Here's your lineup: [list with names and types]. One more step — the assembly blueprint — and your newsletter is fully set up."

---

## Step 2 — Assembly Blueprint

Define how all finished blocks come together into one newsletter issue.

### The Step 2 Interview

Arrive with a recommended block order and complete assembly blueprint based on Steps 1 and the identity. Before diving into specifics, give the user one more chance to shape the overall feel:

"We're about to finalize how your newsletter comes together — the order of your blocks, how you open and close each issue, and your subject line style. Before I show you my recommendation, is there anything about how you want your newsletter to look and feel that we haven't talked about yet?"

Then ask 2-3 focused questions:

1. **Block order:** Present the recommended order with reasoning. "Does this order feel right? I put [strongest block] first because you want to lead with your best content, and [lighter block] in the middle as a breather."

2. **Sign-off style:** "How do you want to close each issue? A casual sign-off like 'See you next week'? A catchphrase? Your name with a title?"

3. **Production mode:** Use AskUserQuestion:
   - **Hands-on production** — "I walk you through each stage. I'll show you story candidates and you pick your favorites. I'll draft each block and you review them one at a time."
   - **Express production** — "I do a full run and hand you a finished newsletter. You review the complete issue at the end and tell me what to change. Faster, fewer stops."
   - "Most people start hands-on for their first few issues and switch to express once they trust the system."

### Opener Structure

Confirm the opener approach: "For your opener, I'll use a simple 4-part structure that varies just enough to stay fresh:"

1. **Salutation** — One quick, warm greeting line. Varies every issue.
2. **Anchor line** — A consistent line that signals what's coming (e.g., "Here's what's coming up:"). Same every issue.
3. **Bullet teasers** — One per major block. Punchy, curiosity-driven, 3-8 words each.
4. **Segue** — One short, energetic line transitioning into the first block. Varies every issue.

"Want to brainstorm some opening salutations and segue lines right now? Having a bank of 5-7 options means the opener stays fresh without requiring new writing each time."

If the user wants to brainstorm, guide them. If not, offer to generate suggestions based on their voice.

### Subject Line Style

"Last thing: subject lines. I'll generate 3 options per issue. How should they feel?"

Recommend: "Short, curiosity-driven, conversational. 5-7 words max. Tight and punchy."

### Output — Assembly Blueprint

Write to `newsboy/assembly-blueprint.md` using the full template from builder-reference.md. The blueprint includes: block order, opener format (with salutation/segue banks), transition style, closer format, subject line style, production mode, and document format.

---

## Builder Complete

After writing the assembly blueprint, verify all files:

1. Use Glob to confirm `**/newsboy/newsletter-identity.md` exists
2. Use Glob to confirm `**/newsboy/block-lineup.md` exists
3. Use Glob to confirm `**/newsboy/assembly-blueprint.md` exists
4. Use Glob to confirm `**/newsboy/blocks/*.md` files exist (one per block in the lineup)

### Final Celebration

"Your newsletter is built and ready to produce! Here's the complete picture:

**[Newsletter name]** — [promise]
**Blocks:** [list custom names]
**Cadence:** [frequency]
**Production mode:** [hands-on/express]

Everything is configured. Run `/newsboy-produce` whenever you're ready to create your first issue. Your first issue gets extra guidance — I'll walk you through the process step by step so you see how everything works.

The more issues you produce, the better the system gets. Your voice calibrates, your sources sharpen, and production gets faster."

If the user wants to produce an issue right away, proceed directly into the produce-issue workflow.

---

## Reconfiguration

When a user returns to make changes after setup is complete, support quick, targeted edits — never re-run the full setup. See builder-reference.md for the reconfiguration guide.

Keep reconfigurations fast. These should feel like quick tweaks, not a re-setup.
