# Newsboy Builder Reference

> Configuration questions, review formats, assembly blueprint template, and reconfiguration guide for the Newsletter Builder skill.

**Version**: 1.1.0
**Part of**: Newsboy plugin by theCLICK

---

## Block Configuration — Key Questions by Type

Different block types need different configuration questions. Don't ask 15 questions — surface 1-3 decisions that genuinely change the output:

- **News Story**: What sources to scan? What filter determines if a story is relevant to your audience?
- **Behind the Scenes**: How personal? Business-only, or life too? What boundaries?
- **Deep Dive**: What topics do you teach best? How long should these run? (500 words? 1000?)
- **Homework**: What skill level is your reader? How much time should an assignment take?
- **Quick Tip**: One-liner tips or multi-step? From your experience or curated from sources?
- **Resource Roundup**: How many links per issue? What sources do you trust?
- **Hot Take**: How controversial are you willing to be? Do you acknowledge the other side?
- **Self-Promo**: What are you promoting? One offer or rotating offers?
- **Tool Spotlight**: Free tools only, or paid too? Your own recommendations or crowd-sourced?
- **Data Point**: What kind of stats resonate with your audience? Where do you find them?
- **Q&A**: Where will questions come from? (Replies, social media, fabricated for early issues?)
- **Reader Spotlight**: Do you have readers/customers to feature? How to solicit stories?
- **Prediction**: How bold? Industry-specific or broad trends?
- **Poll/Survey**: One-click email polls or external survey links?

---

## Express Review Format

When presenting express configuration results, use this summary format — NOT full skill file dumps:

```
Here's what I've built for [newsletter name]:

**Your Blocks:**
1. [Name] ([Type]) — [one sentence: what this block does + default sourcing mode]
2. [Name] ([Type]) — [one sentence]
3. ...

**Assembly:** [Name] opens with [opener style], blocks are separated by [transition style], and closes with [closer approach]. Production mode: [express/hands-on].

Want to change anything, or should we lock this in?
```

**Example:**

Here's what I've built for The Weekly Grind:

**Your Blocks:**
1. The Scoop (News Story) — Top story from your industry, curated and interpreted. Default: find it.
2. Tool of the Week (Tool Spotlight) — One useful tool with a quick review. Default: find it.
3. Real Talk (Behind the Scenes) — A personal story or lesson from your week. Default: prompt me.
4. The Plug (Self-Promo) — Promote your latest offer, tied to the issue's theme. Default: here's something.

**Assembly:** The Weekly Grind opens with a casual greeting + 3 teaser bullets, blocks are separated by horizontal rules, and closes with a reply CTA + personal sign-off. Production mode: express.

Want to change anything, or should we lock this in?

Show full skill files only if the user asks to see details on a specific block.

---

## Assembly Blueprint Template

Write to `newsboy/assembly-blueprint.md` in the user's workspace:

```
# Assembly Blueprint

Newsletter: [name]
Cadence: [frequency + day if discussed]

## Block Order (default)

1. [Custom Block Name] ([Block Type]) — [one-line purpose]
2. [Custom Block Name] ([Block Type]) — [one-line purpose]
3. ...

## Opener

Structure (4 parts, always in this order):
1. **Salutation:** One quick, warm greeting line. Must vary every issue.
2. **Anchor line:** A consistent line that stays the same every issue (e.g., "Here's what's coming up:")
3. **Bullet teasers:** One per major story/block. Punchy, curiosity-driven, 3-8 words each.
4. **Segue:** One short, energetic line transitioning into the first block. Must vary every issue.

Voice: [vibe — e.g., "Energetic, concise, creates anticipation"]
Content: Draft after all blocks are finalized. Tease highlights from the issue.

Salutation bank: [list 4-6 salutation options to rotate through]
Segue bank: [list 4-6 segue options to rotate through]

## Transitions

Style: [How blocks are separated — e.g., horizontal rules (---), visual dividers, or custom separators. Most newsletters use horizontal rules.]

## Closer

Format (in this order):
1. **Quick wrap:** One short line to close (e.g., "That's the week."). Do NOT restate or summarize stories.
2. **Reply CTA:** A joke or playful reference to one of the stories, inviting a reply. Keep it fun, not formal. Mix this up every issue.
3. **Sign-off:** [personal sign-off style — e.g., "See you next week!" or a custom catchphrase, then author name]

Social links: [list or "to be added"]
Referral: [yes/no — describe if yes]
Legal/unsubscribe: Handled by email platform

## Subject Line

Generate: 3 options per issue
Style: [approach — e.g., "Short, curiosity-driven, conversational"]
Length: **5-7 words max.** Tight. Punchy. No filler. If it's over 7 words, cut it. Count hyphenated phrases as one word. Emojis don't count toward the word limit but use sparingly — one max.
Include: Preview text suggestion for each option

## Production Mode

Default: [Hands-on / Express]
Switch anytime: "switch to express" or "switch to hands-on"

## Document Format

Output: Markdown (.md file)
Structure:
  - Production notes at top (subject line options, image reminders, flags)
  - Opener
  - Blocks in order, separated by horizontal rules
  - Closer
  - Image placeholders marked with [Image: description] throughout
```

---

## Block Order Principles

Arrange blocks for good pacing:
- Lead with the strongest content (news or original piece)
- Alternate heavy and light blocks
- Place personal/engagement blocks in the middle
- Close with utility and promotion

---

## Reconfiguration Guide

When a user wants to make changes, start with their goal: "What would you like to change?" Then:
1. Show the current state (list blocks, order, production mode)
2. Propose the specific change they requested
3. Confirm the change and any impacts on the assembly blueprint
4. Make the edit and show the updated state

Keep reconfigurations fast — these should feel like quick tweaks, not a re-setup.

When the user has existing setup files and wants to make changes, support these operations as quick, targeted edits — never re-run the full setup:

**Add a block**: Create a new block skill file using the block template library for reference. Add the block to the assembly blueprint's block order. Update the block lineup. Suggest where it fits in the sequence based on pacing principles.

**Remove a block**: Confirm with the user, then remove the block skill file and remove it from the assembly blueprint. Note: don't delete the file permanently — rename it with a `.disabled` extension in case they want it back. Update the block lineup.

**Reorder blocks**: Update the assembly blueprint's block order. Remind the user of pacing principles.

**Rename a block**: Update the block's skill file header (Block: field), rename the file, update the assembly blueprint, and update the block lineup.

**Change identity**: Update the identity doc. Flag any blocks that may need voice/tone adjustment based on the identity change.

**Change production mode**: Update the assembly blueprint's Production Mode section. This is a one-line edit.

**Add or change sourcing for a block**: Edit the block's skill file Source section. Offer to change default modes or add alternative modes.

---

For detailed sourcing strategy during production — including search techniques, candidate evaluation, source tier standards, and image sourcing — see the Sourcing Guide in the Produce Issue skill references.

---

*Reference document for the Newsboy plugin's newsletter-builder skill. Read during configuration alongside the block template library and newsletter philosophy.*
