---
description: Produce a new newsletter issue
allowed-tools: Read, Write, Edit, Bash, Glob, Grep, WebSearch, WebFetch, AskUserQuestion
argument-hint: [optional: topic or direction, e.g. "feature something about AI this week"]
---

Produce a new newsletter issue using the six-stage production workflow.

**First: verify setup is complete.** Use Glob to check for ALL of these in the user's workspace:
1. `**/newsboy/newsletter-identity.md`
2. `**/newsboy/assembly-blueprint.md`
3. At least one file matching `**/newsboy/blocks/*.md`

**If any are missing** → tell the user: "Your newsletter isn't fully set up yet. Run `/newsboy-setup` first to create your newsletter structure." Stop here.

**If all exist** → read all configuration files (identity, blueprint, all block files, and issue-log.md if it exists).

Read ALL reference files before starting:
- `${CLAUDE_PLUGIN_ROOT}/references/newsletter-philosophy.md` — editorial judgment guidance
- `${CLAUDE_PLUGIN_ROOT}/references/block-template-library.md` — quality standard for block drafts
- `${CLAUDE_PLUGIN_ROOT}/skills/produce-issue/references/sourcing-guide.md` — sourcing strategy and evaluation

If the user provided arguments (e.g., "feature something about AI this week"), use that as a sourcing directive — prioritize that topic during the Source stage for relevant blocks.

Run the six-stage production workflow: Source → Draft → Fact-Check → Review → Assemble → Deliver. Follow the Produce Issue skill for the full workflow, including first-issue guidance (if applicable), mandatory checkpoints (source selection, final review), and the user's preferred production mode from the assembly blueprint.
