---
description: Set up a new newsletter or reconfigure an existing one
allowed-tools: Read, Write, Edit, Bash, Glob, Grep, WebSearch, WebFetch, AskUserQuestion
argument-hint: [optional: topic or idea, e.g. "a fitness newsletter"]
---

Run the Newsletter Discovery + Newsletter Builder setup workflow.

**First: detect existing state.** Use Glob to scan for these files in the user's workspace:
- `**/newsboy/newsletter-identity.md`
- `**/newsboy/block-lineup.md`
- `**/newsboy/assembly-blueprint.md`
- `**/newsboy/blocks/*.md`

**If all files exist** → setup is complete. Tell the user: "You already have [newsletter name] set up with [N] blocks. Want to reconfigure, or jump straight to production with `/newsboy-produce`?"

**If identity + lineup exist but blocks/blueprint don't** → Discovery is done, Builder hasn't run. Tell the user what's done and offer to continue to the Builder.

**If only identity exists** → Discovery is partially done. Offer to continue from block education and selection.

**If no files exist** → begin the full setup workflow starting with Discovery.

## The Two-Skill Setup

Setup runs in two phases, each handled by a dedicated skill:

### Phase 1: Newsletter Discovery
Handles identity, education, and block selection. Run the Newsletter Discovery skill. It produces:
- `newsboy/newsletter-identity.md` — who the newsletter is for and what it sounds like
- `newsboy/block-lineup.md` — which blocks were selected, with custom names and notes

### Phase 2: Newsletter Builder
Handles block configuration and assembly blueprint. Run the Newsletter Builder skill. It reads Discovery's output and produces:
- Block skill files in `newsboy/blocks/` — one per block
- `newsboy/assembly-blueprint.md` — the master assembly playbook

After Discovery completes, offer to continue to the Builder: "Ready to move to configuration? The Builder will turn your blocks into production-ready skill files."

If the user provided arguments (e.g., "I want to build a fitness newsletter"), pass that context to Discovery as a starting point — don't ask questions you already have answers to.

All files ready for `/newsboy-produce` after both phases complete.
