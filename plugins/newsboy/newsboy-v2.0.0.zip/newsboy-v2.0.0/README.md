# Newsboy

Build and produce a newsletter — from "I don't have a newsletter" to a polished, publish-ready document.

## What It Does

Newsboy helps you create a newsletter from scratch using a proven content block model. It has three phases:

**Phase One (Discovery)** — Learn how the content block model works, define your newsletter's identity, and choose your content blocks. Includes an interactive visual explainer, voice calibration, and guided block selection. You'll leave this phase understanding exactly how your newsletter is structured.

**Phase Two (Builder)** — Configure each block's production process and create an assembly blueprint. You can walk through this step by step (hands-on mode) or let Claude build everything and you just review (express mode). Every block gets a skill file defining how it's sourced, structured, formatted, and polished.

**Phase Three (Production)** — Every time you want to produce an issue, Newsboy reads your configuration and runs a seven-stage workflow: Source → Draft → Fact-Check → Voice Pass → Review → Assemble → Deliver. The output is a markdown document ready to paste into your email platform. Includes first-issue guidance, cross-issue continuity, editorial sourcing intelligence, automatic fact-checking, and a dedicated brand voice rewrite pass.

## Commands

| Command | Description |
|---------|-------------|
| `/newsboy-setup` | Set up a new newsletter or reconfigure an existing one |
| `/newsboy-produce` | Produce a new newsletter issue |

Both commands accept optional arguments. For example: `/newsboy-setup a weekly fitness newsletter` or `/newsboy-produce feature something about AI this week`.

## Skills

| Skill | Purpose |
|-------|---------|
| Newsletter Discovery | Three-step identity setup: Interview → Block Education → Block Selection. Includes workspace scanning, voice calibration, mandatory visual explainer, and a block lineup handoff to Builder. |
| Newsletter Builder | Two-step configuration: Block Configuration → Assembly Blueprint. Turns selected blocks into production-ready skill files and creates the master assembly playbook. Includes express/hands-on modes and reconfiguration support. |
| Produce Issue | Seven-stage production: Source → Draft → Fact-Check → Voice Pass → Review → Assemble → Deliver. Includes first-issue guidance, issue continuity, source tier standards, automatic fact-checking, dedicated brand voice rewrite, and two mandatory human checkpoints. |

## Reference Files

| File | Used By | Purpose |
|------|---------|---------|
| Block Template Library | All skills (shared) | 21 proven block types with descriptions, format structures, and fully written examples. Quality standard for drafting. |
| Newsletter Philosophy | Discovery + Builder (shared) | Editorial philosophy: curation, original thinking, the block model, sourcing, voice, production mindset. |
| Discovery Reference | Newsletter Discovery | Express block selection defaults, block count guidance, block naming safeguards. |
| Block Explainer | Newsletter Discovery | Visual HTML mockup showing what content blocks look like in a real newsletter, with color-coded annotations. Mandatory during block education. |
| Builder Reference | Newsletter Builder | Key configuration questions by block type, express review format, assembly blueprint template, block order principles, reconfiguration guide. |
| Sourcing Guide | Produce Issue | How to find, evaluate, and present source material. Covers search strategy, source tier standards, candidate evaluation, material type handling. |

## Getting Started

1. Run `/newsboy-setup`
2. **Discovery:** Answer questions about your audience, niche, and style. Learn how the content block model works. See the visual block explainer. Choose your blocks.
3. **Builder:** Configure each block's production process and create your assembly blueprint.
4. Run `/newsboy-produce` to create your first issue.

## How It Works

Newsboy uses a **content block model**. Instead of writing a newsletter from a blank page, you build it from modular blocks — a news story, a quick tip, a personal story, a homework assignment. Each block has its own format and production process.

The plugin includes a library of 21 proven block types across five categories (News, Education, Engagement, Promotion, Utility). During setup, you pick the ones that fit your style, name them in your voice, and configure how each one gets produced. Then every issue is just filling in the blocks.

Three sourcing modes power the blocks: **Find it** (Claude searches externally), **Prompt me** (Claude asks you), and **Here's something** (you bring existing material like transcripts, voice memos, or notes). Most blocks support multiple modes, so you can repurpose existing content into newsletter pieces just as easily as writing from scratch.

## Files Generated

After setup, Newsboy creates these files in your workspace:

```
newsboy/
├── newsletter-identity.md    — Name, audience, vibe, voice notes, content orientation
├── block-lineup.md           — Selected blocks with custom names (Discovery → Builder handoff)
├── assembly-blueprint.md     — Block order, opener/closer format, production mode
├── blocks/
│   ├── [block-name].md       — One config file per content block
│   └── ...
├── issues/
│   ├── 001/
│   │   ├── research.md       — Source candidates (user reviews and picks)
│   │   ├── draft.md          — Full newsletter draft (fact-checked before user sees it)
│   │   └── fact-check.md     — Verification report
│   └── ...
└── issue-log.md              — Running log of what was covered, subject lines, notes
```

## No External Dependencies

Newsboy is self-contained. No API keys, no email platform integration, no external services required. The output is a markdown document you copy into whatever email tool you use.

## Version

2.0.0
