# Newsboy Block Template Library

> 21 proven content block types for newsletters. Each block includes a description, format structure, and a written example using a fictional newsletter called **"The Growth Signal"** — a weekly newsletter for small business owners who want to grow with smarter marketing.

**Version**: 1.0.0
**Part of**: Newsboy plugin by theCLICK

---

## Quick Reference — All 21 Block Types

**Complexity** reflects the effort and decision-making required per issue. Low = quick to produce (15-30 min), Medium = moderate effort (30-60 min), Medium-High = significant effort (60+ min). These are rough guides — actual time depends on sourcing mode and the creator's familiarity with the topic.

| # | Block Type | Category | Purpose | Complexity |
|---|---|---|---|---|
| 1 | News Story | News | Curate and interpret industry news | Medium |
| 2 | Quick Tip | Education | One actionable tip they can use today | Low |
| 3 | Trivia / Quiz | Engagement | Entertainment + education | Low |
| 4 | Cartoon / Comic | Engagement | Humor, personality, shareability | Low (requires image) |
| 5 | Tool Spotlight | Education | Highlight a useful tool or resource | Low |
| 6 | Data Point / Stat | News | A compelling number with interpretation | Low |
| 7 | Hot Take / Opinion | News | Bold perspective that drives engagement | Medium |
| 8 | Resource Roundup | Education | Curated links worth reading | Low |
| 9 | Reader Spotlight / Case Study | Engagement | Feature a reader's success story | Medium |
| 10 | Action Item / Homework | Education | Give the reader something to do | Medium |
| 11 | Behind the Scenes | Engagement | Personal story, transparency, connection | Low |
| 12 | Q&A / Ask Me Anything | Engagement | Answer a reader's question | Low |
| 13 | Poll / Survey | Engagement | One-click question to drive interaction | Low |
| 14 | Quote of the Week | Utility | Thought-provoking quote + commentary | Low |
| 15 | Sponsor / Ad Block | Promotion | Paid native advertising | Low |
| 16 | Product / Self-Promo | Promotion | Promote your own offers | Low |
| 17 | Prediction / Forecast | News | Forward-looking industry analysis | Medium |
| 18 | Event / Calendar | Utility | Upcoming dates and deadlines | Low |
| 19 | Meme / Humor | Engagement | Industry meme for shareability | Low (requires image) |
| 20 | Referral / Growth | Utility | Incentivize sharing to grow the list | Low |
| 21 | Deep Dive / Feature | Education | Original teaching piece from your expertise | Medium-High |

**Categories at a Glance:**
- **News (4):** News Story, Data Point, Hot Take, Prediction — keep readers informed
- **Education (5):** Quick Tip, Tool Spotlight, Resource Roundup, Homework, Deep Dive — deliver tangible value
- **Engagement (6):** Trivia, Cartoon, Reader Spotlight, Behind the Scenes, Q&A, Poll, Meme — build community
- **Promotion (2):** Sponsor Block, Self-Promo — drive revenue
- **Utility (3):** Quote, Event Calendar, Referral — practical value and growth

---

## How to Read This Document

Each block type includes:

- **Name** — what the block is called generically
- **Category** — what role it plays in the newsletter (News, Education, Engagement, Promotion, Utility)
- **Description** — what the block does and why it works
- **Format** — the structural components that make up the block, in order
- **Example** — a fully written sample from The Growth Signal

---

## Block 1: News Story

**Category**: News

**Description**: The backbone of any Morning Brew-style newsletter. Curate a relevant news story from your industry, present the facts clearly, and then interpret what it means for your audience. The power of this block is in the "why it matters" section — that's where you add value that readers can't get from just reading the headline.

**Format**:
1. Category label (h4 format, e.g., "#### MARKETING TECH" or "#### SOCIAL MEDIA")
2. Headline (h2 format) — a punchy, attention-grabbing title written in your voice (not just the original headline). **Link the headline to the source article** so readers can click through for the full story.
3. Image — a relevant image, meme, or graphic (placeholder in v1)
4. The Bullets — 3-5 factual bullet points that summarize what happened
5. Why It Matters (h3 format) — 2-3 paragraphs interpreting the story for your specific audience

**Heading hierarchy:** Category label as `####` (h4), Headline as `##` (h2, linked to source), Why It Matters as `###` (h3).

**Example**:

> #### MARKETING TECH
>
> ## [Google Just Made Your SEO Strategy Obsolete (Again)](https://www.example.com/google-ai-overviews)
>
> [Image placeholder: Google AI Overviews screenshot]
>
> **The Bullets:**
> - Google announced that AI Overviews will now appear on 75% of all search queries, up from 30% last year
> - Click-through rates to external websites have dropped 18% since the rollout began
> - Small business websites are disproportionately affected — enterprise sites with brand recognition are holding steady
> - Google is simultaneously launching a "verified small business" badge for local search results
>
> ### Why It Matters
>
> If you're a small business relying on blog posts to drive organic traffic, the ground just shifted under your feet. Those "how to" articles that used to bring in steady traffic? Google is now answering those questions directly in the search results, and fewer people are clicking through to read the full article.
>
> But here's the thing most people are missing: Google's new "verified small business" badge is actually a massive opportunity for local businesses. It means Google is trying to build trust signals for smaller players. If you're a local service provider, getting verified and optimizing your Google Business Profile just became more important than writing your next blog post.
>
> The move: audit your traffic sources this week. If more than 40% of your leads come from organic search, it's time to diversify. Email, referrals, and partnerships should be getting more of your attention.

---

## Block 2: Quick Tip

**Category**: Education

**Description**: A single, actionable tip the reader can implement today. This block is fast to read, immediately useful, and builds trust because you're giving something practical every issue. The best quick tips are specific, not generic — they tell the reader exactly what to do, not just what to think about.

**Format**:
1. Block header (e.g., "Quick Win" or "60-Second Tip")
2. The tip — one sentence that captures the action
3. The context — 2-3 sentences explaining why this works
4. The how — 2-3 sentences with specific instructions

**Example**:

> ### 60-Second Tip
>
> **Add a P.S. line to every marketing email you send.**
>
> Here's a weird stat: the P.S. line in an email gets read almost as often as the opening line. People scroll to the bottom, and their eyes land on it. Most marketers don't use it.
>
> This week, add a P.S. to your next email. Use it for your most important call to action — not a repeat of what's above, but the one thing you'd say if you only had one sentence. Something like: "P.S. — We only have 4 spots left for the March workshop. Grab yours here." Short, direct, urgent.

---

## Block 3: Trivia / Quiz

**Category**: Engagement

**Description**: A fun, niche-relevant trivia question that entertains and educates at the same time. Great for engagement — readers look forward to it, and it adds personality to the newsletter. The answer can appear later in the same issue (creating a reason to keep reading) or at the very bottom.

**Format**:
1. Block header (e.g., "Marketing Trivia" or a playful name)
2. The question — framed in a fun way (Jeopardy-style, multiple choice, fill-in-the-blank)
3. Separator or scroll gap
4. The answer — contains: the answer itself, a one-sentence explanation, a link if available, and 1-2 interesting facts or surprising details. Keep it fun and trivia-flavored, not preachy.

The example below uses a Jeopardy-style format, but trivia blocks can take many forms: multiple choice, fill-in-the-blank, true/false, "guess the number," or any playful question format that fits your newsletter's personality.

**Example**:

> ### Marketing Trivia
>
> **I'll take "Email Marketing" for $400, Alex.**
>
> *Answer: This is the average number of marketing emails a person receives per day, according to a 2025 Litmus study.*
>
> *Answer... ermm... question at the bottom of this email.*
>
> ---
>
> **Trivia Answer:** What is 121?
>
> The average person receives 121 marketing emails per day. That's nearly 3,000 per month. Here's the fun part: email open rates are actually UP from 2024. How? Because the people who are good at email are getting really, really good. Meanwhile, the people doing bulk blasts are getting buried. Bonus fact: the average subject line is now just 7 words — any longer and mobile users can't see it.

---

## Block 4: Cartoon / Comic

**Category**: Engagement

**Description**: A topical cartoon or comic strip that's relevant to your industry. This block adds personality, humor, and shareability. People screenshot cartoons and share them — it's organic distribution. Can be custom-illustrated or sourced from industry cartoonists (with permission).

**Format**:
1. Cartoon image (placeholder in v1)
2. Optional caption or brief commentary

**Example**:

> [Image placeholder: A cartoon showing two business owners at a coffee shop. One says "I posted on social media every day for a month!" The other asks "How many customers did you get?" First one replies "I got 47 likes from other marketers." Caption reads: "The Growth Signal"]
>
> We've all been there.

---

## Block 5: Tool Spotlight

**Category**: Education

**Description**: Highlight a tool, app, or resource that your audience would find useful. This block builds trust because you're curating what's worth their time. Can be free tools, paid tools, or even a spreadsheet template. Works great for affiliate monetization in later versions.

**Format**:
1. Block header (e.g., "Tool of the Week")
2. Tool name and one-line description
3. What it does — 2-3 sentences
4. Why it's useful for your audience — 2-3 sentences connecting it to their specific work
5. Link to the tool

**Example**:

> ### Tool of the Week
>
> **Canva Magic Studio** — AI-powered design tools built into Canva's free plan.
>
> Canva just rolled out a set of AI features that let you generate social media graphics from a text prompt, remove backgrounds instantly, and resize designs for every platform in one click. Most of the features work on the free plan.
>
> If you're a small business owner creating your own social media content (and let's be honest, most of you are), this just eliminated about 2 hours of design work per week. You don't need a graphic designer for standard social posts anymore. Write your caption, tell Canva what you want the graphic to look like, and it builds it.
>
> [Try Canva Magic Studio →]

---

## Block 6: Data Point / Stat of the Week

**Category**: News

**Description**: A single compelling statistic with interpretation. Numbers grab attention and lend authority. The key is not just sharing the stat but explaining what it means for the reader's business. This block is fast to read and highly shareable.

**Format**:
1. Block header (e.g., "By the Numbers" or "This Week's Number")
2. The stat — displayed prominently
3. The source — where it came from. Source must be Tier 1 (primary sources, major outlets, top press). If only a Tier 2 source is available, include a Tier 1 cross-reference.
4. The interpretation — 2-3 sentences explaining what this means for your audience

**Example**:

> ### By the Numbers
>
> ## 73%
>
> That's the percentage of consumers who say they've purchased a product because they saw it on social media, according to a 2025 Sprout Social report.
>
> But here's the nuance: it wasn't the polished ad that convinced them. The top driver was "authentic content from real people using the product." If you're a small business spending all your social media budget on professional photo shoots, you might be better off handing your phone to a happy customer and asking them to record a 30-second video.

---

## Block 7: Hot Take / Opinion

**Category**: News

**Description**: A bold, opinionated perspective on something happening in your industry. This block is what separates a personality-driven newsletter from a news aggregator. Readers subscribe for *your* take, not just the facts. Be willing to disagree with popular opinion. This block drives replies and engagement.

**Format**:
1. Block header (e.g., "Hot Take" or "Unpopular Opinion")
2. The take — one bold statement
3. The argument — 3-5 sentences making your case
4. The caveat (optional) — acknowledge the other side briefly

**Example**:

> ### Hot Take
>
> **Most small businesses should stop posting on Instagram.**
>
> I know, I know. But hear me out. If you're a local plumber, a B2B consultant, or an accounting firm, Instagram is almost certainly not where your customers are making buying decisions. You're posting three times a week to get 23 likes from other business owners, and none of it is turning into revenue.
>
> Meanwhile, your Google Business Profile hasn't been updated in six months, you haven't asked for a review since last year, and your email list is collecting dust.
>
> I'm not saying Instagram is bad. I'm saying it's bad *for you* if it's eating time you should be spending on channels that actually drive revenue for your specific business. The businesses that grow fastest are the ones that go deep on one or two channels, not the ones that post everywhere and pray.

---

## Block 8: Resource Roundup

**Category**: Education

**Description**: A curated list of 3-5 links to articles, videos, podcasts, or resources your audience would find valuable. This block positions you as a trusted filter — you sift through the noise so they don't have to. Each link gets a one-line description and your brief take on why it's worth their time.

**Format**:
1. Block header (e.g., "Worth Your Time" or "This Week's Reads")
2. 3-5 items, each with:
   - Title/link
   - One-line description
   - Your take (one sentence) — optional but adds personality

**Example**:

> ### Worth Your Time
>
> **How One Dentist Built a 6-Figure Practice on Google Reviews Alone** (Duct Tape Marketing) — A case study in what happens when you make "ask for the review" the final step of every appointment. Takeaway: systems beat hustle.
>
> **The State of Email Marketing 2026** (Litmus Report) — The annual benchmarks are out. Open rates are up, click rates are down, and plain-text emails are making a comeback. Every number you need is in here.
>
> **Why Your Website Homepage Is Losing You Customers** (5-min YouTube video, Wes McDowell) — If your homepage still starts with "Welcome to [Business Name]," watch this. He redesigns a real small business homepage live, and the before/after is painful.
>
> **Free Template: 90-Day Marketing Plan for Small Businesses** (HubSpot) — Genuinely useful. Not a lead magnet disguised as a template — this one actually has substance.

---

## Block 9: Reader Spotlight / Case Study

**Category**: Engagement

**Description**: Feature a reader, customer, or community member's success story. This block builds community, provides social proof, and gives your audience real-world examples they can learn from. It also incentivizes engagement — people want to be featured.

**Format**:
1. Block header (e.g., "Spotlight" or "Member Win")
2. Who they are — name, business, one-line description
3. The story — what they did, what happened (3-5 sentences)
4. The takeaway — what other readers can learn from this

**Example**:

> ### Member Win
>
> **Sarah Chen, Founder of Bloom & Grow (plant shop + workshops)**
>
> Sarah was spending 10 hours a week on social media content and getting maybe 2-3 new customers a month from it. Three months ago, she shifted her entire marketing budget to email. She started a simple weekly newsletter — plant care tips, new arrivals, and a featured workshop.
>
> Result: her email list went from 340 to 1,200 subscribers. Her workshops now sell out in 48 hours instead of trickling in over two weeks. And she's spending 3 hours a week on marketing instead of 10.
>
> **The takeaway:** Sarah didn't add more marketing. She subtracted the stuff that wasn't working and doubled down on the channel where her audience actually pays attention. Sometimes growing your business means doing less, not more.

---

## Block 10: Action Item / Homework

**Category**: Education

**Description**: Give the reader a specific task to complete before the next issue. This block transforms passive readers into active participants. The best homework assignments are small enough to finish in 15 minutes but impactful enough to move the needle. This is what makes the newsletter feel like a mentorship, not just a media outlet.

**Format**:
1. Block header (e.g., "This Week's Homework" or "Your Assignment")
2. Image (optional — a playful graphic tied to the assignment)
3. The assignment — clearly stated in 1-2 sentences
4. Step-by-step instructions — exactly how to do it (numbered, specific)
5. Done when — what completion looks like

**Example**:

> ### This Week's Homework
>
> [Image placeholder: chalkboard graphic with "ASSIGNMENT" written on it]
>
> **Audit your Google Business Profile in 10 minutes.**
>
> Your Google Business Profile is probably your most important marketing asset — and most small businesses set it up once and never touch it again. This week, let's fix that.
>
> 1. Google your business name. Click on your Business Profile when it appears.
> 2. Check: Is your phone number correct? Hours updated? Website link working?
> 3. Look at your photos. Are they from 2022? Add at least 2 new photos this week.
> 4. Read your last 5 reviews. Have you responded to all of them? Respond to any you've missed.
> 5. Post an update — a photo of your team, a seasonal promotion, anything. Google rewards active profiles.
>
> **You're done when:** You've verified your info is current, added fresh photos, responded to reviews, and posted one update. Total time: 10 minutes. Impact: more visibility in local search results starting this week.

---

## Block 11: Behind the Scenes

**Category**: Engagement

**Description**: Share a personal story, a peek behind the curtain of your business, or a transparent look at something real — a win, a failure, a lesson learned. This block builds trust and connection. People subscribe to people, not brands. The best behind-the-scenes content is specific and honest, not polished and performative.

**Format**:
1. Block header (e.g., "Behind the Curtain" or "Real Talk")
2. The story — 3-6 sentences, conversational tone
3. The lesson (optional) — what you learned or what the reader can take from it

**Example**:

> ### Behind the Curtain
>
> I almost didn't send this newsletter today.
>
> Monday was chaos. A client project blew up, I spent three hours on a proposal that got rejected, and by Tuesday I was behind on everything. My newsletter was the thing I was most tempted to skip. "Nobody will notice if I miss one week," I told myself.
>
> But here's what I've learned after 47 issues: consistency is the entire game. My best-performing newsletter ever was one I almost didn't send. The worst thing I can do for my business is teach my audience that I'm unreliable.
>
> So here I am. It's not my best issue. But it's here. And that matters more than perfection.

---

## Block 12: Q&A / Ask Me Anything

**Category**: Engagement

**Description**: Answer a question submitted by a reader. This block creates two-way communication, makes readers feel heard, and provides content that's guaranteed to be relevant (because your audience literally asked for it). Include a call to action asking readers to submit their own questions for future issues.

**Format**:
1. Block header (e.g., "You Asked" or "Reader Question")
2. The question — attributed to the reader (first name or anonymous)
3. Your answer — conversational, practical, 4-8 sentences
4. CTA — invite readers to submit their own questions

**Example**:

> ### You Asked
>
> **"I have a small landscaping business. Should I be on TikTok?"** — Mike from Denver
>
> Mike, short answer: probably not yet. Here's my framework. Before you add any marketing channel, ask yourself two questions: (1) Is my audience actually there? (2) Do I have something worth showing?
>
> For landscaping, the answer to both is actually yes — people love before/after transformation videos, and TikTok eats that content up. But here's the catch: TikTok rewards consistency. You'd need to post 3-5 times a week to get any traction. If you're already stretched thin on marketing, adding TikTok will just mean doing three channels poorly instead of two.
>
> My advice: if you're already solid on Google Business Profile and email, and you have 30 minutes a day to spare, TikTok could be a game-changer for a visual business like yours. If you're not solid on those two yet, go there first.
>
> *Got a question? Hit reply and ask me anything about marketing your small business. I'll answer one in every issue.*

---

## Block 13: Poll / Survey

**Category**: Engagement

**Description**: A single question that invites the reader to weigh in. Polls drive engagement because they're low-effort for the reader (one click) and high-value for you (you learn about your audience). The results can be shared in the next issue, creating a feedback loop and a reason to open the next email.

**Format**:
1. Block header (e.g., "Quick Poll" or "Your Take")
2. The question — simple, relevant, one sentence
3. The options — 2-4 choices (one-click format in most email platforms)
4. Promise to share results — "I'll share what you all said next week"

**Example**:

> ### Quick Poll
>
> **What's your biggest marketing challenge right now?**
>
> 🅰️ Getting new customers to find me
> 🅱️ Converting leads into paying customers
> 🅲 Getting existing customers to come back
> 🅳 I don't even know where to start
>
> Click your answer — I'll share the results (and my take on each one) in next week's issue.

---

## Block 14: Quote of the Week

**Category**: Utility

**Description**: A thought-provoking quote with your commentary. This block is fast to produce and adds a reflective moment to the newsletter. The key is the commentary — don't just drop a quote. Explain why you chose it and what it means for your audience specifically. Avoid generic motivational quotes; pick ones that connect to your niche.

**Format**:
1. Block header (e.g., "Words to Grow By" or "Quote of the Week")
2. The quote — properly attributed
3. Your commentary — 2-4 sentences connecting it to your audience's world

**Example**:

> ### Words to Grow By
>
> *"The best marketing doesn't feel like marketing."* — Tom Fishburne
>
> This is why your customers scroll past your "20% OFF SPRING SALE!!!" posts but stop to watch a 30-second video of you explaining how your product works. The businesses that are winning right now aren't the ones shouting the loudest. They're the ones that show up with something genuinely useful or entertaining and let the marketing happen as a side effect.
>
> Next time you sit down to create a piece of content, ask yourself: "Would someone share this even if they didn't know it was from a business?" If the answer is no, start over.

---

## Block 15: Sponsor / Ad Block

**Category**: Promotion

**Description**: A native advertising block for paid sponsors. Written in the same voice as the rest of the newsletter so it doesn't feel jarring. This is a primary monetization vehicle for ad-supported newsletters. The best sponsor blocks feel like recommendations, not interruptions.

**Format**:
1. Sponsor label (e.g., "Together With [Sponsor]" or "Presented By")
2. Headline — written in your newsletter's voice
3. Body — 3-5 sentences explaining what the sponsor offers and why it's relevant to your audience
4. CTA — link to the sponsor's offer

**Example**:

> **Together with Calendly**
>
> ### Stop Playing Email Tag with Your Prospects
>
> You know that moment when a hot lead says "let's find a time to talk" and then you spend four emails going back and forth on scheduling? By the time you lock down a meeting, they've cooled off.
>
> Calendly lets your prospects book time with you in one click. You set your availability, share a link, and they pick a time. No back and forth. Our readers get 30% off the first 3 months with code GROWTHSIGNAL.
>
> [Book More Meetings with Calendly →]

---

## Block 16: Product / Self-Promo Block

**Category**: Promotion

**Description**: A block promoting your own products, services, or offers. This is how newsletters that don't rely on advertising make money. The key is making it feel like a natural part of the newsletter, not a hard sell. Rotate what you promote, and tie it to the issue's content when possible.

**Format**:
1. Block header (e.g., "From Us" or a creative name tied to the offer)
2. What you're promoting — 1 sentence
3. Why it matters right now — tie it to something in this issue or a current pain point
4. CTA — clear and specific

**Example**:

> ### Level Up
>
> **Our Marketing Foundations Workshop is open for enrollment.**
>
> If today's issue made you realize your marketing fundamentals need work — your Google profile is stale, your email list is collecting dust, and you're posting on social media out of guilt more than strategy — this workshop is exactly what you need.
>
> It's a 4-week live program where we rebuild your marketing from the ground up. Small group, hands-on, and you'll leave with a working system, not just a pile of notes.
>
> Enrollment closes Friday. 6 spots left.
>
> [Save Your Spot →]

---

## Block 17: Prediction / Forecast

**Category**: News

**Description**: A forward-looking analysis of where your industry is heading. This block positions you as a thought leader — someone who doesn't just report the news but sees where it's going. Predictions should be specific enough to be interesting and grounded enough to be credible. Revisiting past predictions periodically builds trust.

**Format**:
1. Block header (e.g., "Crystal Ball" or "Where This Is Going")
2. The prediction — one clear statement
3. The evidence — 3-5 sentences explaining why you think this
4. What to do about it — specific advice for the reader

**Example**:

> ### Crystal Ball
>
> **By the end of 2026, "AI-generated" will become a negative label for marketing content.**
>
> Right now, everyone's excited about AI content. But I'm already seeing the backlash forming. Consumers are getting better at spotting AI-written emails, blog posts, and social copy — and when they spot it, trust drops immediately. A recent study showed that content labeled "AI-generated" received 38% less engagement than identical content with no label.
>
> The businesses that will win are the ones using AI as a starting point and adding genuine human perspective, stories, and expertise on top. The ones that hit "generate" and "publish" without adding anything of their own are going to find their content ignored.
>
> **The move:** Keep using AI tools (seriously, they save massive time), but make sure every piece of content has your fingerprints on it — a personal story, a specific opinion, a real example from your business. That's the part AI can't fake.

---

## Block 18: Event / Calendar

**Category**: Utility

**Description**: Highlight upcoming events, webinars, conferences, deadlines, or dates that matter to your audience. This block positions the newsletter as a practical utility — something people keep open in their inbox because it tells them what's coming. Can include your own events and relevant industry events.

**Format**:
1. Block header (e.g., "Mark Your Calendar" or "Coming Up")
2. 2-4 events, each with:
   - Date
   - Event name
   - One-line description
   - Link (if applicable)

**Example**:

> ### Mark Your Calendar
>
> **Mar 18** — Google's spring algorithm update rolls out. If your website traffic dips this week, don't panic. Wait 2 weeks before making any changes. [Google's update guide →]
>
> **Mar 20** — Free webinar: "Email Marketing for Local Businesses" hosted by Mailchimp. Actually decent for beginners. [Register here →]
>
> **Mar 22** — Deadline to apply for the SBA's small business marketing grant ($5,000 for businesses under 20 employees). [Application link →]
>
> **Mar 25** — Our next Marketing Office Hours (live Q&A for Growth Signal readers). Bring your questions. [Save your spot →]

---

## Block 19: Meme / Humor

**Category**: Engagement

**Description**: An industry-relevant meme with brief commentary. Lighter than a cartoon but serves the same purpose — personality, shareability, and a mental break between heavier content blocks. Memes are the most shareable content format on the internet, and when they're relevant to your niche, they signal that you *get* your audience.

**Format**:
1. Image — the meme (placeholder in v1)
2. Brief commentary — 1-2 sentences (optional, sometimes the meme speaks for itself)

**Example**:

> [Image placeholder: Drake meme — top panel (rejecting): "Spending $5,000 on Facebook ads with no strategy" / bottom panel (approving): "Spending $0 sending a follow-up email to last month's leads"]
>
> It's not always about the budget. It's about the basics.

---

## Block 20: Referral / Growth Block

**Category**: Utility

**Description**: A built-in referral program block that incentivizes readers to share the newsletter. Morning Brew famously grew to millions of subscribers partly through this mechanism. The block tells readers what they get for referring friends and shows their current progress. Most email platforms (Beehiiv, ConvertKit, Substack) have referral features built in.

**Format**:
1. Block header (e.g., "Share the Signal" or "Spread the Word")
2. The hook — why they should share (1-2 sentences)
3. Referral tiers — what they earn at different levels
4. Their current status — how many referrals they have and what's next
5. Share link / button

**Example**:

> ### Share the Signal
>
> Enjoying The Growth Signal? Share it with a fellow business owner and earn rewards.
>
> 🏅 **3 referrals** — The Growth Signal sticker pack
> 🏅 **10 referrals** — Our "Marketing Foundations" checklist (usually $29)
> 🏅 **25 referrals** — Free month of Marketing Office Hours
> 🏅 **50 referrals** — 1-on-1 marketing audit call with me
>
> You've referred **2 people** so far — just 1 more to unlock the sticker pack!
>
> [Share your unique link →]

---

## Block 21: Deep Dive / Feature

**Category**: Education

**Description**: The flagship block for original thinkers. A medium-length piece where you teach something from your own expertise — a framework, a lesson learned, a contrarian perspective with full evidence, a how-to from personal experience. Unlike a Hot Take (which is short and punchy), a Deep Dive develops the idea fully. Unlike a News Story (which starts with external news), a Deep Dive starts with you. This block can also be sourced from existing material — a voice memo transcript, notes from a client call, a social media comment that deserves to be expanded. This is the block that makes readers think "I can't get this anywhere else."

**Format**:
1. Block header (e.g., "The Deep Dive" or a custom name)
2. Headline — captures the core idea in one compelling line
3. The hook — 2-3 sentences that pull the reader in (a surprising claim, a question, a relatable problem)
4. The body — 4-8 paragraphs developing the idea. Can use subheads, examples, frameworks, or stories to structure the argument.
5. The takeaway — 2-3 sentences distilling what the reader should do with this information

**Example**:

> ### The Deep Dive
>
> #### Why I Stopped Tracking Vanity Metrics (And What I Track Instead)
>
> Last quarter I had my best revenue month ever. My Instagram following went down by 200. My email open rate dropped 3%. And my website traffic was flat. By every metric most marketers obsess over, things were getting worse. But my business was growing faster than it ever had.
>
> That's when I realized I'd been measuring the wrong things for years — and most small business owners are making the same mistake.
>
> **The vanity metric trap**
>
> Here's what happens: you start a business, someone tells you to "build your online presence," and suddenly you're checking follower counts and open rates like they're vital signs. They feel important. Bigger numbers feel like progress. But for most small businesses, these metrics have almost zero correlation with revenue.
>
> I had 4,200 Instagram followers. Sounds decent, right? But when I actually tracked where my paying customers came from over a 90-day period, exactly two came from Instagram. Two. Meanwhile, 31 came from email replies, 18 from Google searches, and 12 from referrals. I was spending five hours a week on the channel that produced 3% of my revenue.
>
> **What I track now**
>
> I track three numbers. That's it.
>
> First: **reply rate**. Not open rate — reply rate. How many people actually respond to my emails? A 2% reply rate means my content is sparking real conversations. Those conversations become consulting calls. Those calls become revenue. When my open rate dropped 3% last quarter, my reply rate actually went up — because I started writing emails that felt more personal and less polished. The people who stayed were more engaged than ever.
>
> Second: **inbound leads per week**. How many people are reaching out to me without me reaching out to them? This combines the effect of everything — content, SEO, referrals, word of mouth. If this number is going up, my marketing is working. I don't care which channel gets the credit.
>
> Third: **revenue per subscriber**. Total revenue divided by email list size. This tells me whether my list is full of buyers or spectators. When I cleaned my list from 3,800 to 2,100 last year, everyone thought I was crazy. My revenue per subscriber tripled. I'd rather have 2,000 people who buy than 5,000 people who scroll.
>
> **The uncomfortable truth**
>
> Most small business owners are tracking what's easy to measure, not what matters. Follower count is easy. Reply rate takes work to calculate. Website traffic is one click in Google Analytics. Revenue per subscriber takes a spreadsheet. We default to vanity metrics because they're visible, not because they're valuable.
>
> **Here's what I'd do this week:** Open a spreadsheet. Three columns: reply rate, inbound leads, revenue per subscriber. Fill in what you can. If you can't fill in a column, that itself is useful information — it means you're flying blind on a metric that actually matters. Start tracking what drives revenue, and give yourself permission to stop tracking what doesn't.

---

*(Summary table and category overview are at the top of this document for quick reference.)*

---

*Reference document for the Newsboy plugin. During setup, users browse this library and select blocks for their newsletter, customizing names and details for their specific audience.*
