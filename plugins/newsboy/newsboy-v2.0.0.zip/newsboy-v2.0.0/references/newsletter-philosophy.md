# Newsletter Philosophy

> The editorial philosophy that powers Newsboy. This document teaches Claude how great newsletters work — not how to write (Claude already knows that), but how to think about newsletter content, sourcing, and editorial judgment.

**Version**: 1.0.0
**Part of**: Newsboy plugin by theCLICK
**Used by**: Newsletter Architect skill, Produce Issue skill

---

## What Makes a Great Newsletter

A great newsletter does one thing consistently: it gives people a reason to open it every time it arrives. Not because of obligation or FOMO, but because every issue delivers something they can't easily get elsewhere — a perspective, a filter, a voice, a practical advantage.

The newsletters that sustain and grow over time share three qualities:

**They have a clear value promise.** The reader knows what they're getting before they open it. Morning Brew promises to make you smarter about business in five minutes. That promise is delivered every single issue. The promise doesn't need to be clever — it needs to be true and consistent.

**They have a voice.** The difference between a newsletter and an RSS feed is personality. A newsletter has a human behind it who has opinions, makes jokes, gets things wrong sometimes, and sounds like a real person. Voice is what turns subscribers into fans. It's why someone reads your take on the news instead of just reading the news.

**They respect the reader's time.** Every block in every issue should earn its place. If a section isn't adding value — entertainment, education, utility, connection — it shouldn't be there. The best newsletters feel dense with value, not long.

---

## Two Sources of Value

Newsletters create value from two fundamentally different sources, and most great newsletters use both.

### Curation + Interpretation

You find the best, most relevant content from external sources — news stories, data points, tools, resources, articles — and you add your interpretation for your specific audience. The value isn't in finding the information (anyone can Google). The value is in three things:

**Filtering.** You sift through hundreds of sources so your reader doesn't have to. Your editorial judgment about what's worth their attention is itself a product. When you choose to feature a story, you're saying "this matters to you, and here's why."

**Interpretation.** You translate what happened into what it means for your specific audience. A general news outlet reports that Google changed its algorithm. You tell your audience of small business owners what that means for their Google Business Profile and what they should do about it this week. The interpretation is where all the value lives.

**Consistency.** You show up on a regular cadence with a consistent format. Your reader knows that every Tuesday they'll get three stories that matter to their industry, interpreted through your lens. That reliability builds trust, and trust builds an audience.

Curation is not lesser than original content. Morning Brew built a billion-dollar media company primarily through curation and interpretation. The editorial judgment — what to include, what to skip, and what to say about it — is the product.

**Why choose curator-heavy.** Curation is often the best starting point for new newsletters. You don't need to be the world's foremost expert — you need to be a good filter. Content is always available (there's always news to curate), which means you're never staring at a blank page. The per-issue effort is lower once you have your source routines dialed in. And if your audience is busy professionals, curation is exactly what they're paying attention for — they don't have time to read 50 articles, but they'll read your five picks.

### Original Thinking

You teach from your own expertise, share your frameworks, develop your own ideas. The raw material comes from your head, not from external sources. The value is:

**Perspective no one else has.** Your specific combination of experience, expertise, and point of view is unique. When you write about why you stopped tracking vanity metrics, or share the framework you use to evaluate marketing channels, that content can't be found anywhere else. It's yours.

**Depth that curation can't reach.** A curated news story gives you the facts and a quick take. An original deep dive gives you the full argument, the evidence, the nuance, the counterarguments, the practical application. It goes deeper because you're drawing on years of experience, not a single news article.

**Trust through vulnerability.** When you share what you've learned — including what went wrong — you build a level of trust that curation alone can't achieve. Behind the scenes stories, honest lessons, and real talk create connection. People subscribe to people.

**Why choose original-thinker-heavy.** Original thinking builds the deepest reader loyalty. People subscribe to YOU, not just the information — which means competitors can't replicate your newsletter by finding the same sources. It positions you as a thought leader, which creates business opportunities beyond the newsletter itself (speaking, consulting, courses, books). The tradeoff: it takes more creative energy per issue, and you'll occasionally face the blank page. That's why many original thinkers use "here's something" mode — repurposing voice memos, social posts, and client conversations into newsletter content.

### The Blend

Most successful newsletters combine both. They curate and interpret the news AND produce original thinking. The mix is what gives a newsletter its character:

- **Curator-heavy newsletters** feel like having a smart friend who reads everything and tells you what matters. The voice comes through in the interpretation, the humor, the selection.
- **Original-thinker-heavy newsletters** feel like a mentorship or a column. The voice IS the content. External sources support the ideas but don't drive them.
- **Balanced newsletters** alternate between the two. A curated news block followed by an original deep dive, a resource roundup followed by a personal behind-the-scenes story. The alternation creates rhythm and variety.

A natural progression for many creators is to start curator-heavy — establishing consistency and building an audience with less friction — then gradually shift more toward original thinking as you develop editorial confidence, deeper relationships with your readers, and a clearer point of view. This evolution is healthy and common. The newsletter adapts as your expertise and relationship with your audience deepen.

There's no right answer. The content orientation should match the creator's strengths and their audience's needs.

---

## The Block Model

The block model is the structural foundation of a newsletter. Instead of treating each issue as a blank page, the newsletter is built from modular content blocks — each with a clear purpose, a repeatable format, and a production process.

### Why Blocks Work

**They eliminate the blank page.** The creator never stares at an empty document wondering what to write. They have a lineup of blocks, each with a defined format. The question isn't "what do I write?" but "what goes in The Scoop this week?"

**They create consistency for the reader.** Readers develop expectations. They know the newsletter opens with news, has a tip in the middle, and closes with a personal story. That predictability is comforting, not boring — it's what makes people trust that opening your email is worth their time.

**They make production systematic.** Each block has its own sourcing strategy, format template, and quality standards. Production becomes a process, not a creative marathon. This is what prevents burnout.

**They're independently flexible.** You can add a block, drop a block, swap the order, or skip a block for one issue without breaking anything. The modular structure means the newsletter can evolve without being redesigned.

### Block Pacing and Rhythm

A well-constructed newsletter has rhythm — it alternates between different types of content to maintain energy and interest:

- **Heavy blocks** (News Story, Deep Dive, Hot Take) require focused reading. They're the main courses. Don't stack three of these in a row.
- **Light blocks** (Quick Tip, Trivia, Meme, Quote) are fast reads. They give the reader a mental break between heavy sections. They're palate cleansers.
- **Personal blocks** (Behind the Scenes, Q&A) create connection. They remind the reader there's a human behind the newsletter. Place these where the reader might be losing energy — usually in the second half.
- **Action blocks** (Homework, Poll) ask the reader to do something. These are best placed after the reader has received value, not before. Give before you ask.
- **Utility blocks** (Events, Referral, Self-Promo) serve practical purposes. These typically close the newsletter because they're not what the reader opened the email for — they're bonuses.

The general pattern: open strong (news or original content), alternate heavy and light, add a personal touch in the middle, close with utility and promotion. But this is a guideline, not a rule. The assembly blueprint captures each newsletter's specific rhythm.

---

## Sourcing Philosophy

### Three Modes of Sourcing

Every content block needs raw material. That material comes from one of three places:

**Find it** — Claude searches external sources for candidates. This works for news stories, data points, tool spotlights, resource roundups — any block where the value is in curation and interpretation. The key is editorial judgment: not just finding things, but finding the *right* things for this specific audience.

**Prompt me** — The creator generates the idea in conversation. Claude asks a good question, the creator riffs, and Claude shapes the raw material into a finished block. This works for behind the scenes stories, hot takes, deep dives — any block where the creator is the source.

**Here's something** — The creator brings existing material. A voice memo transcript from a walk. A comment they left on social media. Notes from a client call. A journal entry. An email they wrote that was better than they realized. Claude ingests it and transforms it into a newsletter block. This is the repurposing mode, and it's often the most efficient path to original content because the creator has already done the thinking — they just need help with the formatting.

### Editorial Judgment

When sourcing external content, Claude should apply these editorial principles:

**Relevance over recency.** A three-week-old story that's highly relevant to the audience is better than a breaking story that's tangentially related. The newsletter isn't a news wire — it's a curated filter.

**Actionability matters.** The best stories are ones where the reader can do something with the information. "Google changed its algorithm" is news. "Google changed its algorithm, and here's what you should do about it this week" is valuable.

**Avoid the echo chamber.** If every marketing newsletter is covering the same story this week, consider whether your take adds something new. If it doesn't, find a different story that others are missing. Being the fifth newsletter to cover the same news with a similar take doesn't serve the reader.

**One story, well told, beats three stories skimmed.** Depth over breadth. If the newsletter has one news block, make it count. Go deeper on one story rather than trying to squeeze in three superficial summaries.

---

## Voice and Tone

Every newsletter has a voice — the personality that comes through in the writing. Voice is what makes two newsletters about the same topic feel completely different.

### What Voice Isn't

Voice is not a set of vocabulary rules or a list of words to use and avoid. It's not "always be casual" or "never use exclamation points." Those are surface-level style choices that can make writing feel artificial when applied mechanically.

### What Voice Is

Voice is the consistent personality behind the writing. It's:

- **How you explain things.** Do you use metaphors? Data? Stories? Blunt statements? All of the above?
- **How you relate to the reader.** Are you their expert advisor? Their peer? Their irreverent friend? Their mentor?
- **How you handle disagreement.** Do you acknowledge the other side? Dismiss it? Steel-man it? Ignore it?
- **How much of yourself you reveal.** Are you all business? Do you share personal stories? Do you crack jokes? How often?

Voice should be captured in the newsletter identity document and referenced during the Polish stage of every block. But it should be applied with judgment, not as a rigid template. The voice in a Behind the Scenes block will naturally be warmer and more personal than the voice in a News Story block — and that's correct.

---

## The Production Mindset

### Consistency Beats Perfection

The number one reason newsletters die is that the creator burns out trying to make every issue perfect. A good issue that ships on time is infinitely more valuable than a perfect issue that ships late — or doesn't ship at all.

The production workflow is designed around this principle. It provides structure, defaults, and a systematic process so that producing an issue feels like running a playbook, not performing brain surgery. Some issues will be better than others. That's normal. The newsletter's value compounds through consistency, not through any single issue being extraordinary.

### The Reader Doesn't See Your Process

The reader opens the email, reads the content, and either finds value or doesn't. They don't know whether the creator spent eight hours or 45 minutes on the issue. They don't know if the news story was the creator's first choice or their third. They don't care whether the behind the scenes story was planned for weeks or written 20 minutes before send.

This means the production workflow should optimize for the reader's experience, not the creator's perfectionism. If the content is relevant, the voice is right, and the formatting is clean — ship it.

### Compounding Value

Newsletters get easier to produce over time, not harder. The creator develops editorial instincts for what their audience cares about. The block skill files accumulate refinements. The issue log prevents repeating content. Voice consistency improves. Sourcing gets faster because the creator knows where to look.

This compounding is the real payoff of Phase One. When the newsletter identity, block configurations, and assembly blueprint are well-defined, each production cycle starts from a higher baseline than the last.

---

*Reference document for the Newsboy plugin. Both the Newsletter Architect and Produce Issue skills read this to inform editorial judgment during setup and production.*
