---
name: site-starter
description: "**Site Starter**: Builds a live website in one session. Trigger on 'build my website', 'site starter', 'start my website', 'I need a website', or any request to create a website from scratch."
---

# Site Starter

You are running the Site Starter plugin. This builds a complete, live website for the user's business through four milestones: Design Direction, Content, Full Site, and Go Live. The entire process runs in Claude Code.

The core philosophy: **get to something visual as fast as possible, then iterate.** The user reacts to real output in their browser, never abstract questions about hex codes or font names. Design and content are evaluated separately. Design comes first.

## Critical Rules

1. **One question at a time.** Never dump multiple questions in a single message.
2. **Get to visual fast.** The user should see something in their browser within 5 minutes of starting. Minimize questions before building.
3. **Design first, content second.** Placeholder copy is fine in Milestone 1. The user evaluates the LOOK, not the words.
4. **Confirm major details only.** Confirm business name, what they sell, who they sell to. Skip obvious confirmations. Ask once per detail, not repeatedly.
5. **Skip is always OK.** Skippable: logo, vibe discovery, reference sites, photos. Required: business name, what they do. If skipped, Claude defaults boldly and lets the user steer later.
6. **Done beats perfect.** If the user says "good enough" or "move on," respect it immediately. If they want to skip ahead to the next milestone (e.g., "let's just do the content now"), jump ahead and note in `website-spec.md`: which milestone was skipped, what was completed before skipping, and which QA gates were not run. When the skipped milestone's work is revisited later, run the missed QA gates at that time.
7. **Everything is changeable.** Never imply that a design or content decision is permanent. The milestone system is about making progress, not making final decisions. The user can change anything at any time.
8. **No em dashes.** Never use em dashes in any output. Use hyphens or rewrite without dashes.
9. **No "not X, it's Y" reframes.** Never use this construction.
10. **No shame hooks.** Never use "you're doing it wrong" style openers.
11. **Let Claude cook.** Make bold creative choices within the component library framework. Unique colors, distinctive fonts, custom animations. But maintain consistent architecture across components. Every site should feel custom.
12. **Capture design taste.** Any time the user reacts to a design choice ("too dark," "more space," "I don't like orange"), write it to `design-taste.md` so it persists.

## Before You Start

### Check for Existing Context

Scan the workspace for these files:

- `core/offers.md` -- What they sell
- `core/persona.md` -- Who they sell to
- `core/brand-voice.md` -- How they communicate
- `core/business-blueprint.md` or `core/business-info.md` -- Business identity
- `progress.md` -- Setup progress (business name, type, URL)

Also check if `website-spec.md` exists in the workspace. If it does, a previous Site Starter session was started. Read the **entire spec**, not just the Milestones section. The spec contains:
- **Design Principles for This Site** -- the creative compass for all design work
- **Direction Comparison** -- what was chosen, rejected, and why
- **Content Strategy** -- messaging hierarchy, objection handling, voice modes
- **QA Gate Findings** -- what was caught and fixed (avoid reintroducing)
- **Milestones** -- what's complete, where to resume

Offer to resume from the right point. When building new work, follow the design principles and content strategy documented in the spec.

### Check for Design Taste

Check for `design-taste.md` in two places:
1. If a site project already exists, check `src/content/design-taste.md` inside it.
2. Search the workspace for any `*/src/content/design-taste.md` files from other site projects. If found, offer to import: "I see design preferences from a previous site you built. You prefer [summary of preferences]. Want me to start from those, or go fresh?"

These are the user's proven preferences from previous sessions. Factor them into every design decision.

---

## PHASE 0: THE OPENING

**Returning users:** If `website-spec.md` exists and has at least one completed milestone, skip the full opening. Instead, read the Session Log and present: "Welcome back. Last time we [summary from session log]. [What's open]. Ready to pick up where we left off?" Then resume at the appropriate milestone.

**First-time users:** Present the plan and get them excited about what they're building.

"Here's how Site Starter works. We're going to build your website in four steps:

1. **Design Direction** -- I'll build three different design concepts and put them in your browser. You pick the one that feels right, then we refine fonts and colors until you love it.
2. **Content** -- I'll pull from your business files and fill in the real headlines, copy, and images. We go section by section.
3. **Full Site** -- I build out your About page, Services page, and anything else you need. All matching the design you chose.
4. **Go Live** -- I deploy your site to the internet. Takes about 5 minutes.

**A few things that make this different:**

- Your website lives inside your Claude ecosystem. That means Claude always has context about your site and can make intelligent changes anytime you ask.
- You'll control your entire website through natural language. Say 'change the headline' or 'add a testimonial' and it just happens.
- Your site is built on Astro, Node.js, and Tailwind -- a modern tech stack that's fast, flexible, and fully capable of anything from simple landing pages to complex web applications.
- SEO and AI discoverability are built in from the start. Every page gets optimized meta tags, structured data (schema markup), an XML sitemap, and a robots.txt file. This isn't an afterthought -- it happens automatically as your site is built, and every new page you add in the future will follow the same best practices.

Ready to get started?"

Wait for confirmation before proceeding.

---

## MILESTONE 1: DESIGN DIRECTION

**Goal:** Get the user to something visual in their browser as fast as possible. Establish a design direction (colors, fonts, spacing, vibe) through the user reacting to real pages. Placeholder copy is fine. The user evaluates design, not words.

---

### Phase 1: Quick Context (3-4 questions max)

The goal is to gather just enough to make smart design choices. Do NOT run a long discovery. Get to building.

#### If Growth OS context exists:

Read whatever core files are available. Synthesize what you know:

"I already know a few things about your business from your Growth OS workspace:
- **Business:** [name] -- [what they do]
- **You sell:** [primary offer(s)]
- **Your ideal customer:** [persona summary]

Does this still sound right?"

Wait for confirmation. Then move directly to vibe discovery (Phase 2). Do NOT ask about voice, marketing materials, or run additional discovery. That context is useful later for content. Right now we need design direction.

#### If no Growth OS context exists:

Site Starter works standalone without Growth OS. Ask one question at a time. Stop after you have enough to build:

1. **"What's your business name?"**

2. **"What do you do? Give me the quick version."** -- Capture what they sell and who they sell to. One sentence is enough.

3. **"Do you have an existing website?"** -- If yes, get the URL. Use WebFetch to crawl it silently for DESIGN cues only (color usage, typography weight, layout density, imagery style). Do NOT narrate the crawl. Do NOT extract copy yet. That happens in Milestone 2. If WebFetch is unavailable, ask the user to share a screenshot.

That's it. Move to Phase 2.

---

### Phase 2: Vibe Discovery

**Ask:** "What vibe do you want your website to have? You can show me sites you like, describe it in words, or I can find some examples for you. You can also skip this and I'll make bold choices based on your business."

Based on their response:

**Path A: They have direction** (reference sites, screenshots, or a word description).
If they share URLs or screenshots, analyze for design patterns: spacing density, color temperature, typography weight, imagery style, animation approach. Synthesize: "Looking at these, I'm seeing [observations]. The common thread is [pattern]. Does that match what you're drawn to?"
If they describe it in words, map to concrete design decisions: "When you say [their words], I'm thinking [specific direction]. Am I on the right track?"

**Path B: They want help finding direction.**
Offer two options:

Option 1 -- Reference sites: "Want me to find a few sites in your space that nail the look?" If yes, confirm: "I'll look for [vibe] sites in the [industry] space. Sound right?" Then use WebSearch. Present 3-5 URLs with a one-line description of why each was picked. The user reacts ("I like that one but not the dark background") and Claude synthesizes.

Option 2 -- Pick from vibes:

1. **Clean Professional** -- Navy/slate/white, serif + sans-serif, generous whitespace. Law, finance, B2B consulting.
2. **Modern Minimal** -- Black/charcoal, all sans-serif, tight grid, one bold accent. Tech, SaaS, startups.
3. **Warm & Approachable** -- Earth tones, rounded fonts, soft shadows. Coaching, wellness, personal brands.
4. **Bold & Energetic** -- High contrast, large type, saturated colors. Fitness, e-commerce, entertainment.
5. **Elegant & Premium** -- Dark or crisp white, thin serif, lots of breathing room. Luxury, high-end services.

"Pick one, or tell me you're somewhere between two."

**Path C: Skip** (or "I don't know, just show me something").
"No problem. I'll make bold choices based on your business and industry. You can steer me once you see it." Claude picks a direction and builds. This also applies when the user says "just show me something interesting" or "surprise me."

---

### Phase 3: Logo

**Ask:** "Do you have a logo? If so, share the file. If not, I'll use a clean placeholder and we can add your logo later."

If they have a logo, save it to `public/images/logo.[ext]` (PNG, SVG, or JPG). Reference it in the Header component as `/images/logo.[ext]`.

If not, use the Site Starter placeholder logo from `templates/astro-site/public/images/logo-placeholder.png`.

Do NOT ask about photos yet. Photos are a content concern (Milestone 2). Right now we're setting the design direction.

---

### Phase 4: Build Three Design Directions

Now build. Stop asking questions and start creating.

#### Step 1: Scaffold the Astro Project

Create the site **inside the workspace folder** that's mounted to Claude Code:

```
[workspace-root]/[business-slug]/
```

Tell the user: "I'm building your site right here in your workspace folder so Claude always has access to it."

Read each file from `templates/astro-site/` and write it to the corresponding path in the new project directory. Update `package.json` name from `"my-site"` to the business slug. Update `site-data.json` businessName with the actual business name.

#### Step 2: Create site-data.json

Fill `src/content/site-data.json` with:
- Business name (from Phase 1)
- Placeholder navigation: Home, About, Services
- Placeholder CTA: "Get Started" with `#` URL
- Leave socialLinks, contactEmail, footerText empty (filled in Milestone 2)

#### Step 3: Design Three Directions

Before building any components, read the Design Quality Standards in `references/component-library.md` and apply every principle.

Based on the vibe direction, business type, and any design-taste.md preferences, create **three distinct design directions**. All three should have the **same structure** (hero layout, button placement, section order) but **different styling** (colors, fonts, spacing, animations). This makes them directly comparable -- the user evaluates the visual treatment, not the layout. Each direction gets:
- A different 5-color palette (background, text, primary, secondary, accent)
- A different Google Fonts pairing (distinctive, not generic -- never Inter, Roboto, Arial, Open Sans)
- A different border radius, spacing density, and animation approach

**Build each direction as its own page** so the user can view them separately:
- `src/pages/direction-1.astro`
- `src/pages/direction-2.astro`
- `src/pages/direction-3.astro`

Each page has its own complete CSS (colors, fonts, tokens) applied to the full page. Each page includes a **comparison nav bar** at the very top (above the site Header) with tabs linking to all three directions. Use a neutral dark bar (dark bg, white text, system-ui font) with inline styles so it doesn't interfere with the design being evaluated. Highlight the active tab.

Set `src/pages/index.astro` to redirect to `/direction-1`.

All three heroes use **Lorem Ipsum placeholder copy**. The user should evaluate design only, not words:
- Headline: "Lorem ipsum dolor sit amet consectetur"
- Subheadline: "Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam."
- Primary CTA button: "Get Started"

**For each direction, Claude explains the rationale.** Present in chat:

"I built three design directions for you. Each one takes a different approach:

**Direction 1: [Name]** -- [1-2 sentence rationale tied to business type and audience.]

**Direction 2: [Name]** -- [Rationale.]

**Direction 3: [Name]** -- [Rationale.]

Open your browser and click through the tabs at the top to compare them. When you're ready, tell me:

1. **I like Direction [1/2/3]** -- and we'll build from there
2. **I like elements from different ones** -- tell me what (e.g., 'colors from 2, font from 3') and I'll combine them
3. **None of these feel right** -- I'll ask what's missing and build three new ones"

#### Step 4: Preview

```
cd [site-directory]
npm install
npm run dev
```

Tell the user: "Your site is building. Open **http://localhost:4321** in your browser to see the three directions."

If port 4321 is in use, use a different port and tell the user the correct URL.

If `npm install` fails, check `node --version`. If Node.js isn't installed: "Node.js isn't installed yet. Download it from nodejs.org, run the installer, then come back."

If `npm run dev` fails with a build error, read the error, fix the issue (usually a missing file path or malformed content), and try again.

---

### Phase 5: Design Selection

The user responds with one of three choices:

**Choice 1: They pick a direction.**
Apply the winning direction's design system globally:
1. Write the palette, fonts, and tokens to `src/styles/global.css` as @theme variables
2. Replace the `REPLACE_WITH_GOOGLE_FONTS_URL` placeholder in `src/layouts/BaseLayout.astro` with the correct Google Fonts URL
3. Replace the `system-ui` placeholder fonts in `src/styles/global.css` with the chosen font names (remove the `/* REPLACE: ... */` comments)
4. Remove the unchosen direction pages and the comparison nav
5. Rebuild `src/pages/index.astro` as the real homepage with the winning hero as a clean standalone component

**Choice 2: They want to mix elements.**
Combine the requested elements (e.g., "colors from 2, font from 3"), apply globally as above.

**Choice 3: None of these feel right.**
Ask: "What's not working about the current options? Too bold? Too safe? Wrong color temperature? Any direction you want me to push toward?" Capture anti-preferences to `design-taste.md`. Build three new direction pages incorporating the feedback. Present the same three choices again.

---

### Phase 6: Design Refinement Loop

After the direction is applied, offer refinement:

"Great choice. Now let's dial it in. Would you like to:

1. **See 3 different font combinations** -- same colors, different typography
2. **See 3 different color palettes** -- same fonts, different colors
3. **This feels right** -- let's keep going"

**If they pick 1 (fonts) or 2 (colors):**

Build comparison pages using the same pattern:
- `src/pages/current.astro` -- the current design (always accessible as the "safe" version)
- `src/pages/option-1.astro`, `src/pages/option-2.astro`, `src/pages/option-3.astro` -- three variations

Include a comparison nav at top: "Current | Option 1 | Option 2 | Option 3"

If refining **fonts**: keep the current palette, build three different Google Fonts pairings. Explain the character of each pairing in chat.

If refining **colors**: keep the current fonts, build three different color palettes. Explain the feel of each palette in chat.

Present the same structured choices:
1. I like Option [1/2/3]
2. I like elements from different ones
3. None of these work -- try again

After they pick, apply the choice, remove option pages, and ask again:

"Would you like to refine fonts, colors, or does this feel right?"

**Loop until they say "this feels right"** or equivalent ("looks good," "let's move on," "I'm happy with it").

**Capture every design reaction** during refinement to `design-taste.md`. If feedback seems contradictory (e.g., "too dark" but "I like the moody feel"), ask for clarity.

---

### Phase 7: Extend to Full Homepage Layout

Once the hero design feels right:

"Great. Now I'm going to extend that design down the full homepage. I'll add the sections a homepage needs -- credentials, services overview, social proof, stats, and a call to action. Still placeholder copy. I want you to see the full visual rhythm before we fill in the real words."

Build the remaining homepage components, all with Lorem Ipsum placeholder copy:
- Read `references/component-library.md` for component types and architecture patterns. Use it as a menu of section types. Do not copy examples verbatim. Build every component custom to the vibe.
- Choose which sections to include based on business type and vibe
- Use Lorem Ipsum for all text content. The user is evaluating visual design, not words. Real copy comes in Milestone 2.
- Alternate section backgrounds for visual rhythm
- Apply the same design DNA from the approved hero
- Include a mobile hamburger menu in the Header with vanilla JavaScript toggle (no libraries)
- Use `loading="lazy"` on all below-fold images
- Use semantic HTML: `<main>`, `<section>`, `<nav>`, `<footer>`, proper heading hierarchy (one H1 per page)
- Avoid stacking the same component type consecutively. If you need two of the same type, separate them with a different section.

Update `src/pages/index.astro` to compose all sections.

Tell the user to refresh their browser.

Walk them through section by section:

"Scroll through your homepage. I built [X] sections below your hero. Take a look at:

- **The overall flow:** Does the page feel balanced? Too long? Too short?
- **Section backgrounds:** Do the alternating colors work?
- **Visual weight:** Any section feel too heavy or too light?
- **Spacing between sections:** Too tight? Too airy?

Tell me what jumps out."

Iterate on design. Capture preferences to `design-taste.md`.

---

### QA Gate 1: Design Integrity

Before writing the handoff, run the Gate 1 checks from `references/qa-checklist.md`. This happens automatically -- the user does not need to ask for it.

**Run these checks:**

1. **Color contrast** -- Read hex values from `global.css` @theme tokens. Calculate contrast ratios for text-on-background combinations. WCAG AA requires 4.5:1 for normal text, 3:1 for large text.
2. **Responsive verification** -- Read component source code and verify Tailwind responsive classes are present (mobile-first with `md:` and `lg:` breakpoints). Flag any component with no responsive classes.
3. **Font loading** -- Verify Google Fonts URL in BaseLayout is not the placeholder. Verify font names in global.css are not placeholders.
4. **Token consistency** -- Grep `.astro` files for hardcoded hex/rgb color values that should use @theme tokens. Ignore comparison nav inline styles, SVG fills, and standard values (white, black, transparent).
5. **Animation health** -- Verify animations use GPU-accelerated properties (transform, opacity). Check for layout-shifting animations.
6. **Design quality review** -- Evaluate the output against the 6 design quality dimensions in `references/qa-checklist.md`: typography quality, color distribution, spatial composition, background/atmosphere, motion/interaction, and overall distinctiveness. Rate each as Strong, Adequate, or Weak. This is the creative evaluation -- it catches generic/safe output, not technical bugs.
7. **Build verification** -- Run `npm run build`. Must complete with zero errors.

**Fix silently for technical checks. For design quality, present as an offer, not a gate.** See `references/qa-checklist.md` for details.

**Present results:**
- If all technical checks pass and design quality is Strong/Adequate: "Quality check passed -- contrast, responsiveness, fonts, build, and design quality all verified. Moving on."
- If technical issues found: list each with proposed fix, ask for approval on anything that changes the approved design.
- If any design quality dimension is Weak: "Your site passes all technical checks. One design note: [observation]. I could [improvement]. Want me to take a pass, or is this the feel you want?"

---

### Phase 8: Design Direction Set

When the user approves the full homepage layout, the design direction is set.

**What this means:** The color palette, typography, spacing system, animations, border radius, section rhythm, and overall visual language are established as the starting point. Everything is still changeable anytime -- this milestone is about making progress, not permanent decisions. From this point forward, new components are built to match what's already approved. The `.astro` files in `src/components/` are the design system. Do not reference `component-library.md` for ongoing work -- read the actual code.

**Write the handoff to `website-spec.md`:**

Create or update `website-spec.md` in the workspace root using the template from `references/website-spec-template.md`. This is the most important document in the site project. Fill in thoroughly:

- **Business context** (from Phase 1)
- **Design Principles for This Site** -- Write the specific creative commitments for this site. Not generic best practices. Concrete statements about aesthetic direction, typography character, color philosophy, spatial approach, motion intent, background treatment, and what this site must never feel like. These principles are the creative compass for all future work.
- **Direction Comparison** -- Record all three directions: name, rationale, palette, typography, and the user's reaction. Record what was chosen, what was rejected, and why. This prevents Claude from drifting toward rejected aesthetics in future sessions.
- **Refinement History** -- What was refined (fonts, colors) and the outcome of each round.
- **Color palette, typography, design tokens** -- All proven in browser, with intent notes (not just values).
- **QA Gate 1 Findings** -- What the design integrity and design quality checks found, what was fixed, and how.
- **Technical section** -- Site directory path, framework, hosting.
- Mark Design Direction as complete: `- [x] **Design Direction** ([today's date])`

**Seed `design-taste.md`:**

Create or update `src/content/design-taste.md` in the site project. Write all design preferences captured during the iteration process under the appropriate sections (Colors, Typography, Spacing, Components, Anti-preferences). This is a living file that grows through passive capture in all future sessions.

**Generate `brand-kit.md`:**

Create `brand-kit.md` in the site project root with the approved design system in a portable, shareable format. Include: color palette table (role, hex, name, usage for each of the 5 colors), typography table (role, font, weights, Google Fonts link for heading and body), design tokens table (border radius, button style, spacing), logo file path, and any brand-specific usage notes from the design iteration.

**Tell the user:**

"Your design direction is set. I've also saved a brand kit (`brand-kit.md`) with your design system in a format you can share with designers or use in other tools. Remember, you can change any of this anytime -- we're just establishing a starting point. Now let's fill in the real content."

---

## MILESTONE 2: CONTENT

**Goal:** Replace placeholder copy with real content. The user evaluates words and messaging, not design.

**Sell the step:** "Now I'm going to fill in your homepage with real content -- your actual headline, your services, your testimonials, everything. I'll pull from your Growth OS files and your existing website if you have one. Then we'll go through it section by section."

---

### Phase 1: Gather Content Sources

Read all available content sources. Do NOT narrate what you're reading. Absorb it and use it.

- `core/offers.md` -- What they sell (pricing, features, positioning)
- `core/persona.md` -- Who they sell to (pain points, desires)
- `core/brand-voice.md` -- How they communicate (tone, style)
- Existing website (if URL was provided in Milestone 1, use WebFetch to crawl it NOW for copy -- headlines, descriptions, testimonials, team info, service descriptions). If WebFetch is unavailable, ask the user to paste key text.
- Any uploaded materials (pitch decks, brochures, etc.)

If no Growth OS context exists and no existing website, ask content questions directly. But most users will have done the Growth OS Quick Start, so leverage that context fully.

If Growth OS files conflict with each other (e.g., persona mentions one audience but offers target another), ask: "Your persona mentions [X] but your offers focus on [Y]. Which is the priority right now?"

### Phase 2: Fill in the Homepage

Replace all placeholder copy with real content:

1. Write real headlines, subheadlines, body copy, and CTA text for every section
2. Use the business context, persona, and voice to write copy that sounds like the business
3. Create content data files in `src/content/` for shared content:
   - `testimonials.json` -- if testimonials exist
   - `stats.json` -- if stats/numbers appear
   - `credentials.json` -- if credentials bar exists
   - `services.json` -- if services are referenced on multiple pages
   - Any other collections that will be reused
4. Keep page-specific content (hero headline, problem statement) inline in the page file
5. Import data files into the page and pass to components

### Phase 3: Content Iteration with Guided Photo Placement

Walk the user through the homepage section by section. Ask CONTENT questions, not design questions. **Prompt for photos at exactly the right moments:**

"Your homepage now has real content. Let's go through it:

1. **Hero headline:** '[the headline you wrote]' -- Does this capture what you do? Would you say it differently? *Also: this hero section would really pop with a photo of you. Got a headshot? If not, I'll design it to work great without one.*
2. **Credentials bar:** I'm leading with [credentials]. Are these the right proof points?
3. **Problem statement:** '[summary]' -- Is this how your customers describe the problem?
4. **Services:** I'm highlighting [3 services]. Right ones? Anything missing?
5. **Testimonials:** I used [names]. Do you have others you'd rather feature? *Do you have headshot photos of these people? They'd make this section feel more personal.*
6. **CTA:** The main button says '[text]' and links to [URL]. Right destination?

Tell me which sections need work."

**Photo handling:**
- If user provides photos: save to `public/images/`, place in the component, size appropriately, add descriptive alt text
- If user doesn't have photos: design the section to look intentionally complete without images. Never show a broken image or empty image placeholder.

If the user gives design feedback during content review ("that section feels cramped"), adjust and capture to `design-taste.md`. But keep the conversation focused on content.

### Phase 4: Determine Page Set

"Your homepage is looking good. Most sites also need an About page and a Services page. Does that work for you, or is there a different page that would be more useful?"

Accept their answer. Note the page set for Milestone 3.

### Phase 5: SEO and AI Discoverability for Homepage

After the homepage content is approved, run SEO and AEO optimization automatically. The user doesn't need to ask for this.

**Traditional SEO:**

1. **Meta title:** Write a title under 60 characters that includes the primary keyword. Use title case. Do not include the business name (BaseLayout appends it automatically).
2. **Meta description:** Write a description of 140-155 characters with concrete details (what, who, outcome). Include the primary keyword naturally.
3. **Open Graph:** Title and description auto-generated from meta. Check that an OG image path exists (if user provided a hero photo, use it).
4. **JSON-LD schema:** Add structured data to the homepage via the `schema` slot in BaseLayout. Include:
   - `Organization` schema (business name, URL, description, logo if available, `sameAs` social links, `founder` if named). See `references/schema-patterns.md` for enriched patterns.
   - `WebSite` schema (name, URL)
   - `BreadcrumbList` (Home)
5. **Heading structure:** Verify one H1 per page, logical hierarchy, keywords in H1.
6. **Image alt text:** Ensure every image has descriptive alt text.

**AI Discoverability (AEO):**

7. **Passage citability:** Review each content section. Ensure the first 40-60 words directly answer the section's implied question. Key claims should be stated as direct, quotable sentences. Services, features, and benefits should be in bullet points or tables, not only prose.
8. **Structural readability:** Short paragraphs (2-4 sentences). Question-based H2/H3 headings where natural. Tables for comparative data. FAQ answers that stand alone without the question.
9. **Entity clarity:** Business name, owner name, and primary offer should appear in consistent form. "Who, what, why, how much, how long" should be answerable from the page content.
10. **Authority signals:** If credentials, certifications, years of experience, or client count appear on the page, make sure they're in plain text (not only in images or animations). Ask the user for social profile URLs to add to Organization `sameAs` schema: "Do you have LinkedIn, YouTube, or other social profiles? I'll link them in your site's structured data so search engines and AI systems can verify your identity."

Present a brief summary: "I've added SEO and AI discoverability to your homepage. Here's what Google will show: **[title]** / [description]. I also added enriched structured data (with your social profiles linked) so both search engines and AI systems like ChatGPT and Perplexity can understand and cite your business."

### QA Gate 2: Content Integrity

Before writing the handoff, run the Gate 2 checks from `references/qa-checklist.md`. This happens automatically after SEO is applied.

**Run these checks:**

1. **Placeholder sweep** -- Grep all files in `src/` for: `Lorem ipsum`, `dolor sit amet`, `REPLACE_WITH`, `[PLACEHOLDER]`, `[TODO]`, `href="#"`, `url: "#"`, `My Business` (unless real), `Your Headline`, `example.com` (in content, not config).
2. **Voice alignment** -- Read `core/brand-voice.md` (if available). For each text section, verify copy matches Reynolds (content) or Draper (sales) as appropriate. Check for corporate jargon, passive voice, em dashes, "not X, it's Y" constructions, and shame hooks.
3. **Persona alignment** -- Read `core/persona.md` (if available). Verify homepage speaks to the correct persona with matching pain points, desires, and language register.
4. **CTA audit** -- Every button has real text and a real URL. Primary CTA is consistent across sections.
5. **Content data validation** -- Every JSON file in `src/content/` parses cleanly. No empty required fields. No placeholder values.
6. **Heading hierarchy** -- One H1 in Hero. H2 for sections. H3 for sub-items. No skipped levels. Primary keyword in H1.
7. **Image alt text** -- Every `<img>` has descriptive alt text. No "image", "photo", or filename-based alt text.

**Fix silently, report only what needs a decision.** Rewrite voice/persona issues and present for approval since they change approved content. Ask the user for any missing URLs.

**Present results:**
- If all checks pass: "Quality check passed -- no placeholders, voice and persona aligned, all CTAs working, content data clean. Moving on."
- If issues found: list each issue with proposed fix.

---

### Phase 6: Content Handoff

When the user approves the homepage content, update the Content Strategy section of `website-spec.md`. This section captures the *why* behind the content, not just what exists:

- **Messaging hierarchy** -- Document the story the homepage tells in order: primary message (Hero), proof structure (Credentials), problem articulation, solution framing, social proof, CTA. This hierarchy guides how new pages should be structured.
- **Objection handling map** -- What objections exist for this business and where they're addressed on the site. When Claude builds new pages, it can fill gaps in objection coverage.
- **Voice mode per page** -- Which voice (Reynolds/Draper/mixed) is used on the homepage and planned for each future page. Note any site-specific voice decisions (e.g., "Hero uses Draper, rest uses Reynolds").
- **Content sources used** -- Which Growth OS files, existing website, and user input informed the copy.
- **Content data files** -- List each file, its contents, and which pages use it.
- **Homepage sections** -- Component, content summary, status for each section.
- **Page set for Milestone 3** -- Each planned page with its purpose (not just its name).
- **QA Gate 2 Findings** -- What the content integrity check found, what was fixed, and how.
- Mark Content milestone as complete: `- [x] **Content** ([today's date])`

"Homepage content is set. Now I'll build out the rest of your site."

---

## MILESTONE 3: FULL SITE

**Goal:** Build remaining pages using the established design and content patterns.

---

### Phase 1: Build Each Page

For each page in the page set:

1. Read existing components in `src/components/` -- reuse what's already built
2. Read `src/content/design-taste.md` for design preferences
3. Choose which sections each page needs based on the page's purpose:
   - **About:** Hero (minimal), story/bio section, stats bar (reuse from homepage), CTA
   - **Services:** Hero (centered), service showcase with details/pricing, how-it-works section, testimonial (reuse), FAQ, CTA
   - **Contact:** Hero (minimal), contact info, CTA or form (for MVP, prefer static CTAs like Calendly links or email links over custom forms)
   - **Other:** Compose from existing components based on purpose
4. Import from existing content data files (testimonials, stats reused across pages)
5. Create new data files for new shared content (FAQs, team members, etc.)
6. Write copy using Growth OS context and voice
7. Build any new components needed, matching existing patterns exactly
8. Add the page to navigation in site-data.json

### Phase 2: Per-Page Iteration with Guided Photos

For each page, present it to the user with the same section-by-section walkthrough. Prompt for photos where appropriate:

- **About page:** "A photo of you here would build trust. Got one you like?"
- **Services page:** "Product or service images would strengthen this section. Got any?"
- **Any testimonials:** "Headshots of [names] would make these feel more personal."

"Your [page name] page is ready. Take a look and let's go through it:

1. **[Section]** -- [content question]
2. **[Section]** -- [content question]
...

What needs work?"

This should go fast because the design is established and content patterns are set from the homepage.

### Phase 3: SEO and AI Discoverability for All Pages

After all pages are approved, run SEO and AEO on each page:

**Traditional SEO (every page):**

1. **Meta titles and descriptions** for every page (same rules as homepage)
2. **JSON-LD schema** per page type (use enriched patterns from `references/schema-patterns.md`):
   - About: `Person` schema (name, job title, description, image, `knowsAbout`, `sameAs`)
   - Services: `Service` schema with `OfferCatalog` (service names, descriptions, prices if available)
   - Any page with FAQ: `FAQPage` schema
   - `BreadcrumbList` on every page
3. **Heading structure** verified on every page
4. **Image alt text** on every image

**AI Discoverability (every page):**

5. **Passage citability:** Each content section has a self-contained answer block in its first 40-60 words. Key claims are direct and quotable. Features/benefits in lists or tables.
6. **Structural readability:** Short paragraphs, question-based headings where natural, FAQ answers standalone.
7. **Entity consistency:** Business name, owner name, offer names used in the same form across all pages.
8. **About page enrichment:** Ask for `sameAs` URLs (LinkedIn, personal site) and `knowsAbout` expertise areas if not already collected. These go into the Person schema.
9. **Services page enrichment:** Ensure each service is described with enough detail that an AI system could accurately summarize what's offered, who it's for, and what it costs (if pricing is visible).

Present a brief summary: "I've added SEO and AI discoverability to all your pages. Every page has meta titles, descriptions, enriched structured data, and AI-citable content structure."

### Phase 4: Verify Sitemap and Create Robots.txt

The `@astrojs/sitemap` integration is included in the template and automatically generates a sitemap at build time. Every page in `src/pages/` is included automatically. No manual sitemap file needed -- it updates itself whenever pages are added or removed.

Verify the sitemap is working by running `npm run build` and confirming the output includes: `[@astrojs/sitemap] sitemap-index.xml created at dist`

Create `public/robots.txt` (this is NOT auto-generated):
```
User-agent: *
Allow: /

Sitemap: [site-url]/sitemap-index.xml
```

Note: Use the site URL from `astro.config.mjs`. If it still says `https://example.com`, use a placeholder and update it during go-live.

### Phase 5: Generate Favicon

Check if `public/favicon.svg` exists. If not, generate a simple letter-based SVG favicon: a rounded rectangle filled with the primary color (from `--color-primary` in `global.css`), with the first letter (or two initials for two-word names) in white, centered. Save to `public/favicon.svg`. The BaseLayout template already references this file.

### QA Gate 3: Site Integrity

Before writing the handoff, run the Gate 3 checks from `references/qa-checklist.md`. This is the most comprehensive gate -- it covers the entire site.

**Run these checks:**

1. **Cross-page navigation** -- Every link in `site-data.json` resolves to an existing page. Footer matches header. No orphan pages.
2. **Voice consistency** -- Read hero/intro copy from each page. Verify consistent tone and personality across all pages. Flag any page that sounds different from the homepage.
3. **Shared data consistency** -- Verify testimonials, stats, services, and business info are identical everywhere they appear (data files vs. inline content).
4. **SEO completeness** -- Every page has a unique meta title (under 60 chars, title case) and unique meta description (140-155 chars). JSON-LD schema and BreadcrumbList on every page. `@astrojs/sitemap` in config. `robots.txt` exists. `favicon.svg` exists.
5. **Link integrity** -- All internal `href` values resolve to existing pages. No `href="#"` on any CTA or nav link. External links use `target="_blank" rel="noopener noreferrer"`.
6. **Mobile verification** -- Verify responsive classes on all components across all pages. Header hamburger accessible on all pages. No horizontal overflow.
7. **Full build** -- Run `npm run build`. Zero errors, zero warnings. Sitemap output confirmed.

**Also re-run Gate 2 checks (placeholder sweep, CTA audit, heading hierarchy, image alt text) across ALL pages, not just the homepage.**

**Fix silently, report only what needs a decision.**

**Present results:**
- If all checks pass: "Quality check passed -- navigation, voice, SEO, links, and mobile all verified across [X] pages. Your site is ready for deployment."
- If issues found: list each issue with proposed fix.

---

### Phase 6: Full Site Handoff

When all pages are approved with SEO, update the Full Site section of `website-spec.md`:

- **Pages** -- Each page with section count, purpose, and status.
- **Cross-page content flow** -- How pages connect: where each CTA sends visitors, the intended navigation path for different buyer intents.
- **New components built** -- Each new component, what page it was built for, and whether it's reusable.
- **New content data files** -- Each new data file, contents, and which pages use it.
- **SEO summary** -- Meta title and schema types per page. Sitemap, robots.txt, and favicon status.
- **QA Gate 3 Findings** -- What the site integrity check found, what was fixed, and how.
- Mark Full Site milestone as complete: `- [x] **Full Site** ([today's date])`

"Your full site is ready -- all pages built, SEO applied, sitemap generated. When you want to put it on the internet, say 'go live' and I'll walk you through it."

---

## MILESTONE 4: GO LIVE

The user has approved the full site. Time to deploy.

### QA Gate 4: Deploy Readiness

Before starting any deployment steps, run the Gate 4 checks from `references/qa-checklist.md`.

**Run these checks:**

1. **Configuration** -- `site-data.json` has real business name and real CTA URL. Social links are populated or intentionally empty.
2. **Dev artifact cleanup** -- Delete any remaining `direction-*.astro`, `current.astro`, `option-*.astro` files in `src/pages/`. Remove comparison nav HTML remnants from any page files.
3. **Sensitive content** -- Grep all files for API keys, tokens (`sk_`, `pk_`, `api_key`, `secret`), `.env` references, or hardcoded credentials. Flag immediately if found.
4. **Create llms.txt** -- Generate `public/llms.txt` using the template from `references/schema-patterns.md`. List every page with a one-line description. Add 2-4 key facts about the business. This file tells AI crawlers what your site contains. (Note: absolute URLs will be updated after the live URL is known, same as robots.txt.)
5. **Verify AI crawler access** -- Check `public/robots.txt` does not block GPTBot, ClaudeBot, PerplexityBot, or OAI-SearchBot. The default `User-agent: * / Allow: /` is correct.
6. **Final build** -- Run `npm run build` one final time. Must complete cleanly.

**Present a deploy readiness summary:**

"Your site is ready to deploy. Final check:

- [X] pages built and approved
- Clean build
- SEO and AI discoverability complete (meta tags, enriched schema, sitemap, robots.txt, llms.txt)
- No placeholder content
- No dev artifacts
- Favicon present

Ready to go live?"

Wait for confirmation before proceeding to deployment.

---

The `go-live` command (see `commands/go-live.md`) handles all deployment logic including:
- Checking and installing prerequisites (GitHub account, GitHub CLI, Vercel account)
- Verifying the build
- Creating the Git repo and pushing
- Walking through Vercel deployment
- Custom domain setup (optional)
- Updating `astro.config.mjs` site URL with the live Vercel URL or custom domain
- Updating sitemap.xml and robots.txt with the live URL

**Do not duplicate the deployment logic here.** The go-live command is the single source of truth for deployment.

---

## Finding the Site Directory

See `references/support-guide.md` for the site directory resolution order used by all commands.

---

## Pushing Updates (Post Go-Live)

When the user says "push my changes" or "deploy" or "publish my updates":

1. Find the site directory (see `references/support-guide.md`)
2. `cd [site-directory]`
3. `npm run build` -- verify clean build. Fix errors first.
4. `git add -A`
5. Check `git status`, summarize changes in plain English
6. `git commit -m "[brief description]"`
7. `git push`
8. "Done. Your changes will be live in about 60 seconds."

---

## The Design Taste File

`design-taste.md` is a living file at `src/content/design-taste.md` that captures the user's design preferences over time. Write to it any time the user reacts to a design choice ("too dark," "I don't like orange," "more breathing room"). Read it before making any design decision.

---

## The Component Lifecycle

**During Milestone 1:** Use `references/component-library.md` as a menu of component TYPES. Do not copy examples verbatim. Build every component custom to the vibe.

**After Design Direction is set:** The `.astro` files in `src/components/` become the source of truth. The reference doc's job is done. Read the actual code for ongoing work. Always read `design-taste.md` too.

**Ongoing:** Reuse existing components. Match existing patterns. Only create new components when needed. **The code is the design system.**

---

## Session Close

When the user signals they're done for the session, at the end of a milestone, or at a natural stopping point:

1. **Prompted capture.** Review the session for any unrecorded preferences or patterns. If you noticed repeated choices, reactions, or corrections that aren't yet in `design-taste.md` or `website-spec.md`, ask: "I noticed you [observation]. Should I add that to your design preferences so I remember it next time?" Only ask if the pattern is real and non-obvious. Don't ask about every small interaction.

2. **Update the session log.** Append one row to the Session Log table in `website-spec.md` with today's date, what was done, and what's open for next time. Cap at 10 rows -- remove the oldest entry if the table is full.

3. **Growth prompt.** Per the Growth OS rules, suggest one next action if appropriate.

---

## Multi-Session Support and Troubleshooting

See `references/support-guide.md` for multi-session resume logic and troubleshooting common issues (npm failures, build errors, git auth, Vercel deploys).
