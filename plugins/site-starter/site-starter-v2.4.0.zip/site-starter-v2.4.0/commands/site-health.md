---
name: site-health
description: "**Site Health**: Post-launch health check for your website. Trigger on 'site health', 'check my site', 'audit my site', 'is my site working', or any request to verify site quality after deployment."
---

# Site Health

Runs a post-launch health check on the deployed website. This is a re-check of the same quality standards enforced during the build by QA Gates 1-4. It catches issues introduced after deployment: content drift, new pages without SEO, broken links from URL changes, regressions from manual edits.

The full QA criteria are defined in `references/qa-checklist.md`. This command runs all four gates as a single pass.

## Critical Rules

1. **No em dashes.** Use hyphens or rewrite without dashes.
2. **Present results simply.** Pass/fail format. No technical jargon.
3. **Offer to fix everything found.** Don't just report problems -- offer solutions.

## Find the Site Directory

See `references/support-guide.md` for the resolution order. Find the site directory before proceeding.

## What It Checks

Run all checks from `references/qa-checklist.md` in this order:

### From Gate 1: Design Integrity
- **Build verification** -- `npm run build` succeeds without errors or warnings
- **Color contrast** -- Text-on-background contrast meets WCAG AA (4.5:1 normal, 3:1 large)
- **Font loading** -- Google Fonts URL is real (not placeholder). Font names in global.css are real.
- **Token consistency** -- No hardcoded hex/rgb values that should use @theme tokens
- **Responsive** -- All components have responsive Tailwind classes

### From Gate 2: Content Integrity
- **Placeholder content** -- No Lorem ipsum, `href="#"`, `[PLACEHOLDER]`, template strings, or unreplaced placeholders in any file
- **Voice alignment** -- Copy matches brand voice (if `core/brand-voice.md` exists)
- **CTA audit** -- Every button has real text and a real URL
- **Content data** -- All JSON files in `src/content/` parse cleanly, no empty required fields
- **Heading hierarchy** -- One H1 per page, logical H2/H3, no skipped levels
- **Image alt text** -- Every `<img>` has descriptive alt text

### From Gate 3: Site Integrity
- **Navigation** -- All nav links resolve to existing pages. No orphan pages.
- **SEO completeness** -- Every page has unique meta title, unique meta description, JSON-LD schema, BreadcrumbList
- **Sitemap** -- `@astrojs/sitemap` in config, builds successfully
- **Robots.txt** -- Exists, points to `sitemap-index.xml`
- **Favicon** -- `public/favicon.svg` exists, referenced in BaseLayout
- **Link integrity** -- All internal links resolve. No `href="#"`. External links use `target="_blank"`.
- **Accessibility** -- One H1 per page, logical heading hierarchy, interactive elements have labels, mobile viewport meta present

### From Gate 4: Deploy Readiness
- **Site configuration** -- `astro.config.mjs` site field is a real URL (not `https://example.com`)
- **Business identity** -- `site-data.json` has real business name (not placeholder)
- **Dev artifacts** -- No `direction-*.astro`, `option-*.astro`, or `current.astro` pages remaining
- **Sensitive content** -- No API keys, tokens, or credentials in source files

### AI Discoverability (AEO)
- **Passage citability** -- Each page has self-contained answer blocks in opening 40-60 words of each section. Key claims are direct and quotable. Features/benefits in lists or tables.
- **Entity consistency** -- Business name, owner name, offer names identical across all pages, schema, and meta tags
- **Schema enrichment** -- Organization schema has `sameAs` social links. Person schema has `knowsAbout` and `sameAs`. All schema matches visible content.
- **llms.txt** -- `public/llms.txt` exists with all pages listed and key facts
- **AI crawler access** -- `robots.txt` does not block GPTBot, ClaudeBot, PerplexityBot, OAI-SearchBot
- **Content structure** -- Short paragraphs, question-based headings, no critical content behind JS

## Output Format

Present as a simple report:

"**Site Health Report**

| Check | Status |
|-------|--------|
| Build | Pass |
| Color contrast | Pass |
| Fonts | Pass |
| Responsive | Pass |
| Placeholder content | Pass |
| Voice alignment | Pass |
| CTAs | Pass |
| Content data | Pass |
| Headings | Pass |
| Image alt text | Pass |
| Navigation | Pass |
| SEO | Pass |
| Sitemap | Pass |
| Robots.txt | Pass |
| Favicon | Pass |
| Links | Pass |
| Accessibility | Pass |
| AI citability | Pass |
| Entity consistency | Pass |
| Schema enrichment | 1 issue |
| llms.txt | Pass |
| AI crawler access | Pass |
| Configuration | Pass |
| Dev artifacts | Pass |
| Sensitive content | Pass |

**Issues found:**
1. [issue description] -- [how to fix]

Want me to fix these?"

If everything passes:

"Your site is healthy. All 25 checks passed. You're good."
