---
name: new-page
description: "**New Page**: Adds a new page to your website. Trigger on 'add a page', 'new page', 'build me a [X] page', or any request to create a new page on the site."
---

# New Page

Adds a new page to the user's existing website.

## Critical Rules

1. **One question at a time.** Don't overwhelm with options.
2. **Read the actual component files first.** Before building anything, read every `.astro` file in `src/components/`. These are the approved design system. Do NOT reference `references/component-library.md` for ongoing work -- that was the blueprint for the initial build. The code is the source of truth now.
3. **Reuse existing components.** Import and compose from what's already built. Pass new content via props. Do not rebuild components that already exist.
4. **Match existing patterns exactly.** When you need a new component type, read the existing ones first. Match their spacing, their Tailwind token usage, their props architecture, and their responsive patterns. The new component should be indistinguishable in quality and style from the originals.
5. **Check `src/content/` for existing data files.** Before hardcoding testimonials, stats, services, or other collection content as inline props, check if a JSON data file already exists in `src/content/`. If it does, import and use it. If you're adding a new collection that will appear on multiple pages, create a new data file for it.
6. **Read `design-taste.md` before building.** Check `src/content/design-taste.md` for the user's proven design preferences. Factor every preference into your design decisions. If the user reacts to design during the new page build, capture those reactions back to this file.
7. **No em dashes.** Never use em dashes in any output.

## Find the Site Directory

See `references/support-guide.md` for the resolution order. Find the site directory before proceeding.

## Flow

### Step 1: Understand the Request

Ask: **"What kind of page do you need?"**

If they already told you (e.g., "build me a podcast page"), skip this question and confirm: "Got it, a podcast page. Let me ask a few quick questions."

### Step 2: Gather Content Direction

Ask 2-3 targeted questions based on the page type. Examples:

**For a contact page:**
- "What's the best way for people to reach you? Email, phone, booking link?"
- "Want a simple CTA or a contact form?"

**For a blog/content page:**
- "Is this a single page or a listing page for multiple posts?"
- "What's the first topic you want to cover?"

**For a portfolio/case study page:**
- "How many projects or case studies do you want to showcase?"
- "Do you have images for these, or should I plan text-only cards for now?"

**For a landing page:**
- "What's the one action you want visitors to take on this page?"
- "Is this for a specific offer or campaign?"

**For any other page:**
- "What's the main purpose of this page? What should someone do or know after visiting it?"
- "Any specific sections you want on it?"

### Step 3: Plan the Page

Read every `.astro` file in `src/components/` and the existing `website-spec.md`. Read the spec's **Design Principles for This Site**, **Content Strategy** (messaging hierarchy, objection handling map), and **Voice Mode** sections. New pages should extend the established creative direction, messaging architecture, and voice assignments. Know exactly what building blocks already exist before proposing anything.

Propose a page structure using the same components already in the site:

"Here's what I'm thinking for your [page name] page:

1. **[Component]** -- [what it does on this page]
2. **[Component]** -- [what it does]
3. **[Component]** -- [what it does]

Sound good, or want to adjust?"

Wait for approval.

### Step 4: Build the Page

1. Create `src/pages/[slug].astro`
2. Check `src/content/` for existing data files (testimonials.json, stats.json, etc.). Import any that the new page needs rather than duplicating the content inline.
3. Import existing components from `src/components/` -- reuse what's already built, pass content via props (from data files or inline)
4. If a section needs a component type that doesn't exist yet, build a new `.astro` file in `src/components/`. Read at least two existing components first to match their patterns (spacing, tokens, props style, responsive approach). The new component should feel like it was built at the same time as the originals.
5. If the new page introduces collection content that will appear on other pages too, create a new data file in `src/content/` for it.
6. Write the copy using business context from the spec and any Growth OS files
7. Add the new page to the navigation in the Header component
8. Update `src/content/site-data.json` with the new nav link

### Step 5: Update the Spec

Add the new page to `website-spec.md` under Page Specs so the spec stays current.

### Step 6: Preview

If the dev server is running, tell the user to refresh their browser.

If not, start it: `cd [site-directory] && npm run dev`

"Check your browser at localhost:4321 -- you should see the new page."

### Step 7: Iterate

"How does it look? Want to adjust anything?"

Edit based on feedback until the user is happy.

### Step 8: Remind to Publish

"When you're ready to make this live, say 'push my changes' and I'll deploy it."
