---
name: go-live
description: "**Go Live / Push Changes**: Deploys the site or pushes updates. Trigger on 'go live', 'deploy my site', 'push my changes', 'push it live', 'publish my updates', or any request to deploy or update the website."
---

# Go Live / Push Changes

This command handles two scenarios:
1. **First deployment** -- Site has never been pushed to GitHub/Vercel before
2. **Pushing updates** -- Site is already live, user wants to publish changes

## Critical Rules

1. **Confirm before every destructive or external action.** "I'm about to create a GitHub repository called [name]. Good to go?"
2. **Explain what's happening in plain English.** These users are not developers. "I'm uploading your site files to GitHub" not "I'm pushing to origin main."
3. **If anything fails, explain what went wrong in simple terms and offer to fix it.** Don't dump error logs.
4. **No em dashes.** Never use em dashes in any output.
5. **Capture preferences.** If the user reacts to any design or content choice during this session, write the preference to `src/content/design-taste.md` immediately.

## Find the Site Directory

See `references/support-guide.md` for the resolution order. Find the site directory before proceeding.

---

## If This Is a Push Update

Check: Does a `.git` directory exist with a remote configured? If yes, this is an update push. Skip straight to the push flow:

1. `cd [site-directory]`
2. `npm run build` -- verify the site builds cleanly. If it fails, fix the error first.
3. `git add -A`
4. Check `git status` to see what changed
5. Summarize changes in plain English: "I see changes to your homepage headline and a new testimonial section on the about page."
6. `git commit -m "[brief description of changes]"`
7. `git push`
8. "Done. Your changes will be live in about 60 seconds."

---

## If This Is the First Deployment

No `.git` directory, or no remote configured. Walk through the full setup.

### Step 1: Check and Install Prerequisites

Work through this checklist. Check each one, skip what's already done, install what's missing. Keep it conversational, not interrogating.

**1a. Node.js**

Run `node --version`. If it fails: "Node.js isn't installed yet. Download it from nodejs.org, run the installer, then come back." Wait for them.

This should already be installed from the build phase, but check anyway.

**1b. GitHub Account**

Ask: **"Do you have a GitHub account? If not, go to github.com and create a free account. I'll wait."**

No terminal command needed. Just need them to confirm they have an account.

**1c. GitHub CLI**

Run `gh --version`.

If **installed**, move to authentication (1d).

If **not installed:**

"I need to install a tool called the GitHub CLI. It lets me create a repository and push your site files. This takes about a minute."

Check if Homebrew is available: `brew --version`

If Homebrew exists:
```
brew install gh
```

If Homebrew does not exist:
"I need to install Homebrew first (it's a Mac package manager), then the GitHub CLI. This might ask for your Mac password."

```
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
```

After Homebrew installs, check if it needs to be added to PATH (Homebrew often prints instructions about this). Then:

```
brew install gh
```

Verify: `gh --version`

**1d. GitHub CLI Authentication**

Run `gh auth status`.

If already authenticated, move on.

If not: "Let's log you into GitHub. This will open your browser."

```
gh auth login --web
```

Walk them through the browser flow: "It'll show you a code. Enter that code in your browser and click Authorize."

**1e. Vercel Account**

Ask: **"Do you have a Vercel account? If not, go to vercel.com and click 'Sign Up.' Use your GitHub account to sign up -- this connects them automatically so deployment is one-click."**

Wait for confirmation. No terminal command needed.

---

### Step 2: Verify the Build

```
cd [site-directory]
npm run build
```

If the build fails, read the error, explain it simply, and fix it. Common issues:
- Missing image file referenced in a component
- Typo in an import path
- Malformed content in site-data.json

Once the build passes: "Your site builds cleanly. Let's put it on the internet."

### Step 3: Initialize Git

```
cd [site-directory]
git init
```

The `.gitignore` file should already exist from the template. If not, create one:

```
node_modules/
dist/
.astro/
.env
.DS_Store
```

### Step 4: Create GitHub Repository

Confirm: **"I'm going to create a GitHub repository called [business-slug] to store your website files. This is free. Good to go?"**

Wait for confirmation, then:

```
gh repo create [business-slug] --public --source=. --remote=origin
```

Use `--public` by default (simplest). If the user prefers private, that works too -- Vercel's free tier supports both. To create private: `gh repo create [business-slug] --private --source=. --remote=origin`.

If the repo name is taken, try `[business-slug]-website` or ask the user.

### Step 5: First Commit and Push

```
git add -A
git commit -m "Initial site build via Site Starter"
git push -u origin main
```

"Your website files are now on GitHub. Last step: connecting Vercel."

### Step 6: Connect Vercel

Walk the user through the browser steps:

"Now let's connect Vercel to deploy your site:

1. **Go to vercel.com** and sign in (use your GitHub account)
2. **Click 'Add New Project'**
3. **Select your GitHub repo** -- it should be called **[business-slug]**
4. **Framework Preset:** Vercel should auto-detect Astro. If it asks, select **Astro**.
5. **Click Deploy**

Vercel will build and deploy in about 60 seconds. When it's done, it gives you a URL."

Wait for confirmation.

### Step 7: Custom Domain (Optional)

If the user has a custom domain:

"Want to connect your own domain? Here's how:

1. **In Vercel**, go to your project settings > Domains
2. **Add your domain** (e.g., yourbusiness.com)
3. **Vercel gives you DNS records** to add at your domain registrar (GoDaddy, Namecheap, Cloudflare, etc.)
4. **Add those records** at your registrar. It's usually two things:
   - An **A record** pointing to Vercel's IP
   - A **CNAME record** for the www version
5. **Wait 5-30 minutes** for DNS to propagate

If you're not sure where your domain is registered or how to change DNS, tell me your registrar and I'll give you specific steps."

If no domain: "No worries. Your site is live at the Vercel URL for now. You can add a custom domain anytime."

### Step 8: Update URLs Across the Project

Now that the site has a live URL, update it everywhere:

1. **`astro.config.mjs`** -- Update the `site` field with the live Vercel URL or custom domain:
   ```javascript
   site: 'https://[your-vercel-url].vercel.app',
   ```
   Or if they set up a custom domain:
   ```javascript
   site: 'https://yourbusiness.com',
   ```

2. **`public/robots.txt`** -- Update the Sitemap line with the live URL: `Sitemap: https://yourbusiness.com/sitemap-index.xml`
   (The sitemap itself is auto-generated by `@astrojs/sitemap` using the `site` field from astro.config.mjs, so updating the site field is all that's needed.)

3. **`public/llms.txt`** -- Update all page URLs with the live domain. If `llms.txt` doesn't exist yet, create it now using the template from `references/schema-patterns.md`. List every page with a one-line description and add 2-4 key facts about the business.

4. **JSON-LD schema** -- If any schema blocks use absolute URLs, update them to the live domain. Verify `sameAs` social links are still correct.

5. **`website-spec.md`** -- Update with:
   - Repository name
   - Live URL
   - Custom domain (if set up)
   - Mark the Go Live milestone as complete: `- [x] **Go Live** ([today's date])`

### Step 9: Confirm

"Your website is live at [URL]!

From now on:
1. Tell me what to change right here in Claude Code
2. I'll edit the files and you can preview at localhost:4321
3. When you're happy, say **'push my changes'** and I'll deploy

Your site lives in your workspace folder so Claude always has access to it.

Do you use Google Analytics, Plausible, or another analytics tool? I can add the tracking code to your site."

---

## Troubleshooting

### "Permission denied" on git push
Run `gh auth status` and re-authenticate if needed.

### Build fails
Run `npm run build` to see the error. Most common: a typo in a file path or broken HTML. Fix it and try again.

### Vercel deploy fails
Check the Vercel dashboard for the error. Most common: Node.js version mismatch.

### "I don't see my changes"
Tell the user to hard-refresh (Cmd+Shift+R on Mac) or wait 2 minutes.

### GitHub CLI installation fails
If `brew install gh` fails, try the direct download: "Go to cli.github.com, download the Mac installer, and run it."
