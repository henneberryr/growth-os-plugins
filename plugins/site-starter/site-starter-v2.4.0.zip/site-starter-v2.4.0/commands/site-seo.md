---
name: site-seo
description: "**Site SEO**: Audits and optimizes website pages for search engines and AI discovery. Trigger on 'optimize for SEO', 'SEO audit', 'add schema', 'check my SEO', 'make this discoverable', or any request to improve search visibility."
---

# Site SEO

Audits and optimizes website pages for search engines and AI discovery systems (ChatGPT search, Perplexity, Google AI Overviews). This runs automatically during the Site Starter build (end of Milestone 2 and Milestone 3) but can also be triggered manually post-launch.

## Critical Rules

1. **No em dashes.** Use hyphens or rewrite without dashes.
2. **Never fabricate schema data.** Every schema property must match actual page content. Don't invent prices, ratings, or dates that aren't on the page.
3. **Title tags use title case.** Capitalize every word except small prepositions (of, in, for, to, at, by, with). Preserve acronyms (AI, SEO, SaaS).
4. **Business-agnostic.** This skill works for any business, any industry. No hardcoded assumptions about what the site sells or who it serves.
5. **Capture preferences.** If the user reacts to any design or content choice during this session, write the preference to `src/content/design-taste.md` immediately.

## Find the Site Directory

See `references/support-guide.md` for the resolution order. Find the site directory before proceeding.

## Flow

### Step 1: Identify Pages to Audit

If called during the Site Starter flow (Milestone 2 or 3), audit the pages that were just approved. If called standalone:

"Which pages do you want me to optimize? I can do the whole site or specific pages."

If they say "all" or "the whole site," scan `src/pages/` for all `.astro` files.

### Step 2: Classify Each Page

For each page, determine its type:

| Page Type | Typical Pages | Schema Types |
|-----------|--------------|-------------|
| Homepage | index.astro | Organization, WebSite, BreadcrumbList |
| About | about.astro | Person, BreadcrumbList |
| Services/Products | services.astro | Service, OfferCatalog, BreadcrumbList |
| Contact | contact.astro | LocalBusiness (optional), BreadcrumbList |
| Blog/Article | blog/*.astro | Article, BreadcrumbList |
| FAQ (standalone) | faq.astro | FAQPage, BreadcrumbList |
| Any page with FAQ section | * | Add FAQPage schema alongside page type schema |

### Step 3: Audit Each Page

For each page, run the full per-page checks from `references/seo-checklist.md` (Sections 1-8). This covers: meta title, meta description, Open Graph, heading structure, JSON-LD schema, images, internal linking, and AI discoverability (AEO).

Also check schema enrichment per `references/schema-patterns.md`:
- Organization schema includes `sameAs` social profile links (ask user if missing)
- Person schema (About page) includes `knowsAbout` expertise areas and `sameAs` links
- All schema rich enough for AI systems to accurately describe the business/service

### Step 4: Implement Fixes

For each issue found:
1. Fix it directly in the source files
2. For schema, add a `<Fragment slot="schema">` block to the page's frontmatter area:

```astro
<BaseLayout title="Services" description="...">
  <Fragment slot="schema">
    <script type="application/ld+json" set:html={JSON.stringify({
      "@context": "https://schema.org",
      "@type": "Service",
      "name": "...",
      "provider": { "@type": "Organization", "name": "..." },
      "description": "..."
    })} />
  </Fragment>
  <!-- page content -->
</BaseLayout>
```

### Step 5: Verify Sitemap, Robots.txt, and llms.txt

The `@astrojs/sitemap` integration auto-generates the sitemap at build time. Run `npm run build` and verify the output includes `sitemap-index.xml created at dist`. Check that `public/robots.txt` exists and points to `[site-url]/sitemap-index.xml`.

Verify `public/robots.txt` does not block AI crawlers (GPTBot, OAI-SearchBot, ChatGPT-User, ClaudeBot, PerplexityBot). The default `User-agent: * / Allow: /` is correct.

Check for `public/llms.txt`. If it doesn't exist and the site is live (has a real URL), create it using the template from `references/schema-patterns.md`.

### Step 6: Present Results

Show a brief summary:

"SEO and AI discoverability audit complete. Here's what each page looks like in search results:

**Homepage:** [title] / [description]
**About:** [title] / [description]
**Services:** [title] / [description]

Schema: [list schema types per page, note enriched properties like sameAs, knowsAbout]
Sitemap: [status]
Robots.txt: [status] (AI crawlers: [allowed/blocked])
llms.txt: [status]
AI citability: [brief assessment -- e.g., 'All pages have citable passages and structured content']

All pages have proper heading structure, image alt text, internal linking, and AI-optimized content structure."

---

## Schema Patterns Reference

See `references/schema-patterns.md` for JSON-LD templates for each page type.

---

## Post-Launch Re-Audit

When the user runs `/site-seo` after the site is live:

1. Re-read all pages for changes since last audit
2. Verify the `@astrojs/sitemap` integration is still in `astro.config.mjs` (new pages are auto-included at build time)
3. Verify all URLs in schema use the live domain (not localhost or example.com)
4. Verify `robots.txt` points to the correct sitemap URL
5. Present results with pass/fail for each item
