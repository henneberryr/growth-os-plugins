---
name: preview
description: "**Preview**: Starts the local dev server. Trigger on 'preview my site', 'show me my site', 'start the dev server', 'run my site locally', or any request to preview the website."
---

# Preview

Starts the Astro dev server so the user can see their website in a browser.

## Find the Site Directory

See `references/support-guide.md` for the resolution order. Find the site directory before proceeding.

## Install Dependencies (if needed)

Check if `node_modules/` exists in the site directory. If not:

```
cd [site-directory]
npm install
```

"Installing dependencies. This takes about 30 seconds the first time."

## Start the Dev Server

```
cd [site-directory]
npm run dev
```

"Your site is running. Open **http://localhost:4321** in your browser to see it."

If port 4321 is already in use, Astro picks the next available port. Tell the user the correct URL from the output.

## Notes

- Astro hot-reloads most changes (CSS, content, component markup) without a full page refresh
- New pages and config changes require a manual browser refresh
- If the dev server stops, just say "preview my site" again to restart it
