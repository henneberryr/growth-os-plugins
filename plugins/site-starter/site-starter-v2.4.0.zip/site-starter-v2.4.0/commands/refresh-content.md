---
name: refresh-content
description: "**Refresh Content**: Syncs your website with your latest Growth OS files. Trigger on 'refresh content', 'sync my site', 'update content from Growth OS', 'check for content changes', or any request to update the site based on changed business context."
---

# Refresh Content

Re-reads the user's Growth OS files and compares them to what's currently on the website. Flags differences and offers to update the site.

## Critical Rules

1. **No em dashes.** Use hyphens or rewrite without dashes.
2. **Present differences clearly.** Show what changed and what the site currently says.
3. **Always ask before changing.** Don't auto-update content. Present the differences and let the user choose.
4. **Read design-taste.md** before making any visual changes.
5. **Capture preferences.** If the user reacts to any design or content choice during this session, write the preference to `src/content/design-taste.md` immediately.

## Find the Site Directory

See `references/support-guide.md` for the resolution order. Find the site directory before proceeding.

## Flow

### Step 1: Read Current Sources

Read all Growth OS files:
- `core/offers.md` -- Current offers, pricing, positioning
- `core/persona.md` -- Current ideal customer
- `core/brand-voice.md` -- Current communication style

Read the current website content:
- All page files in `src/pages/`
- All content data files in `src/content/` (testimonials.json, stats.json, services.json, etc.)
- `src/content/site-data.json` (nav, CTA, footer)

### Step 2: Compare and Flag Differences

Look for:

**New content not on the site:**
- New services/offers in offers.md not on the Services page
- New testimonials mentioned but not in testimonials.json
- New team members or credentials
- Changed pricing

**Outdated content on the site:**
- Services on the site that are no longer in offers.md
- Old pricing that doesn't match current offers
- Persona language that's shifted

**Voice/tone shifts:**
- If brand-voice.md has changed, note whether the site copy still matches. If the voice has shifted significantly, offer to refresh the site copy to match: "Your brand voice has shifted toward [new direction]. Want me to update the copy on your key pages to match?"

### Step 3: Present Findings

"I compared your Growth OS files to your website. Here's what I found:

**New (not on your site yet):**
- [list items -- e.g., 'Your offers file has a new service: AI Workshops for Teams']

**Potentially outdated:**
- [list items -- e.g., 'Your Services page shows pricing at $3,000 but offers.md says $5,000']

**Still current:**
- [summary of what matches]

Want me to update any of these?"

### Step 4: Apply Updates

For each change the user approves:

1. Read existing components -- reuse what's built
2. Read `design-taste.md` for design preferences
3. Update content data files if applicable (services.json, etc.)
4. Update page files with new content
5. Match existing design patterns exactly
6. Run the per-page checks from `references/seo-checklist.md` on any changed pages, including AEO passage citability and entity consistency. Update meta titles/descriptions if content changed significantly. Update schema if services, pricing, or credentials changed.

### Step 5: Offer to Push

"I've updated your site. Want to preview at localhost, or push these changes live?"
