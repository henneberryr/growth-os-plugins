# SEO Checklist

Use this checklist when auditing any page built with Site Starter. Every item should pass before a page goes live.

---

## Per-Page Checks

### 1. Title Tag
- [ ] Exists and is unique across the site
- [ ] Under 60 characters (BaseLayout appends " | [Business Name]" automatically)
- [ ] Includes a relevant keyword naturally
- [ ] Uses title case (capitalize every word except: of, in, for, to, at, by, with, and, or, the, a, an)
- [ ] Preserve acronyms: AI, SEO, SaaS, CRM, etc.
- [ ] No em dashes

### 2. Meta Description
- [ ] Exists and is unique across the site
- [ ] 140-155 characters
- [ ] Includes concrete details (what, who, outcome)
- [ ] Includes primary keyword naturally
- [ ] No em dashes
- [ ] Reads like a human wrote it (not keyword-stuffed)

### 3. Open Graph
- [ ] OG title set (auto-generated from meta title by BaseLayout)
- [ ] OG description set (auto-generated from meta description by BaseLayout)
- [ ] OG image path set if a hero image or logo exists

### 4. Heading Structure
- [ ] Exactly one `<h1>` per page (in the Hero section)
- [ ] H2s follow H1, H3s follow H2s -- no skipped levels
- [ ] Primary keyword appears in at least one heading
- [ ] Headings are descriptive (not "Section 1" or "More Info")

### 5. JSON-LD Structured Data
- [ ] BreadcrumbList schema present (required on every page)
- [ ] Page-type-specific schema present (Organization, Person, Service, FAQPage, Article)
- [ ] All URLs in schema are absolute (use site URL from astro.config.mjs)
- [ ] All schema data matches actual visible page content
- [ ] Schema injected via `<Fragment slot="schema">` in the page file

### 6. Images
- [ ] Every `<img>` has descriptive alt text
- [ ] Alt text conveys purpose ("CEO delivering keynote" not "man on stage")
- [ ] Below-fold images use `loading="lazy"`
- [ ] No broken image references (every src points to a file that exists)

### 7. Internal Linking
- [ ] Page links to other relevant pages on the site
- [ ] Anchor text is descriptive (not "click here" or "learn more")
- [ ] All internal links resolve (no 404s)

### 8. AI Discoverability (AEO)

AI search systems (Google AI Overviews, ChatGPT, Perplexity, Bing Copilot) select content differently than traditional search. These checks ensure your pages are citable by AI systems, not just indexable by crawlers.

**Passage-Level Citability**
- [ ] Each major section contains a self-contained answer block (134-167 words) that can be extracted without surrounding context
- [ ] Key claims are stated as direct, quotable sentences -- not buried in paragraphs
- [ ] First 40-60 words of each section directly answer the section's implied question
- [ ] Definitions use "X is..." or "X refers to..." patterns where appropriate
- [ ] Specific statistics and data points include their source
- [ ] Services, features, and deliverables listed in bullet points or tables (not only prose)

**Structural Readability for AI**
- [ ] Question-based H2/H3 headings where natural (matches how users query AI systems)
- [ ] Short paragraphs (2-4 sentences max)
- [ ] Tables used for comparative data (pricing, features, plan differences)
- [ ] Ordered lists for processes/steps, unordered lists for features/benefits
- [ ] FAQ sections with complete, standalone answers (each answer makes sense without the question)
- [ ] No critical content hidden behind JavaScript interactions, accordions in collapsed state, or CSS animations

**Entity Clarity**
- [ ] Business name appears in the same form everywhere (not "Smith Co" in one place and "Smith Consulting" in another)
- [ ] Owner/founder name appears with consistent title/credentials
- [ ] Primary offer is named explicitly, not only implied
- [ ] "Who, what, why, how much, how long" answered on relevant pages

**Authority Signals**
- [ ] Author/founder byline with credentials on About page (and blog posts if applicable)
- [ ] Publication date visible on content pages (AI systems check freshness)
- [ ] Citations to primary sources where claims are made (studies, official docs)
- [ ] Organization credentials, certifications, or affiliations mentioned

---

## Site-Wide Checks

### 9. Sitemap
- [ ] `@astrojs/sitemap` integration is in `astro.config.mjs`
- [ ] `npm run build` generates `sitemap-index.xml` in `dist/`
- [ ] `astro.config.mjs` site field is set to the live URL (sitemap uses this for absolute URLs)

### 10. Robots.txt
- [ ] `public/robots.txt` exists
- [ ] Allows all crawlers: `User-agent: * / Allow: /`
- [ ] Points to sitemap: `Sitemap: [site-url]/sitemap-index.xml`

### 11. Favicon
- [ ] `public/favicon.svg` exists
- [ ] Referenced in BaseLayout `<head>`

### 12. Site Configuration
- [ ] `astro.config.mjs` site field is set to the live URL (not example.com)
- [ ] Canonical URLs work correctly (check page source in browser)

### 13. AI Crawler Access
- [ ] `robots.txt` does NOT block AI crawlers (GPTBot, OAI-SearchBot, ChatGPT-User, ClaudeBot, PerplexityBot)
- [ ] No blanket `Disallow` rules that would prevent AI discovery
- [ ] Current default (`User-agent: * / Allow: /`) is sufficient for AI discoverability

### 14. llms.txt (Create During Go-Live)
- [ ] `public/llms.txt` exists with site title, description, and links to key pages
- [ ] Each linked page has a one-line description of what it covers
- [ ] Format follows the llms.txt standard (# Title, > Description, ## Sections with links)

### 15. Enriched Schema for AI
- [ ] Organization schema includes `sameAs` array linking to social profiles (LinkedIn, YouTube, etc.)
- [ ] Person schema (About page) includes `knowsAbout` array with expertise areas
- [ ] Person schema includes `sameAs` linking to LinkedIn, personal site, etc.
- [ ] All schema includes `dateModified` where content has been updated
- [ ] Service schema includes enough detail for AI systems to describe the offering

---

## Title Tag Examples by Page Type

| Page Type | Good Title | Bad Title |
|-----------|-----------|----------|
| Homepage | AI Marketing Consultant and Keynote Speaker | Home |
| About | About [Name] - [Brief Descriptor] | About Us |
| Services | AI Workshops, Keynotes, and Custom Agent Builds | Our Services |
| Contact | Get in Touch | Contact |
| Blog Post | How to Build an AI Marketing System in 30 Days | Blog Post #12 |

---

## Meta Description Examples

**Good:** "Jane Smith helps marketing teams build AI systems that actually work. Keynotes, workshops, and custom AI agents. Book a free discovery call."

**Bad:** "Welcome to our website. We offer many services. Contact us today to learn more about what we do."

**Why the first works:** Concrete (names what's offered), specific (free discovery call), and includes keywords naturally (AI systems, marketing teams, keynotes, workshops).
