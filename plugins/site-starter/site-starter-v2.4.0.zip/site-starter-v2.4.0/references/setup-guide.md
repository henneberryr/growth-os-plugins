# Site Starter -- Setup Guide

You only need one thing installed before you start building your website. Everything else gets set up later when you're ready to put your site on the internet.

---

## Before You Start

| Tool | What It Does | Cost |
|------|-------------|------|
| **Node.js** | Lets you preview your website on your computer | Free |

That's it. One thing.

---

### Install Node.js

Node.js is the engine that runs your website locally so you can preview it.

1. Go to **nodejs.org**
2. Click the big green button that says **"LTS"** (Long Term Support)
3. Run the installer -- click Next through everything, accept defaults
4. When it's done, open your **Terminal** app (search "Terminal" in Spotlight on Mac)
5. Type `node --version` and press Enter
6. If you see a version number (like `v22.x.x`), you're good

**Troubleshooting:** If Terminal says "command not found," close Terminal, reopen it, and try again. The installer sometimes needs a fresh terminal window.

---

## You're Ready

Once Node.js is installed, open Claude Desktop, switch to **Claude Code**, and say:

**"Build my website"**

Claude takes it from there. You'll have a live preview of your site before you need anything else.

---

## Before You Go Live (Claude handles this)

When you're happy with your site and ready to put it on the internet, Claude will walk you through setting up these three things. You don't need to do any of this in advance.

| Tool | What It Does | Cost |
|------|-------------|------|
| **GitHub account** | Stores your website files in the cloud | Free |
| **GitHub CLI** | Lets Claude upload your files to GitHub | Free |
| **Vercel account** | Hosts your website on the internet | Free |

Claude checks what you already have and only sets up what's missing. The whole process takes about 5 minutes.

---

## Quick Reference

After your site is built, here's all you need to say to Claude:

| What You Want | What You Say |
|------|---------|
| Preview your site locally | "preview my site" |
| Push changes live | "push my changes" |
| Add a new page | "add a page" |
| Make any edit | Just describe what you want changed |

You never need to type terminal commands yourself. Claude handles everything.

---

## FAQ

**Q: Do I need to know how to code?**
A: No. Claude writes all the code. You just tell Claude what you want.

**Q: Is this really free?**
A: Yes. Node.js, GitHub, GitHub CLI, and Vercel are all free. Vercel's free tier handles plenty of traffic for a business website. You only pay for Claude (which you already have) and optionally a custom domain (~$12/year).

**Q: What if I already have a domain?**
A: Great. During the Go Live step, Claude walks you through connecting it to Vercel. Takes about 5 minutes.

**Q: What if I don't have a domain?**
A: No problem. Vercel gives you a free URL (like yoursite.vercel.app). You can buy and connect a custom domain anytime later.

**Q: Can I move my site away from Vercel later?**
A: Yes. Your site is just HTML files. You own everything. You can host it anywhere.

**Q: What if something goes wrong during setup?**
A: Tell Claude what happened. Paste the error message if you have one. Claude can usually diagnose and fix setup issues.

**Q: Where does my website get built?**
A: Claude builds it right in your workspace folder so it always has access to it. Your site lives alongside your Growth OS files.
