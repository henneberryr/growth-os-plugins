# Component Library

This is the catalog of section components Claude can use to compose website pages. Each component is a self-contained Astro section block that accepts content via props and uses Tailwind @theme tokens for all styling.

Claude selects and orders components during Milestone 1 (Design Direction) and builds them based on the approved design. Every site is a unique composition. There is no fixed page template.

---

## When to Use This Document vs. the Actual Code

**This document is the blueprint for the INITIAL BUILD ONLY.** It tells Claude what types of components exist, what variants are available, what props they accept, and how they should be styled.

Once the site is built and the user approves it, **the actual `.astro` files in `src/components/` become the source of truth.** From that point forward:

- **Adding content?** Read the existing component file, import it, pass new props.
- **Building a new page?** Read the existing components, compose from what's already built.
- **Need a new component type?** Read existing components to match their patterns (spacing, tokens, props architecture), then build the new one to fit.

**The code is the design system.** This reference doc is the seed. The code is the tree.

### Design Quality Standards

Every component must meet a high design bar. The goal is distinctive, production-grade output that looks intentionally designed, not like generic AI output.

**Design Thinking (before writing any component code):**
- **Purpose:** What does this section need to accomplish? Who's looking at it?
- **Tone:** Commit to the vibe direction from the spec. Execute it with precision and intentionality.
- **Differentiation:** What makes this site feel like *this* business and no other? Every component should reinforce that identity.

**Typography:**
- Choose fonts that are beautiful, unique, and interesting
- NEVER use generic fonts: Inter, Roboto, Arial, Open Sans, system fonts
- Pair a distinctive display font with a refined body font
- Use dramatic size contrast between headings and body text

**Color & Theme:**
- Commit to a cohesive aesthetic using CSS variables (@theme tokens)
- Dominant colors with sharp accents outperform timid, evenly-distributed palettes
- Every color choice should feel deliberate

**Motion & Interaction:**
- Use CSS animations for high-impact moments: staggered reveals on page load (animation-delay), scroll-triggered effects, hover states that surprise
- Prioritize CSS-only solutions (no JS animation libraries needed for Astro)
- One well-orchestrated animation creates more delight than scattered micro-interactions

**Spatial Composition:**
- Don't default to predictable, symmetrical layouts
- Use generous negative space OR controlled density -- commit to one
- Consider asymmetry, overlap, grid-breaking elements, diagonal flow where appropriate for the vibe

**Backgrounds & Visual Details:**
- Create atmosphere and depth rather than defaulting to solid white backgrounds
- Match effects to the vibe: gradient meshes, subtle noise textures, geometric patterns, layered transparencies, dramatic shadows, decorative borders
- These details separate a professional site from a generic one

**NEVER do these things:**
- Generic AI aesthetics (the "purple gradient on white" look)
- Overused fonts (Inter, Roboto, Arial, Space Grotesk, system fonts)
- Predictable layouts and component patterns
- Cookie-cutter design that lacks context-specific character
- The same design choices across different sites -- every site should feel unique to its business

**Match complexity to vision.** Maximalist vibes need elaborate styling, rich animations, and layered effects. Minimalist vibes need restraint, precision, and meticulous attention to spacing, typography, and subtle details. Elegance comes from executing the vision fully, not from splitting the difference.

---

## How Components Work

### Architecture

Every component is an `.astro` file in `src/components/`. Each one:

- Accepts content via props (headline, body, items, etc.)
- Uses Tailwind classes referencing @theme tokens (never hardcoded colors)
- Is fully responsive (mobile-first)
- Uses semantic HTML (proper heading levels, landmarks, alt text)
- Requires zero JavaScript unless noted
- Is self-contained (no external dependencies beyond Tailwind)
- Is reusable across multiple pages with different content

### Props Pattern

```astro
---
interface Props {
  headline: string;
  subheadline?: string;
  body?: string;
  buttonText?: string;
  buttonUrl?: string;
}

const { headline, subheadline, body, buttonText, buttonUrl } = Astro.props;
---

<section class="py-20 px-6">
  <!-- component markup -->
</section>
```

### Content Data Files

Components that render collections (testimonials, stats, FAQs, services, credentials) should have their data stored in `src/content/[name].json` and imported into pages, not hardcoded as inline props. This makes content reusable across pages and editable in one place.

**The pattern:**

```astro
---
// In a page file
import Testimonial from '../components/Testimonial.astro';
import testimonials from '../content/testimonials.json';
---
<Testimonial testimonials={testimonials} variant="featured-plus-grid" />
```

**The rule:** If the same data appears on two or more pages, or if it's a collection that will grow, it belongs in a JSON data file. If it's unique to one page (a hero headline, a page-specific description), it stays inline.

Components don't need to know where their data comes from. They accept props. The page decides whether those props come from a data file or are written inline. This keeps components simple and reusable.

### Design Taste File

Before building or modifying any component, check for `src/content/design-taste.md` in the site project. This living file captures the user's proven design preferences from previous iteration sessions -- things like "prefers lighter backgrounds," "doesn't like orange," "wants generous nav padding."

If the file exists, read it and factor every preference into your design decisions. The user's taste is the most valuable design input. It compounds over time: the more sessions the user has done, the richer this file becomes, and the closer your first attempt will be to what they want.

If you're building a new component and the user reacts to it ("too cramped," "the font feels heavy"), capture that reaction to `design-taste.md` so it persists for future work.

### Composition Pattern

Pages compose components by importing and stacking them:

```astro
---
import Hero from '../components/Hero.astro';
import FeatureGrid from '../components/FeatureGrid.astro';
import Testimonial from '../components/Testimonial.astro';
import CtaBanner from '../components/CtaBanner.astro';
---

<Hero headline="..." subheadline="..." buttonText="..." buttonUrl="..." />
<FeatureGrid headline="..." items={[...]} />
<Testimonial quote="..." author="..." title="..." />
<CtaBanner headline="..." buttonText="..." buttonUrl="..." />
```

---

## Component Catalog

This is a menu of component TYPES for composing pages. Claude selects from these types and builds each component custom to the site's vibe. Do not copy examples verbatim. Design props and markup fresh for each site based on the approved design direction.

After the initial build, the actual `.astro` files in `src/components/` become the source of truth. This catalog is only used during Milestone 1.

### 1. Hero
The first thing visitors see. Sets the tone for the entire page.
Variants: **Centered** (headline + CTA on background), **Split** (text left, image right), **Gradient Overlay** (background image with overlay), **Minimal** (headline + whitespace), **Video Background** (looping video with overlay).

### 2. Feature Grid
Showcases capabilities, services, benefits, or features.
Variants: **Icon Grid** (3-col with icons), **Image Cards** (3-col with images), **Numbered Steps** (sequential process), **Two Column** (larger cards), **Alternating** (left/right image+text rows).

### 3. Testimonial
Social proof from real customers.
Variants: **Single Featured** (one large centered quote), **Card Grid** (2-3 cards in a row), **Minimal Quote** (just text + attribution), **Side-by-Side** (quote + photo).
Data source: `src/content/testimonials.json` for collections.

### 4. CTA Banner
Full-width call-to-action section.
Variants: **Simple** (headline + button on colored bg), **Split** (text left, button right), **Gradient** (gradient background), **With Subtext** (headline + paragraph + button).

### 5. About / Bio Section
The person or team behind the business.
Variants: **Photo + Story** (photo + narrative), **Team Grid** (team member cards), **Timeline** (vertical milestones), **Values Grid** (mission + values), **Stats Bar** (key numbers row).

### 6. Services / Products Showcase
What the business sells in a structured, scannable format.
Variants: **Card Grid** (3-col service cards), **Featured + List** (one highlighted, others listed), **Pricing Table** (side-by-side tiers), **Detailed Sections** (full-width per service), **Product Gallery** (image-forward grid).

### 7. FAQ / Accordion
Common questions. Reduces friction and objections.
Variants: **Simple List** (always open), **Accordion** (expand/collapse, requires minimal JS), **Two Column** (split columns).
Note: Accordion variant needs a small `<script>` for toggle behavior.

### 8. Logo Bar
Client logos, partner logos, press mentions, certifications.
Variants: **Static Row** (horizontal centered), **Scrolling Ticker** (CSS animation strip), **Grid** (grid layout).

### 9. Newsletter / Email Signup
Email capture with optional incentive copy.
Variants: **Inline** (horizontal row), **Card** (centered card), **Banner** (full-width colored bg).
Note: Static HTML form. `action` URL points to external service (Beehiiv, Formspree, etc.).

### 10. Contact / CTA Section
Getting in touch or taking the final action.
Variants: **Simple CTA** (headline + button), **Contact Info** (details + optional map), **Split** (CTA left, details right).

### 11. Content Section
Flexible text for long-form content.
Variants: **Centered Prose** (narrow centered column), **Two Column Text** (split columns), **Text + Image** (text alongside image).

### 12. Divider / Spacer
Visual breaks between sections.
Variants: **Line** (horizontal rule), **Spacer** (empty space), **Decorative** (gradient, dots, shapes).

---

## Header & Footer

Always included on every page. Not selected during Design Direction.

**Header:** Fixed top, logo left, nav center/right, CTA button far right. Mobile hamburger menu with vanilla JS toggle. Import nav links and CTA from `site-data.json`.

**Footer:** Full-width bottom section. Business name, tagline, nav links (repeat from header), social media icon links (inline SVG), copyright line. Import from `site-data.json`.

---

## Composition Guidelines

### Homepage Pattern

A typical homepage flows through these emotional beats:

1. **Hook** (Hero) -- Grab attention, state the value proposition
2. **Credibility** (Logo Bar or Stats) -- Instant trust signal
3. **Value** (Feature Grid) -- What you get / how it works
4. **Proof** (Testimonial) -- Someone else saying it
5. **Action** (CTA Banner) -- Tell them what to do next

### About Page Pattern

1. **Context** (Hero, Minimal) -- Set the stage
2. **Story** (Bio Section) -- The human behind the business
3. **Values** (Feature Grid or Values Grid) -- What the business believes
4. **Proof** (Testimonial, optional) -- Reinforcement
5. **Action** (CTA Banner) -- Next step

### Services/Products Page Pattern

1. **Overview** (Hero) -- What you offer, broadly
2. **Offerings** (Services Showcase) -- The specific things they can buy
3. **Process** (Feature Grid, Numbered Steps) -- How it works
4. **Proof** (Testimonial) -- Results from real clients
5. **FAQ** (Accordion) -- Objection handling
6. **Action** (CTA Banner) -- Take the next step

### Rules for Composition

1. **Avoid stacking the same component type consecutively.** If you need two of the same type (e.g., two Feature Grids for different purposes), separate them with a different section in between.
2. **Alternate light and dark sections** for visual rhythm. If Hero is dark, the next section should be light.
3. **Every page ends with a CTA.** The last section before the footer should always have a clear next step.
4. **Keep homepage to 4-6 sections.** More than that feels overwhelming for a starter site.
5. **Keep inner pages to 3-5 sections.** Focused and purposeful.
6. **Mobile first.** Every layout must work as a single column on mobile before you consider the desktop grid.
7. **Heading hierarchy matters.** Only one `<h1>` per page (in the Hero). Subsequent sections use `<h2>`. Sub-items use `<h3>`.

---

## Accessibility

Every component must meet basic accessibility standards:

- **Semantic HTML:** Use `<main>`, `<section>`, `<nav>`, `<footer>`, `<article>` appropriately. Not everything is a `<div>`.
- **ARIA labels:** Interactive elements (hamburger menu, accordion toggles, modal triggers) must have `aria-label` or `aria-expanded` attributes.
- **Alt text:** Every `<img>` must have descriptive alt text. Never leave alt empty unless the image is purely decorative (in which case use `alt=""`).
- **Color contrast:** Text must have a contrast ratio of at least 4.5:1 against its background (WCAG AA). Test light text on colored backgrounds carefully.
- **Focus states:** Interactive elements (links, buttons) should have visible focus outlines for keyboard navigation.
- **Heading hierarchy:** One H1 per page, logical H2/H3 nesting. Never skip levels.
- **Skip to content:** Every page's `<main>` element must have `id="main-content"` to support the skip link in BaseLayout.

---

## Image Handling

- **File location:** All images go in `public/images/`. Reference them as `/images/filename.ext` in components.
- **Lazy loading:** Use `loading="lazy"` on all images below the fold. Hero images can use eager loading.
- **Alt text:** Write descriptive alt text that conveys the image's purpose, not just its contents. "CEO delivering a keynote presentation" not "person on stage."
- **Sizing:** Keep images under 500KB for hero/feature images. When the user provides a photo over 500KB, resize it before saving using macOS `sips`: `sips --resampleWidth 1600 photo.jpg` for hero images, `sips --resampleWidth 400 photo.jpg` for thumbnails/headshots. Tell the user: "I resized your photo from [X]MB to [Y]KB so your site loads fast."
- **No broken images:** Never render an `<img>` tag pointing to a file that doesn't exist. If an image is optional and not provided, omit the tag entirely -- don't show a broken placeholder.
- **Formats:** PNG for logos and graphics with transparency. JPG for photos. SVG for icons and simple graphics.

---

## SEO Integration

Every page built with the component library should support SEO via the BaseLayout:

- **Schema slot:** BaseLayout includes `<slot name="schema" />` in the `<head>`. Pages inject JSON-LD structured data through this slot.
- **Meta props:** Every page passes `title` and `description` to BaseLayout. The layout constructs the full title (`{page} | {businessName}`) and handles OG tags.
- **Canonical URLs:** Handled automatically by BaseLayout when `site` is configured in `astro.config.mjs`.

See `commands/site-seo.md` for the full SEO audit workflow.

---

## Forms and Contact

For MVP builds, prefer static CTAs over custom forms:

- **Booking link:** "Schedule a Call" button linking to Calendly, Cal.com, or similar
- **Email link:** `mailto:` link styled as a button or inline CTA
- **Contact info display:** Phone, email, address displayed as text (no form needed)

If a form is required, the `<form>` action attribute can point to an external service (Formspree, Netlify Forms, etc.). Advanced API integrations are out of scope for the initial build.
