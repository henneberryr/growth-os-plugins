# Schema Patterns

JSON-LD structured data patterns for Site Starter websites. Use these as templates when adding schema to pages. All data must match actual page content -- never fabricate properties.

## Rules

1. **BreadcrumbList is required on every page.** No exceptions.
2. **All URLs must be absolute.** Use the site URL from `astro.config.mjs`.
3. **Never fabricate data.** If a price, rating, or date isn't on the page, don't put it in the schema.
4. **Inject via the schema slot.** Use `<Fragment slot="schema">` in the page file.

## How to Add Schema to a Page

```astro
<BaseLayout title="Services" description="...">
  <Fragment slot="schema">
    <script type="application/ld+json" set:html={JSON.stringify({
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://yourbusiness.com/" },
        { "@type": "ListItem", "position": 2, "name": "Services", "item": "https://yourbusiness.com/services" }
      ]
    })} />
    <script type="application/ld+json" set:html={JSON.stringify({
      "@context": "https://schema.org",
      "@type": "Service",
      "name": "...",
      "provider": { "@type": "Organization", "name": "..." }
    })} />
  </Fragment>
  <!-- page content -->
</BaseLayout>
```

---

## Homepage

### Organization + WebSite

```json
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "[Business Name]",
  "url": "[site-url]",
  "description": "[elevator pitch from business context]",
  "logo": "[site-url]/images/logo.png",
  "sameAs": [
    "[LinkedIn company URL, if available]",
    "[YouTube channel URL, if available]",
    "[Twitter/X URL, if available]",
    "[Instagram URL, if available]"
  ],
  "founder": {
    "@type": "Person",
    "name": "[Owner Name]"
  }
}
```

Include `sameAs` with every social profile URL the business has. AI systems use these to build entity graphs and verify identity. Include `founder` if the owner is named on the homepage. Only include URLs that are real and active -- never fabricate social links.

```json
{
  "@context": "https://schema.org",
  "@type": "WebSite",
  "name": "[Business Name]",
  "url": "[site-url]"
}
```

### BreadcrumbList (Home only)

```json
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    { "@type": "ListItem", "position": 1, "name": "Home", "item": "[site-url]/" }
  ]
}
```

---

## About Page

### Person

```json
{
  "@context": "https://schema.org",
  "@type": "Person",
  "name": "[Owner Name]",
  "jobTitle": "[Title/Role]",
  "description": "[Brief bio from about page content]",
  "url": "[site-url]/about",
  "image": "[site-url]/images/[headshot-filename]",
  "worksFor": {
    "@type": "Organization",
    "name": "[Business Name]"
  },
  "knowsAbout": [
    "[expertise area 1]",
    "[expertise area 2]",
    "[expertise area 3]"
  ],
  "sameAs": [
    "[LinkedIn personal URL, if available]",
    "[Twitter/X URL, if available]",
    "[Personal website URL, if different from business site]"
  ]
}
```

Include `image` only if a headshot exists on the page. `knowsAbout` should list the person's primary expertise areas as they appear on the page (not fabricated). AI systems use this to determine topical authority. `sameAs` links help AI systems verify identity across platforms -- ask the user for these URLs during the About page content review.

---

## Services Page

### Service with OfferCatalog

```json
{
  "@context": "https://schema.org",
  "@type": "Service",
  "name": "[Primary Service Category]",
  "provider": {
    "@type": "Organization",
    "name": "[Business Name]",
    "url": "[site-url]"
  },
  "description": "[Service page description]",
  "hasOfferCatalog": {
    "@type": "OfferCatalog",
    "name": "Services",
    "itemListElement": [
      {
        "@type": "Offer",
        "itemOffered": {
          "@type": "Service",
          "name": "[Service 1 Name]",
          "description": "[Service 1 description from page]"
        }
      },
      {
        "@type": "Offer",
        "itemOffered": {
          "@type": "Service",
          "name": "[Service 2 Name]",
          "description": "[Service 2 description from page]"
        }
      }
    ]
  }
}
```

Only include `price` in offers if pricing is visible on the page.

---

## FAQ (Any Page with FAQ Section)

### FAQPage

```json
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "[Question text exactly as displayed on page]",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "[Answer text exactly as displayed on page]"
      }
    }
  ]
}
```

Add one Question/Answer entry for each FAQ item on the page. Use the exact text from the page -- do not paraphrase.

---

## Blog / Article Page

### Article

```json
{
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "[Article title]",
  "author": {
    "@type": "Person",
    "name": "[Author name]"
  },
  "datePublished": "[YYYY-MM-DD]",
  "dateModified": "[YYYY-MM-DD]",
  "description": "[Meta description]",
  "url": "[site-url]/blog/[slug]"
}
```

Only include dates if they're displayed on the page.

---

## Contact Page

### LocalBusiness (optional)

Only use this if the business has a physical location:

```json
{
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "name": "[Business Name]",
  "url": "[site-url]",
  "telephone": "[phone if on page]",
  "email": "[email if on page]",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "[address]",
    "addressLocality": "[city]",
    "addressRegion": "[state]",
    "postalCode": "[zip]",
    "addressCountry": "US"
  }
}
```

If no physical address, skip LocalBusiness entirely. Use a simple BreadcrumbList.

---

## BreadcrumbList (Required on Every Page)

```json
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    { "@type": "ListItem", "position": 1, "name": "Home", "item": "[site-url]/" },
    { "@type": "ListItem", "position": 2, "name": "[Page Name]", "item": "[site-url]/[slug]" }
  ]
}
```

For nested pages, add additional ListItem entries with incrementing positions.

---

## llms.txt (AI Crawler Guidance)

Create `public/llms.txt` during Milestone 4 (Go Live) after the site URL is known. This file tells AI crawlers what your site contains and where to find key content.

```
# [Business Name]

> [One-sentence elevator pitch from business context]

## Pages

- [Homepage]([site-url]/): [What the homepage covers -- e.g., "Overview of services, client results, and getting started"]
- [About]([site-url]/about): [What the about page covers -- e.g., "Founder story, credentials, and company values"]
- [Services]([site-url]/services): [What the services page covers -- e.g., "Service descriptions, pricing, and how to book"]
- [Contact]([site-url]/contact): [What the contact page covers -- e.g., "Contact information and booking link"]

## Key Facts

- [Primary offering and who it serves]
- [Key differentiator or credential]
- [How to engage -- e.g., "Free consultation available at [URL]"]
```

Every page on the site should be listed with a descriptive one-line summary. `Key Facts` should include 2-4 statements that AI systems can use to quickly understand and describe the business. Only include facts that are stated on the actual website.
