# Support Guide

Shared utilities, multi-session support, and troubleshooting for all Site Starter commands.

---

## Finding the Site Directory

All commands (site-starter, preview, go-live, new-page, site-seo, site-health, refresh-content) need to find the site directory. Use this resolution order:

1. Read `website-spec.md` in the workspace root. Check the `Site directory` field. Verify it exists and contains `astro.config.mjs`.
2. If missing or invalid, scan the workspace root for any directory with both `package.json` and `astro.config.mjs`.
3. If nothing found: "I don't see a website project. Say 'build my website' to get started."

If found at a different path than stored, update `website-spec.md`.

If multiple site directories are found during scanning, ask the user: "I found more than one site project. Which one do you want to work on?" and list the options.

---

## Multi-Session Support

If the user stops mid-build, everything is saved to disk. When they return, read `website-spec.md` and check the Milestones section:

| State | What to do |
|-------|-----------|
| No spec, no site directory | Fresh start. Milestone 1. |
| Spec exists, Design Direction not complete | Resume design iteration. |
| Design Direction complete, Content not complete | Resume Milestone 2. |
| Content complete, Full Site not complete | Resume Milestone 3. |
| Full Site complete, not deployed | Offer Milestone 4 (go live). |
| Deployed | Ready for ongoing edits. |

"I see your design direction is set but we haven't filled in the real content yet. Ready to pick up where we left off?"

---

## Troubleshooting

### npm install fails
Check `node --version`. If Node.js isn't installed: "Node.js isn't installed yet. Download it from nodejs.org, run the installer, then come back." If installed but failing, try `npm cache clean --force` then `npm install` again.

### npm run dev fails with build error
Read the error message. Most common: missing file path, malformed JSON in `src/content/`, or broken HTML in a component. Fix the error and try again.

### "Permission denied" on git push
Run `gh auth status` and re-authenticate if needed.

### Vercel deploy fails
Check the Vercel dashboard. Most common: Node.js version mismatch. Add `engines` field to package.json if needed.

### "I don't see my changes"
Hard-refresh (Cmd+Shift+R on Mac) or wait 2 minutes. Check `git log --oneline -1` to verify push went through.

### Dev server not running
Find the site directory (see resolution order above) and run: `cd [site-directory] && npm run dev`

### Site directory not found
Use the resolution order above. If the user moved the folder manually, update `website-spec.md` with the new path once found.
