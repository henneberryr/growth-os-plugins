# QA Checklist

This is the single source of truth for Site Starter quality checks. The four QA gates in the main skill file reference this checklist. The `site-health` command also references it for post-launch re-checks.

Every check is tagged with when it runs: **G1** (Design), **G2** (Content), **G3** (Full Site), **G4** (Deploy Readiness).

---

## How QA Gates Work

Claude runs each gate automatically after the user approves the milestone's work but before writing the handoff to `website-spec.md`. The user never has to ask for QA.

**Principle: fix silently, report only what needs a decision.**

- If Claude can fix an issue without changing anything the user approved (e.g., adding a missing `loading="lazy"` attribute), fix it silently.
- If fixing an issue would change something the user already approved (e.g., adjusting a color for contrast), present the issue and offer the fix.
- If an issue requires information Claude doesn't have (e.g., a real CTA URL), ask the user.

**Gate output format:**

After running the checks, present a brief summary only if issues were found:

"I ran a quality check before we move on. [N] things look great. [N] need a quick fix:

1. [Issue] -- [proposed fix]. Want me to handle it?
2. [Issue] -- I need your input: [question]

Everything else passed."

If all checks pass, keep it to one line:

"Quality check passed -- [brief summary of what was verified]. Moving on."

---

## Gate 1: Design Integrity

Runs at the end of Milestone 1, after the user approves the full homepage layout and before writing the handoff to `website-spec.md`.

### Color Contrast (G1)

Check text-on-background contrast for these combinations:
- Primary text color on page background
- Heading text on page background
- Button text on button background (primary CTA)
- Muted/secondary text on page background
- Any text on colored section backgrounds (alternating sections)

**Standard:** WCAG AA requires 4.5:1 for normal text, 3:1 for large text (18px+ bold or 24px+ regular).

**How to check:** Read the hex values from `global.css` @theme tokens. Calculate contrast ratio. For section backgrounds that use custom colors, read those too.

**Fix approach:** If contrast fails, propose a slightly adjusted shade that passes while preserving the design intent. Present as: "Your [color] text on [background] is close but doesn't meet accessibility standards (ratio: [X]:1, needs 4.5:1). I can [specific adjustment]. Want me to fix it?"

### Responsive Verification (G1)

With the dev server running, verify the homepage renders correctly at three breakpoints:
- Mobile (375px width)
- Tablet (768px width)
- Desktop (1280px width)

**Check for:**
- Text overflow or horizontal scroll
- Overlapping elements
- Images breaking out of containers
- Navigation hamburger menu works on mobile
- Hero section readable at all sizes
- Section padding appropriate at each size

**How to check:** Read the component source code and verify Tailwind responsive classes are present (mobile-first with `md:` and `lg:` breakpoints). If a component has no responsive classes, it's likely broken on mobile.

**Fix approach:** Add missing responsive classes. Fix silently since this doesn't change the approved desktop design.

### Font Loading (G1)

- Verify the Google Fonts `<link>` URL in `BaseLayout.astro` is not the placeholder (`REPLACE_WITH_GOOGLE_FONTS_URL`)
- Verify the URL is well-formed and includes the correct font families and weights
- Verify `global.css` font names have been replaced (not still `system-ui` with `/* REPLACE: heading font */` or `/* REPLACE: body font */` comments)

**Fix approach:** If placeholders remain, fill them from the approved direction's fonts. Fix silently.

### Token Consistency (G1)

Grep all `.astro` files in `src/components/` and `src/pages/` for hardcoded color values:
- Hex values (`#[0-9a-fA-F]{3,8}`)
- RGB/RGBA values (`rgb(`, `rgba(`)
- Named CSS colors used for theming (not `white`, `black`, or `transparent` which are fine)

**Exceptions:** The comparison nav bar uses inline styles intentionally. Ignore those. Also ignore SVG fills that reference brand colors directly (favicons, decorative elements).

**Fix approach:** Replace hardcoded values with the corresponding @theme token. Fix silently.

### Animation Health (G1)

- No animation causes layout shift (elements jumping position on load)
- CSS transitions use `transform` and `opacity` (GPU-accelerated), not `width`, `height`, `top`, `left`
- Staggered animations have reasonable delays (not more than 1-2 seconds total)
- `prefers-reduced-motion` media query respected for non-essential animations

**Fix approach:** Fix silently.

### Design Quality Review (G1)

This is the creative evaluation. The checks above verify technical correctness. This review evaluates whether the design output matches the quality standards in `references/component-library.md` and would hold up as intentional, professional work -- not generic AI output.

**Read the Design Quality Standards** section of `references/component-library.md` before running this review.

**Evaluate each dimension against the approved homepage:**

**1. Typography Quality**
- Are the fonts distinctive and characterful? (Not Inter, Roboto, Arial, Open Sans, Space Grotesk, or system fonts)
- Is there dramatic size contrast between headings and body text? (H1 should feel visually dominant, not just slightly larger)
- Does the font pairing have personality that matches the business?
- Check: Read `global.css` for font-size scale. If H1 is less than 2.5x body size, the contrast is likely too weak.

**2. Color Distribution**
- Is there a clear dominant color with sharp accents? (Not an even 20/20/20/20/20 split across five colors)
- Is the accent color used sparingly and deliberately? (Accent should appear in 2-3 places max, not sprinkled everywhere)
- Do alternating section backgrounds create visual rhythm without feeling random?
- Check: Count how many times each @theme color token appears across components. Primary should appear most. Accent should appear least.

**3. Spatial Composition**
- Is the spacing system committed to a direction? (Generous breathing room OR controlled density -- not splitting the difference)
- Is section spacing consistent? (All sections use the same vertical padding, or intentional variation for emphasis)
- Does the content width feel intentional? (Not just default max-w-7xl everywhere)
- Is there any compositional surprise? (Asymmetry, overlap, a grid-breaking element, or unexpected spatial relationship -- at least one moment that doesn't feel like a template)

**4. Background & Atmosphere**
- Do sections have depth and atmosphere? (Gradients, textures, patterns, layered elements -- not all flat solid colors)
- Do dark sections and light sections feel like they belong to the same design system?
- Is the background treatment appropriate to the vibe? (Minimal vibe = subtle/restrained treatment. Bold vibe = dramatic treatment.)

**5. Motion & Interaction**
- Is there at least one orchestrated animation moment? (Page load reveal, scroll-triggered entrance, hover state)
- Do animations feel intentional and matched to the vibe? (Slow/confident for luxury. Snappy/energetic for bold.)
- Are hover states present on interactive elements? (Buttons, cards, links)

**6. Overall Distinctiveness**
- Does this site look like it was designed for *this specific business*? (Not a template with colors swapped)
- Could you identify the business type/personality from the design alone, without reading the text?
- Is there at least one design choice that feels unexpected or memorable?

**Scoring:** Rate each dimension as Strong, Adequate, or Weak.

- **All Strong or Adequate:** Pass. Note any Adequate areas as opportunities in the spec but don't block.
- **Any Weak dimension:** Flag it. Present to the user with a specific proposal:

"Your site passes all technical checks. One design note: [dimension] could be stronger. Right now [specific observation]. I could [specific improvement] to give it more [quality]. Want me to take a pass at it, or is this the feel you want?"

**Important:** The user's preference wins. If they say "I like it as is," respect it immediately and note it in `design-taste.md`. The design quality review is an offer, not a gate. It catches cases where Claude defaulted to safe/generic output, not cases where the user made a deliberate aesthetic choice.

**Write findings to `website-spec.md`:** Record the evaluation results in the QA Gate 1 Findings section. Include what scored Strong, what scored Adequate (with notes), and what was flagged and how it was resolved. This becomes the design quality baseline for future sessions -- if Claude adds a page later, it should meet the same bar.

### Build Verification (G1)

Run `npm run build`. Must complete with zero errors and zero warnings.

**Fix approach:** Read the error, fix the source file, rebuild.

---

## Gate 2: Content Integrity

Runs at the end of Milestone 2, after SEO is applied to the homepage and before writing the handoff to `website-spec.md`.

### Placeholder Sweep (G2)

Grep all files in `src/` for:
- `Lorem ipsum` (any case)
- `dolor sit amet`
- `REPLACE_WITH` or `[PLACEHOLDER]` or `[TODO]`
- `href="#"` or `url: "#"` (CTA buttons pointing nowhere)
- `My Business` (unless it's the actual business name)
- `Your Headline` or `Your Subheadline`
- `example.com` (in content, not in astro.config.mjs which is updated at deploy)

**Fix approach:** If Claude can infer the correct content from Growth OS files or context, fix silently. If not, list each placeholder and ask the user.

### Voice Alignment (G2)

Read `core/brand-voice.md` (if available). For each text-heavy section on the homepage:
- Identify whether the section should use Reynolds (content) or Draper (sales)
- Check that the copy matches the voice mode's characteristics
- Flag any section where the tone feels generic or mismatched

**Check for common voice violations:**
- Corporate jargon that doesn't match the voice ("leverage," "synergy," "solutions")
- Passive voice where active is expected
- Em dashes (global rule: never use em dashes)
- "Not X, it's Y" reframe constructions (global rule: never use)
- Shame hooks or "you're doing it wrong" openers (global rule: never use)

**Fix approach:** Rewrite flagged copy to match the correct voice. Present rewrites for user approval since they change approved content.

### Persona Alignment (G2)

Read `core/persona.md` (if available). Verify:
- The homepage speaks to the primary persona (Robin for B2C/solo, Brian for B2B/teams, or whichever the user specified)
- Pain points and desires referenced match the persona's documented concerns
- The language register matches the persona's sophistication level

**Fix approach:** Flag misalignments and propose rewrites. Present for user approval.

### CTA Audit (G2)

For every button and link styled as a CTA:
- Has real, descriptive text (not "Click Here" or "Submit")
- Points to a real URL (not `#`)
- Primary CTA is consistent across sections (same text and destination)
- Secondary CTAs have distinct, appropriate destinations

**Fix approach:** Ask the user for any missing URLs. Fix text issues silently if the intent is clear.

### Content Data Validation (G2)

For every JSON file in `src/content/`:
- Valid JSON (parses without error)
- No empty string values for required fields
- No placeholder values ("John Doe", "Company Name", "Lorem ipsum")
- Arrays have at least the minimum expected entries (e.g., testimonials should have 2+)

**Fix approach:** Fix JSON syntax silently. Flag placeholder content and ask the user.

### Heading Hierarchy (G2)

For the homepage:
- Exactly one `<h1>` (in the Hero component)
- `<h2>` for each section heading
- `<h3>` for sub-items within sections
- No skipped levels (H1 to H3 without H2)
- Primary keyword appears in the H1

**Fix approach:** Fix heading levels silently. Flag keyword issues for user input.

### Image Alt Text Quality (G2)

For every `<img>` tag:
- Has a non-empty `alt` attribute
- Alt text is descriptive of purpose, not just appearance
- Decorative images use `alt=""`
- No alt text says "image", "photo", "picture", or repeats the filename

**Fix approach:** Rewrite weak alt text silently. If an image's purpose is unclear, ask the user.

### AI Discoverability -- Content (G2)

Verify the homepage content is structured for AI citation. See `references/seo-checklist.md` Section 8 for the full checklist.

**Passage citability:**
- Each major content section has a self-contained answer block in its opening 40-60 words
- Key claims are stated as direct, quotable sentences (not buried in paragraphs or hedged with qualifiers)
- Services, features, and benefits appear in bullet points or tables, not only prose
- Statistics and data points include their source or context

**Structural readability:**
- Paragraphs are 2-4 sentences (not walls of text)
- H2/H3 headings are descriptive and question-based where natural
- FAQ answers are complete sentences that stand alone without the question
- No critical content hidden behind JavaScript interactions or collapsed accordions

**Entity clarity:**
- Business name appears in consistent form (not "Smith Co" in hero and "Smith Consulting" in footer)
- Owner/founder name consistent with credentials
- Primary offer named explicitly

**Fix approach:** Restructure content for citability silently (breaking long paragraphs, adding list formatting). Changes that alter approved copy (rewriting a buried claim into a direct statement) should be presented for approval.

---

## Gate 3: Site Integrity

Runs at the end of Milestone 3, after all pages are built and SEO is applied, before writing the handoff to `website-spec.md`.

### Cross-Page Navigation (G3)

- Every link in `site-data.json` navLinks resolves to an existing page in `src/pages/`
- Every page's header navigation matches `site-data.json`
- Footer navigation matches header navigation (or is an intentional subset)
- No orphan pages (pages that exist but aren't linked from navigation)

**Fix approach:** Fix silently by updating `site-data.json` or adding missing pages to navigation.

### Voice Consistency (G3)

Spot-check that all pages sound like the same brand:
- Read the hero/intro copy from each page
- Verify consistent tone, register, and personality across all pages
- Flag any page that sounds notably different from the homepage

**Fix approach:** Rewrite to match. Present for user approval.

### Shared Data Consistency (G3)

- Testimonials: same quote text, author name, and title everywhere they appear
- Stats: same numbers everywhere they appear
- Services: same names and descriptions everywhere they appear
- Business info: same name, tagline, contact info everywhere

**How to check:** Read each JSON data file in `src/content/`. Search all pages for inline content that should match. Flag any discrepancies.

**Fix approach:** Fix silently by updating to match the canonical data file.

### SEO Completeness (G3)

Run the full per-page checks (Sections 1-8) and site-wide checks (Sections 9-15) from `references/seo-checklist.md` on every page. That checklist is the single source of truth for all SEO and AEO criteria.

**Fix approach:** Fix missing/duplicate meta tags silently. Fix schema silently. Flag any issue that requires user input (e.g., choosing a keyword for a title).

### Link Integrity (G3)

- All internal `href` values resolve to existing pages
- No `href="#"` on any CTA or navigation link
- All external links (if any) use `target="_blank" rel="noopener noreferrer"`
- No duplicate internal links pointing to the same page with different paths

**Fix approach:** Fix silently where possible. Ask the user for any missing URLs.

### Mobile Verification (G3)

For every page (not just homepage):
- Verify responsive classes are present on all components
- Header hamburger menu accessible on all pages
- No horizontal overflow
- Touch targets are at least 44x44px for buttons and links

**Fix approach:** Fix silently.

### AI Discoverability -- Site-Wide (G3)

Verify AEO implementation across all pages. Re-run the Gate 2 AI Discoverability checks on every page (not just homepage). Additionally:

**Schema enrichment:**
- Organization schema on homepage includes `sameAs` with social profile URLs (if user provided them)
- Person schema on About page includes `knowsAbout` and `sameAs` (if user provided them)
- All schema properties match actual visible page content (never fabricated)

**Cross-page entity consistency:**
- Business name identical in every schema block, every page header, every footer, every meta title suffix
- Owner name identical in Person schema, About page content, and any homepage mention
- Service names identical in Services page schema, homepage mentions, and navigation

**Content structure across pages:**
- Every page has at least one self-contained, citable passage
- About page includes credentials and expertise in plain text (not only in images)
- Services page describes each offering with enough detail for AI to summarize it

**Fix approach:** Fix schema and entity consistency silently. Flag content restructuring for user approval if it changes visible copy.

### Full Build (G3)

Run `npm run build`. Must complete with zero errors and zero warnings. Verify sitemap output line appears.

**Fix approach:** Read the error, fix the source file, rebuild.

---

## Gate 4: Deploy Readiness

Runs at the beginning of Milestone 4, before any deployment steps.

### Configuration (G4)

- `astro.config.mjs` site field is NOT `https://example.com` (it gets set during deployment, but verify it's ready to be set)
- `site-data.json` has the real business name (not "My Business" or placeholder)
- `site-data.json` CTA URL is a real destination
- `site-data.json` socialLinks are populated (or intentionally empty)

### Dev Artifact Cleanup (G4)

Grep `src/pages/` for files that should have been removed:
- `direction-1.astro`, `direction-2.astro`, `direction-3.astro`
- `current.astro`, `option-1.astro`, `option-2.astro`, `option-3.astro`
- Any file with "comparison" or "direction" in the name

Also check for comparison nav HTML remnants in any remaining page files (the dark nav bar with direction/option links).

**Fix approach:** Delete artifact files and remove remnant HTML silently.

### llms.txt (G4)

- `public/llms.txt` exists with business name, elevator pitch, and links to all pages
- Each page link has a one-line description
- Key Facts section has 2-4 statements about the business
- Format follows the llms.txt standard (see `references/schema-patterns.md`)

**Fix approach:** Generate silently using the template. Ask the user to verify the Key Facts are accurate.

### AI Crawler Access (G4)

- `public/robots.txt` does not block AI crawlers: GPTBot, OAI-SearchBot, ChatGPT-User, ClaudeBot, PerplexityBot
- Default `User-agent: * / Allow: /` is correct for maximum AI discoverability
- No page-specific `Disallow` rules that would block content pages

**Fix approach:** Fix silently. If custom robot rules exist, verify they don't block AI crawlers.

### Sensitive Content (G4)

Grep all files for:
- API keys or tokens (patterns: `sk_`, `pk_`, `api_key`, `secret`)
- `.env` references that shouldn't be in source
- Hardcoded credentials or passwords

**Fix approach:** Flag immediately. Never deploy with exposed credentials.

### Final Build (G4)

Run `npm run build` one final time. Must complete cleanly.

**Fix approach:** Fix any issues before proceeding to deployment.

### Pre-Deploy Summary (G4)

Present a brief deploy readiness report:

"Your site is ready to deploy. Final check:

- [X] pages built and approved
- [X] Clean build
- [X] SEO complete (meta tags, schema, sitemap, robots.txt)
- [X] No placeholder content
- [X] No dev artifacts
- [X] Favicon present

Ready to go live?"

---

## Post-Launch Re-Check

The `site-health` command uses this same checklist for post-launch verification. It runs all checks from Gates 1-4 as a single pass, reporting any issues that may have been introduced after deployment (content drift, new pages without SEO, broken links from URL changes, etc.).
