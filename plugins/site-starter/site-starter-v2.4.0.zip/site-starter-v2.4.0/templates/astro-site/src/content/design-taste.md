# Design Taste

Preferences captured from design iteration sessions. Read this before making design decisions. Claude populates this file during Milestone 1 (Design Direction) and updates it whenever the user reacts to a design choice in any future session.

## Colors

<!-- Example entries:
- Prefers lighter backgrounds over dark (reacted "too dark" to initial palette)
- Likes cool-toned accents (chose blue over orange)
- Dislikes warm oranges (requested "cooler accent colors")
-->

## Typography

<!-- Example entries:
- Prefers all sans-serif (rejected serif heading fonts)
- Likes generous heading sizes (wanted "more dramatic" size contrast)
- Approved "Plus Jakarta Sans" for headings
-->

## Spacing

<!-- Example entries:
- Likes generous breathing room between sections (asked for "more padding")
- Wants generous nav padding (requested 20px+ top and bottom)
- Prefers larger hero sections with lots of white space
-->

## Components

<!-- Example entries:
- Prefers rounded buttons over sharp-edged ones
- Likes soft shadows on cards
- Wants headshots on testimonial cards
-->

## Anti-preferences

<!-- Example entries:
- Dislikes orange for CTAs or accents
- Doesn't want dark/moody backgrounds
- No serif fonts anywhere
-->
