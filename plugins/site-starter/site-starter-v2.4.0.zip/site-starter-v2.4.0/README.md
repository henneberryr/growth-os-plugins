# Site Starter v2.4.0

> Build a live website with Claude in one session. Design-first. Visual-first. No coding required.

## What It Does

Site Starter builds a professional website through four milestones: Design Direction, Content, Full Site, and Go Live. The core philosophy is **get to something visual as fast as possible, then iterate.**

You see real output in your browser within minutes. You react to actual design, not abstract questions about hex codes or font names. Design and content are evaluated separately -- design first, words second. By the time content goes in, the design direction is already set.

If you've already run Growth OS Quick Start, Site Starter picks up what it already knows about your business. You confirm it and jump straight to designing. Site Starter also works standalone without Growth OS -- Claude will ask you a few questions to get started.

Everything runs in Claude Code -- one continuous conversation from "build my website" to "your site is live."

## What You Need Before Starting

**Just one thing: Node.js.** Download it from nodejs.org and run the installer.

Everything else (GitHub, Vercel) gets set up later when you're ready to put your site on the internet. Claude walks you through it. See `references/setup-guide.md` for details.

## How It Works

### Milestone 1: Design Direction

Claude explains the plan, then asks 3-4 quick questions. Then it builds three different design directions and puts them in your browser as separate pages you can click between. You pick your favorite (or mix elements), then refine fonts and colors until you love it. Claude extends the design down the full homepage with placeholder copy so you can see the full visual rhythm. Everything is changeable anytime -- this step is about establishing a starting point.

### Milestone 2: Content

Claude reads your Growth OS files (offers, persona, voice) and fills in the approved design with real copy. You go through the homepage section by section, evaluating the words and messaging. This is where photos come in naturally -- headshots for testimonials, hero images, product photos.

### Milestone 3: Full Site

Claude builds the remaining pages (About, Services, etc.) using the established design and content patterns. Each page reuses approved components and imports shared content from data files.

### Milestone 4: Go Live

Claude walks you through setting up GitHub and Vercel, pushes your site, and it's live. Optional custom domain setup.

## After Your Site Is Live

- **Edit anything:** "Change the headline on my homepage to X"
- **Add pages:** "Add a podcast page" or "Build me a contact page"
- **Change the look:** "Make the buttons rounder" or "Switch to a darker color scheme"
- **Publish changes:** Say "push my changes"

Claude remembers your design preferences in a living `design-taste.md` file. The more you iterate, the better Claude knows your taste.

## What It Produces

```
[your-site]/
├── package.json                  # Astro project config
├── astro.config.mjs              # Site settings
├── src/
│   ├── layouts/
│   │   └── BaseLayout.astro      # Global layout (SEO, fonts, analytics)
│   ├── components/               # Section blocks Claude composes into pages
│   │   ├── Header.astro
│   │   ├── Footer.astro
│   │   ├── Hero.astro
│   │   ├── FeatureGrid.astro
│   │   ├── Testimonial.astro
│   │   ├── CtaBanner.astro
│   │   └── [more as needed]
│   ├── pages/
│   │   ├── index.astro           # Homepage
│   │   ├── about.astro           # About page
│   │   └── services.astro        # Services or Products page
│   ├── content/
│   │   ├── site-data.json        # Global config (nav, footer, socials)
│   │   ├── design-taste.md       # Living design preferences
│   │   ├── testimonials.json     # Shared content (created as needed)
│   │   ├── stats.json            # Shared content (created as needed)
│   │   └── [others as needed]
│   └── styles/
│       └── global.css            # Brand colors, fonts, spacing
├── public/
│   ├── images/                   # Your logo, photos, assets
│   ├── favicon.svg               # Auto-generated letter favicon
│   ├── sitemap.xml               # XML sitemap for search engines
│   └── robots.txt                # Crawler instructions
├── brand-kit.md                  # Exportable brand system (colors, fonts, tokens)
└── website-spec.md               # Progressive spec (grows through milestones)
```

## Key Concepts

### Three-Way Design Comparison

Instead of building one design and asking "do you like it?", Claude builds three distinct design directions and explains the thinking behind each one. You pick your favorite or mix elements. This is the fastest path to a design you love because choosing between options is easier than describing what you want.

### Design-First, Content-Second

Placeholder copy during design iteration means you evaluate one thing at a time. Colors, fonts, and spacing first. Words second. When you're reviewing content, the design direction is already set.

### Design Taste (Living File)

Every time you react to a design choice ("too dark," "I don't like orange," "more breathing room"), Claude captures that preference in `design-taste.md`. Future pages and sites start from a better place because Claude already knows your taste.

### Built-in SEO

Every page automatically gets: meta titles and descriptions, JSON-LD structured data (schema markup), an XML sitemap, and a robots.txt file. No extra setup required.

### Brand Kit Export

After the design direction is set, Claude generates a portable `brand-kit.md` with your colors, fonts, and tokens in a format you can share with designers or use in other tools.

### Built-in QA Gates

Every milestone ends with an automatic quality check. Claude runs it without being asked, fixes what it can silently, and flags anything that needs your input. Four gates catch issues at the moment they're introduced:

1. **Design Integrity** (end of M1) -- color contrast, responsive layout, font loading, token consistency
2. **Content Integrity** (end of M2) -- placeholder sweep, voice/persona alignment, CTA audit, heading hierarchy
3. **Site Integrity** (end of M3) -- cross-page navigation, voice consistency, SEO completeness, link integrity, mobile verification
4. **Deploy Readiness** (start of M4) -- configuration, dev artifact cleanup, sensitive content scan, final build

### Site Health Check

Run `/site-health` after launch to re-check all quality criteria. It runs the same checks from all four QA gates as a single pass, catching any issues introduced after deployment.

### Content Refresh

Run `/refresh-content` to sync your site with your latest Growth OS files. If you've added a new service or updated your pricing, Claude flags the differences and offers to update your site.

### Content Data Files

Shared content (testimonials, stats, credentials) is stored in JSON files in `src/content/`. Edit once, update everywhere.

## Commands

| Command | What It Does |
|---------|-------------|
| "build my website" | Start the full Site Starter flow (4 milestones) |
| "preview my site" | Start local dev server |
| "go live" / "push my changes" | Deploy or push updates |
| "add a page" | Add a new page to an existing site |
| `/site-seo` | Audit and optimize SEO across the site |
| `/site-health` | Post-launch health check |
| `/refresh-content` | Sync site with Growth OS changes |

## How to Install

1. Install Node.js (see `references/setup-guide.md`)
2. Download the Site Starter .zip file
3. Open Claude Desktop and switch to **Claude Code**
4. Install the plugin from the .zip
5. Say "build my website" to begin

## Version History

- **v2.4.0** (2026-04-04) -- Audit-driven improvement release. Token diet: trimmed component-library.md by ~15KB (removed props tables and styling notes Claude doesn't need), deduplicated SEO checks across qa-checklist/site-seo/seo-checklist into single authority, removed inline templates from site-starter.md. Bug fixes: corrected build location in setup-guide, fixed placeholder fonts that failed silently (now fall back to system-ui), clarified scaffolding mechanism, added package.json name update. SEO consistency: seo-checklist.md is now the single source of truth for all SEO/AEO criteria. Added Twitter/X card meta tags to BaseLayout. Capture model: passive capture added to all 6 commands (not just the main flow). Prompted capture at session close asks about unrecorded preferences. Session log in website-spec enables proactive intelligence on return. Cross-reference fixes: new-page.md reads the spec's creative compass. Milestone skip handling specifies what to document. Template improvements: analytics slot in BaseLayout, custom 404 page, skip-to-content accessibility link. UX polish: returning users get a short welcome-back instead of the full opening monologue. Image optimization with macOS sips compression.
- **v2.3.0** (2026-04-04) -- 4-gate QA system, design quality review, and expanded website spec. QA gates at every milestone boundary: Design Integrity (contrast, responsive, fonts, tokens, design quality), Content Integrity (placeholders, voice/persona alignment, CTAs, headings), Site Integrity (navigation, cross-page consistency, SEO, links, mobile), Deploy Readiness (config, artifact cleanup, sensitive content). Design quality review evaluates 6 dimensions (typography, color distribution, spatial composition, atmosphere, motion, distinctiveness) inspired by Anthropic's front-end design principles. Website spec expanded from state tracker to creative compass: design principles per site, direction comparison with rejection history, QA gate findings, messaging hierarchy, objection handling map, voice modes per page, cross-page content flow. Shared QA checklist (`references/qa-checklist.md`). Refactored `site-health` to re-check all gates post-launch.
- **v2.2.0** (2026-03-29) -- Post-testing UX overhaul. Site builds inside workspace folder (no migration needed). Three design directions on separate pages with comparison nav. Structured options at every comparison point (pick, mix, or try again). Font and color refinement loop with "Current + 3 Options" pattern. Opening experience explains the plan and gets buy-in. Replaced "locked" language with "direction is set" throughout. Everything framed as changeable.
- **v2.1.0** (2026-03-29) -- Three-way design comparison (three hero variations with rationale). Built-in SEO: meta tags, JSON-LD schema, XML sitemap, robots.txt. Brand kit export after design direction is set. Guided photo placement during content review. Auto-generated SVG favicon. Post-launch site health check (`/site-health`). Content refresh from Growth OS (`/refresh-content`). Cross-site design taste import. Accessibility and image optimization guidance. Template bug fixes (Inter font, hardcoded business name, example.com URL).
- **v2.0.0** (2026-03-29) -- Design-first rewrite. Four milestones replace old Spec/Build/Go Live. Hero-first build. Placeholder copy separates design from content. Living design-taste.md. Reference site discovery. Section-by-section guided iteration. Content data files.
- **v1.2.0** (2026-03-29) -- Content data files pattern. Shared content stored in JSON, imported by pages.
- **v1.1.0** (2026-03-23) -- Local build in Documents folder. Deferred prerequisites. Post-deployment migration.
- **v1.0.0** (2026-03-23) -- Initial release. Component library architecture. Growth OS context scanning.
