---
name: seo-audit
description: "**Search Party SEO Audit**: Full SEO audit and optimization for any website. Covers on-page analysis, keyword research, schema markup, technical SEO, E-E-A-T, GEO/AEO, and Google API data. Use when user says 'SEO audit', 'optimize for SEO', 'check my SEO', 'search party', 'audit my site', 'make this rank', or anything about improving search visibility."
---

# Search Party SEO Audit

This skill audits any website page and applies a complete SEO and AI discoverability optimization pass. It covers title tags, meta descriptions, JSON-LD structured data, semantic HTML, and content structure for both traditional search engines and AI-powered discovery (ChatGPT search, Perplexity, Google AI Overviews).

## Sub-Commands

Search Party includes specialized sub-commands for deeper analysis. Route to these when the user requests a specific capability, or dispatch them as parallel subagents during a full audit.

| Sub-Command | Trigger Phrases | File |
|-------------|----------------|------|
| **Technical SEO** | "technical audit", "crawlability", "Core Web Vitals", "page speed" | `commands/seo-technical.md` |
| **Content Quality (E-E-A-T)** | "E-E-A-T", "content quality", "expertise audit", "trust signals" | `commands/seo-content-quality.md` |
| **GEO / AEO** | "GEO", "AEO", "AI Overviews", "generative engine optimization" | `commands/seo-geo.md` |
| **Google APIs** | "Search Console", "PageSpeed", "CrUX", "GA4", "Google SEO data" | `commands/seo-google.md` |
| **Backlinks** | "backlinks", "link profile", "referring domains" | `commands/seo-backlinks.md` |
| **Competitor Pages** | "competitor comparison", "X vs Y page", "alternatives page" | `commands/seo-competitor-pages.md` |

### Dispatch Rules

- **Full audit**: Run the core workflow below, then spawn `seo-technical` and `seo-content` agents in parallel for deeper analysis. Include `seo-geo` if the page is content-heavy.
- **Specific sub-command**: When the user asks for a specific capability, read and execute that sub-command directly.
- **Google API commands**: Route to `commands/seo-google.md` for Search Console, PageSpeed, CrUX, or GA4 requests. Python scripts live in `scripts/` -- install deps with `pip install -r scripts/requirements.txt`.

---

## Workflow

### Step 1: Identify the Page

Ask the user which page to optimize. They'll specify by:
- A URL (e.g., "audit example.com/about")
- A file path (e.g., "optimize the about page")
- A general reference (e.g., "SEO the pricing page")

Fetch or read the page source before doing anything else. Use WebFetch for live URLs or Read for local files.

### Step 2: Detect the Site Stack

Identify the technology powering the site:
- **Static site generators**: Astro, Next.js, Gatsby, Hugo, Jekyll
- **CMS platforms**: WordPress, Shopify, Squarespace, Webflow, Wix
- **Frameworks**: React, Vue, Angular (SPA concerns)
- **Plain HTML**

This determines how to implement fixes (e.g., where title tags are set, how schemas are injected, whether there's a build step).

### Step 3: Classify the Page Type

Determine which category the page falls into. This dictates which schemas and optimization patterns to apply.

| Page Type | Common Schema Types |
|-----------|-------------------|
| **Homepage** | Organization, WebSite, SearchAction |
| **Sales/service page** | Service, Offer, FAQPage |
| **Blog post / Article** | Article, BreadcrumbList |
| **Product page** | Product, Offer, AggregateRating |
| **About page** | Organization, Person |
| **Course / Training** | Course, BreadcrumbList |
| **FAQ page** | FAQPage |
| **Contact page** | LocalBusiness, ContactPoint |
| **Category / Listing** | ItemList, CollectionPage |
| **Legal / Utility** | BreadcrumbList only |

### Step 4: Keyword Research

**This step is required.** Every page needs a primary keyword and a secondary keyword chosen based on what people actually search for.

Read `references/keyword-research.md` for the full methodology. The short version:

1. **Identify the page's core problem or topic.** What question does this page answer?
2. **Search for how people phrase that problem.** Use WebSearch to find actual terms, "People also ask" questions, and competitor keywords.
3. **Pick a primary keyword** (highest-intent, most relevant phrase). This goes in the title tag and H1.
4. **Pick a secondary keyword** (alternative phrasing or related query). This goes in the meta description and body content.
5. **Validate fit.** The keyword must match the page's actual content.

**Present both keywords to the user for approval** before proceeding.

### Step 5: Run the Audit

Read `references/seo-checklist.md` and evaluate each item against the page. Score every item as:
- **Pass** -- already correct
- **Needs work** -- present but suboptimal
- **Missing** -- not implemented at all
- **N/A** -- not applicable to this page type

### Step 6: Present the Audit Report

Present findings organized by priority:

**Critical (must fix):**
- Missing or duplicate title tags
- Missing meta description
- Missing JSON-LD schemas for the page type
- No H1 or multiple H1s

**Recommended (should fix):**
- Title tag not keyword-optimized or too long (over 60 chars)
- Meta description too short/long or not compelling
- Missing image alt text
- Heading hierarchy issues
- Missing BreadcrumbList schema
- No internal links to/from the page

**Nice-to-have:**
- Content structure improvements for AI crawlers
- Additional schema types
- Lazy loading on below-fold images

Then present options for the user to approve:
- **Title tag:** 2-3 variations with character counts
- **Meta description:** 2 variations with character counts
- **Schemas:** Which JSON-LD types will be added

Read `references/title-and-meta-rules.md` before drafting titles and descriptions.

Wait for user approval before implementing.

### Step 7: Implement

After approval, apply all changes:

1. **Title and description:** Update in whatever format the site stack uses
2. **JSON-LD schemas:** Read `references/schema-patterns.md` and `references/schema-templates.json` for templates. Inject as `<script type="application/ld+json">` blocks.
3. **Other fixes:** Apply heading, alt text, semantic HTML, or content structure fixes
4. **Build and verify:** If the site has a build step, run it to confirm no errors
5. **Internal links:** Confirm the page is linked from at least one other page

### Step 8: Save the Audit Report

Save a summary to the workspace:

```markdown
# SEO Audit: {Page Name}
**Date:** {YYYY-MM-DD}
**Page:** {URL}

## Changes Applied
- Title: "{old}" -> "{new}"
- Description: "{old}" -> "{new}"
- Schemas added: {list}
- Other fixes: {list}

## Audit Scores
| Item | Status |
|------|--------|
| Title tag | Pass |
| Meta description | Fixed |
| ... | ... |
```

---

## Rules

1. **Always include BreadcrumbList.** Every page gets a BreadcrumbList schema. No exceptions.
2. **Never fabricate claims.** Schema data must match what's actually on the page.
3. **Use absolute URLs in schemas.** Always use full URLs, never relative paths.
4. **No em dashes.** Use regular dashes in all meta content.
5. **All title tags use title case.** Capitalize every word except small prepositions/conjunctions. Preserve acronyms (AI, SOP, WCAG, AEO, SEO) as uppercase.
6. **Keyword research is mandatory.** Never write a title tag without first identifying a primary keyword through actual search research.
7. **Present before implementing.** Always show the user what you plan to change and get approval before editing files.

---

## Python Scripts (Optional)

For deeper analysis, Search Party includes Python scripts in `scripts/`. Install dependencies first:

```bash
pip install -r scripts/requirements.txt
```

| Script | Purpose |
|--------|---------|
| `google_report.py` | PDF/HTML report generation with charts |
| `pagespeed_check.py` | PageSpeed Insights API v5 + CrUX |
| `gsc_query.py` | Search Console queries and pages |
| `gsc_inspect.py` | URL Inspection (single + batch) |
| `google_auth.py` | Google API credential management |
| `fetch_page.py` | Page fetcher with UA rotation |
| `parse_html.py` | HTML SEO element extraction |
| `crux_history.py` | 25-week Core Web Vitals trends |
| `ga4_report.py` | GA4 organic traffic reporting |
