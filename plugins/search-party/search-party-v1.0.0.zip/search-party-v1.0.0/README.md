# Search Party

Full-stack SEO audit and optimization plugin for Growth OS. Search Party sends a crew through your entire site to find what's missing, what's broken, and what's holding you back from ranking.

## What It Does

- Audits any page for on-page SEO, schema markup, and content structure
- Runs keyword research using real search data
- Generates optimized title tags, meta descriptions, and JSON-LD schemas
- Analyzes technical SEO across 9 categories (crawlability, indexability, security, Core Web Vitals, mobile, URL structure, redirects, structured data validation)
- Evaluates content quality using the E-E-A-T framework
- Optimizes for AI search (Google AI Overviews, ChatGPT, Perplexity)
- Connects to Google Search Console, PageSpeed Insights, CrUX, and GA4 for real field data
- Generates competitor comparison pages ("X vs Y")
- Analyzes backlink profiles and link quality

## Commands

| Command | What It Does | Say This |
|---------|-------------|----------|
| `seo-audit` | Full page audit with keyword research, schema, and optimization | "SEO audit", "check my SEO", "optimize this page" |
| `seo-technical` | Deep technical SEO audit (9 categories) | "technical audit", "crawl issues", "Core Web Vitals" |
| `seo-content-quality` | E-E-A-T and content quality analysis | "E-E-A-T", "content quality", "trust signals" |
| `seo-geo` | AI search optimization (GEO/AEO) | "GEO", "AI Overviews", "AI search optimization" |
| `seo-google` | Google API data (Search Console, PageSpeed, CrUX, GA4) | "Search Console data", "PageSpeed check", "CrUX" |
| `seo-backlinks` | Backlink profile analysis | "backlinks", "link profile", "referring domains" |
| `seo-competitor-pages` | Generate "X vs Y" comparison pages | "competitor comparison", "vs page", "alternatives page" |

## Getting Started

1. Install the plugin in your Growth OS workspace
2. Say "SEO audit" and provide a URL or page reference
3. Search Party will analyze the page, research keywords, and present recommendations
4. Approve the changes and Search Party implements them

## Google API Setup (Optional)

For real field data from Google, set up API credentials:

1. Create a Google Cloud project with Search Console API, PageSpeed Insights API, and GA4 Data API enabled
2. Create OAuth credentials or a service account
3. Run `python scripts/google_auth.py --setup` to configure

Without Google APIs, Search Party still performs a complete audit using page analysis, WebSearch, and WebFetch.

## Python Scripts (Optional)

Some features use Python scripts for API access and report generation. To set up:

```
pip install -r scripts/requirements.txt
```

Scripts work without setup for basic auditing. The Python layer adds Google API integrations and PDF report generation.

---

Built by theCLICK
