# JSON-LD Schema Patterns for theclick.ai

This reference contains ready-to-use JSON-LD structured data templates for every page type on theclick.ai. Each template is written in the Astro frontmatter format (JavaScript objects) and injected via `<script type="application/ld+json" set:html={JSON.stringify(schema)} />`.

## Implementation Pattern (Astro)

All schemas follow this two-part pattern:

**1. Define in frontmatter** (between the `---` fences):

```javascript
const mySchema = {
  "@context": "https://schema.org",
  "@type": "...",
  // ... properties
};
```

**2. Inject before closing `</BaseLayout>`:**

```astro
<script type="application/ld+json" set:html={JSON.stringify(mySchema)} />
```

Never use `is:inline` on these script tags. It breaks `set:html` rendering in Astro.

Multiple schemas go on separate script tags. Each page typically gets 2-4 schemas.

---

## Shared Constants

Use these across all schemas. They never change unless Russ updates business info.

```javascript
const ORG = {
  "@type": "Organization",
  "name": "theCLICK",
  "url": "https://theclick.ai",
  "logo": "https://theclick.ai/images/logos/theclickpro-dark.png"
};

const RUSS = {
  "@type": "Person",
  "name": "Russ Henneberry",
  "url": "https://theclick.ai",
  "jobTitle": "Founder",
  "description": "Digital marketing consultant, author of Digital Marketing for Dummies, and creator of Growth OS for Claude Cowork.",
  "worksFor": ORG
};
```

You don't need to define these as separate variables in every page. Inline them or copy the values directly into each schema. They're here as the canonical source of truth.

---

## BreadcrumbList (Every Page)

Every page on the site gets this schema. Adjust the final item to match the page.

```javascript
const breadcrumbSchema = {
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    {
      "@type": "ListItem",
      "position": 1,
      "name": "Home",
      "item": "https://theclick.ai"
    },
    {
      "@type": "ListItem",
      "position": 2,
      "name": "Page Name Here",
      "item": "https://theclick.ai/page-slug"
    }
  ]
};
```

For nested pages (e.g., `/blog/some-post`), add a middle breadcrumb:

```javascript
{
  "@type": "ListItem",
  "position": 2,
  "name": "Blog",
  "item": "https://theclick.ai/blog"
},
{
  "@type": "ListItem",
  "position": 3,
  "name": "Post Title",
  "item": "https://theclick.ai/blog/some-post"
}
```

---

## FAQPage (Any Page with FAQ Section)

If the page has an FAQ accordion or Q&A section, add this schema. Map directly from the page's FAQ data.

```javascript
const faqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": faqs.map(faq => ({
    "@type": "Question",
    "name": faq.q,        // or faq.question, depending on the data structure
    "acceptedAnswer": {
      "@type": "Answer",
      "text": faq.a        // or faq.answer
    }
  }))
};
```

This is eligible for FAQ rich snippets in Google search results. Only use it when the page has genuine FAQ content, not fabricated questions.

---

## Sales/Service Page

**Use for:** `/custom-claude-plugins`, `/teams`, any page selling a service.

**Schemas:** Service + FAQPage (if FAQ exists) + BreadcrumbList

```javascript
const serviceSchema = {
  "@context": "https://schema.org",
  "@type": "Service",
  "name": "Service Name Here",
  "description": "One-sentence description of the service.",
  "url": "https://theclick.ai/page-slug",
  "serviceType": "Category of service (e.g., AI Marketing Agent Configuration)",
  "areaServed": {
    "@type": "Place",
    "name": "Worldwide"
  },
  "provider": {
    "@type": "Person",
    "name": "Russ Henneberry",
    "url": "https://theclick.ai",
    "jobTitle": "Founder",
    "description": "Digital marketing consultant, author of Digital Marketing for Dummies, and creator of Growth OS for Claude Cowork.",
    "worksFor": {
      "@type": "Organization",
      "name": "theCLICK",
      "url": "https://theclick.ai",
      "logo": "https://theclick.ai/images/logos/theclickpro-dark.png"
    }
  },
  "offers": {
    "@type": "Offer",
    "price": "5000",                    // actual price from the page
    "priceCurrency": "USD",
    "description": "Pricing description as shown on page",
    "availability": "https://schema.org/InStock"
  },
  "hasOfferCatalog": {                  // optional: if the page lists deliverables
    "@type": "OfferCatalog",
    "name": "Deliverables",
    "itemListElement": deliverables.map(d => ({
      "@type": "Offer",
      "itemOffered": {
        "@type": "Service",
        "name": d.title,
        "description": d.desc
      }
    }))
  }
};
```

**Notes:**
- Only include `offers` if the page actually states a price. If pricing is "contact us" or "schedule a call" with no number, omit the `offers` property.
- The `hasOfferCatalog` is optional. Use it when the page has a clear list of deliverables or inclusions.
- `serviceType` should be a concise category, not a marketing tagline.

---

## Homepage

**Schemas:** Organization + WebSite + FAQPage (if FAQ exists) + BreadcrumbList (Home only, single item)

```javascript
const orgSchema = {
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "theCLICK",
  "url": "https://theclick.ai",
  "logo": "https://theclick.ai/images/logos/theclickpro-dark.png",
  "description": "AI marketing training for founders and marketers. Learn to plan, build, and ship growth campaigns with Growth OS for Claude Cowork.",
  "founder": {
    "@type": "Person",
    "name": "Russ Henneberry"
  },
  "contactPoint": {
    "@type": "ContactPoint",
    "email": "support@modernpublisher.com",
    "contactType": "customer support"
  },
  "sameAs": []   // add social profile URLs here when available
};

const webSiteSchema = {
  "@context": "https://schema.org",
  "@type": "WebSite",
  "name": "theCLICK",
  "url": "https://theclick.ai",
  "description": "AI marketing training and tools for founders and marketers.",
  "publisher": {
    "@type": "Organization",
    "name": "theCLICK",
    "url": "https://theclick.ai"
  }
};
```

**Notes:**
- The homepage BreadcrumbList is just a single item (Home).
- Add social URLs to `sameAs` as they become available (LinkedIn, YouTube, etc.).

---

## Training/Course Page

**Use for:** `/claude-cowork-quick-start-for-marketers`, `/chatgpt-canvas-for-marketing`, etc.

**Schemas:** Course + BreadcrumbList

```javascript
const courseSchema = {
  "@context": "https://schema.org",
  "@type": "Course",
  "name": "Course Title Here",
  "description": "One-sentence course description.",
  "url": "https://theclick.ai/page-slug",
  "provider": {
    "@type": "Organization",
    "name": "theCLICK",
    "url": "https://theclick.ai"
  },
  "instructor": {
    "@type": "Person",
    "name": "Russ Henneberry",
    "jobTitle": "Founder",
    "url": "https://theclick.ai"
  },
  "isAccessibleForFree": true,        // true for free trainings, false for paid
  "educationalLevel": "Beginner",     // or "Intermediate", "Advanced"
  "about": ["AI Marketing", "Claude Cowork"],   // topic tags
  "inLanguage": "en"
};
```

**Notes:**
- Set `isAccessibleForFree` based on whether the training is free or behind theCLICK Pro.
- `educationalLevel` should match the page's positioning (most free trainings are Beginner).
- `about` should contain 2-4 topic keywords relevant to the specific training.

---

## Blog Post

**Use for:** `/blog/[slug]` pages.

**Schemas:** Article + BreadcrumbList

```javascript
const articleSchema = {
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "Post Title Here",
  "description": "Brief summary of the article.",
  "url": "https://theclick.ai/blog/post-slug",
  "datePublished": "2026-02-24",         // ISO 8601
  "dateModified": "2026-02-24",          // update if edited
  "author": {
    "@type": "Person",
    "name": "Russ Henneberry",
    "url": "https://theclick.ai"
  },
  "publisher": {
    "@type": "Organization",
    "name": "theCLICK",
    "url": "https://theclick.ai",
    "logo": {
      "@type": "ImageObject",
      "url": "https://theclick.ai/images/logos/theclickpro-dark.png"
    }
  },
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://theclick.ai/blog/post-slug"
  },
  "image": "https://theclick.ai/images/blog/post-image.jpg"   // if available
};
```

**Notes:**
- `headline` must match the page's H1 exactly or be very close.
- `image` is optional but strongly recommended. Use the post's hero/featured image.
- Use the actual publish date from the blog post's frontmatter or content collection.

---

## About Page

**Schemas:** Person + Organization + BreadcrumbList

```javascript
const personSchema = {
  "@context": "https://schema.org",
  "@type": "Person",
  "name": "Russ Henneberry",
  "url": "https://theclick.ai/about",
  "jobTitle": "Founder",
  "description": "Digital marketing consultant, author of Digital Marketing for Dummies, and creator of Growth OS for Claude Cowork. Teaches marketers and founders how to use AI for business growth.",
  "worksFor": {
    "@type": "Organization",
    "name": "theCLICK",
    "url": "https://theclick.ai"
  },
  "image": "https://theclick.ai/images/instructorImage.png",
  "knowsAbout": ["AI Marketing", "Digital Marketing", "Growth OS", "Claude Cowork", "Content Marketing"],
  "sameAs": []   // social profile URLs
};
```

---

## Plugin Detail Page

**Use for:** `/plugins/[slug]` (e.g., `/plugins/growth-os-healthcare`)

**Schemas:** SoftwareApplication + WebPage + BreadcrumbList

These schemas are auto-generated by the plugin detail page template (`src/pages/plugins/[...slug].astro`). No manual implementation is needed when creating new plugin pages. Documented here for audit reference.

```javascript
const softwareSchema = {
  "@context": "https://schema.org",
  "@type": "SoftwareApplication",
  "name": plugin.data.title,
  "alternateName": `${plugin.data.title} Plugin`,
  "description": plugin.data.description,
  "applicationCategory": "BusinessApplication",
  "applicationSubCategory": "Marketing",
  "operatingSystem": "Claude Cowork",
  "softwareRequirements": plugin.data.compatibilityNote,
  "featureList": plugin.data.skillsList,     // comma-separated skills
  "keywords": "Claude Cowork plugin, AI marketing, ...",
  "inLanguage": "en",
  "author": ORG,
  "provider": ORG,
  "softwareVersion": plugin.data.version,
  "downloadUrl": plugin.data.downloadUrl,
  "offers": {
    "@type": "Offer",
    "price": "0",
    "priceCurrency": "USD",
    "availability": "https://schema.org/InStock"
  },
  "url": `https://theclick.ai/plugins/${plugin.id}`
};

const webPageSchema = {
  "@context": "https://schema.org",
  "@type": "WebPage",
  "name": plugin.data.title,
  "description": plugin.data.description,
  "url": `https://theclick.ai/plugins/${plugin.id}`,
  "isPartOf": {
    "@type": "WebSite",
    "name": "theCLICK",
    "url": "https://theclick.ai"
  },
  "mainEntity": softwareSchema,
  "inLanguage": "en"
};

// BreadcrumbList: Home > Plugins > {Plugin Title}
// "Plugins" links to /claude-cowork-plugins (the listing page URL)
```

**Notes:**
- The `featureList` property is populated from `skillsList` (comma-separated string in frontmatter).
- `offers.price` is "0" for free plugins. Always include `"availability": "https://schema.org/InStock"` on free plugins. Use `"https://schema.org/LimitedAvailability"` for pro-only plugins.
- `titleTag` in the .mdoc frontmatter controls the `<title>` tag. If not set, it falls back to `plugin.data.title`. Every plugin should have an explicit `titleTag`. Never include `" | theCLICK"` in the titleTag value. Keep the rendered title (titleTag + 12 char suffix) under 62 characters.
- The `description` frontmatter field serves as both the meta description and the schema description. Keep it 140-160 characters with the primary keyword.
- `mainEntity` in the WebPage schema must reference the full `softwareSchema` object, not a stub. This tells search engines the plugin is the primary entity on the page.
- **Breadcrumb parent is dynamic:** Industry quick start plugins (`growth-os-*` except `growth-os-quickstart`) use "Quick Start Plugins" → `/claude-cowork-quick-start-plugins` as their parent breadcrumb. All other plugins use "Plugins" → `/claude-cowork-plugins`.

---

## Plugin Listing Page

**Use for:** `/claude-cowork-plugins`, `/claude-cowork-quick-start-plugins`

**Schemas:** ItemList + CollectionPage + BreadcrumbList

```javascript
const itemListSchema = {
  "@context": "https://schema.org",
  "@type": "ItemList",
  "name": "AI Marketing Plugins",
  "description": "Ready-made AI marketing tools, templates, and workflows.",
  "url": "https://theclick.ai/claude-cowork-plugins",
  "numberOfItems": availablePlugins.length,
  "itemListElement": availablePlugins.map((plugin, i) => ({
    "@type": "ListItem",
    "position": i + 1,
    "name": plugin.title,
    "url": `https://theclick.ai/plugins/${plugin.slug}`
  }))
};
```

**Notes:**
- The ItemList must include **all non-retired plugins**, not just featured/displayed ones. This gives search engines the complete catalog.
- The main index at `/claude-cowork-plugins` lists all plugin types. The quick start index at `/claude-cowork-quick-start-plugins` lists only industry verticals.
- Both listing pages also include a CollectionPage schema with `provider` set to the theCLICK Organization.

---

## Good Example: Custom Claude Plugins Page

This is the first page optimized with this skill. Use it as a reference for quality and completeness.

**File:** `website/src/pages/custom-claude-plugins.astro`

**What was applied:**
- Title: `"Custom AI Marketing Plugins for Claude Cowork"` (46 chars + 12 suffix = 58 total)
- Description: `"Get a custom Claude Cowork plugin built for your business. We configure your AI marketing agent with your brand voice, workflows, and tool integrations. Fully built, tested, and delivered in 2-3 weeks."` (197 chars, slightly long but benefit-rich)
- Schemas: Service (with OfferCatalog of 7 deliverables, $5,000 Offer, Person provider) + FAQPage (6 questions) + BreadcrumbList (Home > Custom AI Marketing Plugins)
- All three schemas defined as frontmatter objects and injected via `set:html={JSON.stringify()}`

---

## Learned Preferences

- Plugin WebPage `mainEntity` must reference the full `softwareSchema` object, not a minimal stub with just name and URL. (Caught 2026-03-16.)
- Free plugin offers must include `"availability": "https://schema.org/InStock"`. Without it, search engines may not display the offer. (Caught 2026-03-16.)
- Plugin breadcrumbs must use the correct parent page. Industry quick starts point to `/claude-cowork-quick-start-plugins`. All others point to `/claude-cowork-plugins`. (Caught 2026-03-16: all plugins pointed to quick start.)
- Plugin listing ItemList should include all non-retired plugins, not just the featured subset displayed on the page. (Caught 2026-03-16: main index only listed 3 of 15 plugins.)
