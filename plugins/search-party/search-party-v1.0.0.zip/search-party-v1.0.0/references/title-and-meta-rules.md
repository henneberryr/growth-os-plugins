# Title Tag and Meta Description Rules

Rules, formulas, and examples for writing optimized title tags and meta descriptions on theclick.ai.

---

## Title Tag Rules

### How BaseLayout Works

`website/src/layouts/BaseLayout.astro` renders titles as:

```html
<title>{title} | theCLICK</title>
```

The `" | theCLICK"` suffix (12 characters) is added automatically. **Never include it in the title prop.** Doing so produces a double suffix: `"Page Name | theCLICK | theCLICK"`.

### Character Limits

| Component | Target | Max |
|-----------|--------|-----|
| Title prop (what you write) | 40-48 characters | 50 characters |
| Rendered title (with suffix) | 52-60 characters | 62 characters |

Google truncates titles around 60 characters. Staying under 62 total (50 + 12 suffix) keeps the full title visible in search results.

### Keyword Placement

Front-load the most important keywords. Search engines and AI systems weight the first words most heavily.

**Good:** `Custom AI Marketing Plugins for Claude Cowork`
**Bad:** `theCLICK's Service for Building Custom Plugins`

### Formulas

Use one of these patterns depending on the page type:

| Page Type | Formula | Example |
|-----------|---------|---------|
| Sales/service | `{Primary Keyword} for {Audience/Platform}` | `Custom AI Marketing Plugins for Claude Cowork` |
| Training/course | `{Course Name}: {Benefit}` | `Claude Cowork Quick Start: Build Your First AI Workflows` |
| Homepage | `{Brand} with {Product}: {Value Prop}` | `theCLICK Pro with Growth OS for Claude Cowork` |
| Blog post | `{Topic}: {Specific Angle or Promise}` | `AI Marketing Workflows: 5 You Can Build This Week` |
| About | `About {Person/Brand}` | `About Russ Henneberry` |
| Listing | `{Category}: {What They Are}` | `AI Marketing Plugins: Ready-Made Tools and Workflows` |
| Plugin detail | `{Plugin Name}: {Benefit or Category}` | `Newsboy: Newsletter Plugin for Claude Cowork` |

### Title Case

All title tags use **title case**. Capitalize every word except small prepositions and conjunctions:

**Lowercase these words** (unless they're the first word): a, an, the, and, but, or, nor, for, in, on, at, to, of, by, vs

**Always keep uppercase:** Acronyms of 2+ characters: AI, SOP, WCAG, AEO, SEO, GEO, CTA, HTML, CSS

**Examples:**
- `AI Brand Voice Generator vs Humanize AI Content: AI Plugin Showdown`
- `Custom AI Marketing Plugins for Claude Cowork`
- `Best AI Marketing Plugins 2026: 16 Tools Compared in a Bracket Tournament`
- `How to Start a Newsletter and Get Your First 50 Subscribers`

### Rules

1. Every page must have a unique title. No two pages share the same title prop.
2. Include the primary keyword the page should rank for. Keywords are chosen through the keyword research process in `reference/keyword-research.md`, not guessed.
3. Avoid filler words like "best", "top", "ultimate" unless they genuinely apply.
4. All titles use title case (see above).
5. No em dashes in titles. Use colons or pipes if you need a separator.
6. For AI discoverability, include specific, declarative phrases that answer what the page is about.

---

## Meta Description Rules

### Character Limits

| Target | Max |
|--------|-----|
| 140-155 characters | 160 characters |

Google truncates descriptions around 155-160 characters. Aim for the sweet spot of 140-155.

### Structure

A good meta description has three parts:

1. **What it is** (the offer or content)
2. **Who it's for** (the audience)
3. **A concrete detail** (timeframe, price, specific outcome, or proof point)

### Formula

```
{What you get}. {How it works or who it's for}. {Concrete detail: timeframe, price, result}.
```

### Examples

**Good:**
> Get a custom Claude Cowork plugin built for your business. We configure your AI marketing agent with your brand voice, workflows, and tool integrations. Fully built, tested, and delivered in 2-3 weeks.

Why it works: States the offer, describes what's included, gives a concrete timeframe.

**Bad:**
> We offer AI marketing services to help your business grow. Contact us to learn more about our solutions.

Why it fails: Generic, no specifics, no reason to click, could be any company.

### Rules

1. Every page must have a unique meta description. No two pages share the same description.
2. Include the page's primary keyword naturally.
3. Write in active voice. Address the reader directly when possible ("Get a custom...", "Learn how to...").
4. Include at least one concrete detail: a number, a timeframe, a price, or a specific outcome.
5. No em dashes. Use periods, commas, or colons.
6. Don't start with the brand name. Lead with the value.
7. End with a complete thought. No trailing ellipses or cut-off sentences.
8. For AI discoverability, write descriptions that directly answer the question "What does this page offer?" in a way that an AI system could extract and cite.

---

## OG and Twitter Meta

BaseLayout handles these automatically from the title and description props:

```html
<meta property="og:title" content="{title} | theCLICK" />
<meta property="og:description" content="{description}" />
<meta name="twitter:title" content="{title} | theCLICK" />
<meta name="twitter:description" content="{description}" />
```

The only thing to add manually is an OG image if the page has a hero image or social preview graphic. Pass it via the `image` prop on BaseLayout:

```astro
<BaseLayout title="..." description="..." image="https://theclick.ai/images/og/page-preview.jpg">
```

---

## Plugin Page Rules

Plugin detail pages set their title via the `titleTag` field in the `.mdoc` frontmatter. If `titleTag` is not set, the template falls back to the `title` field.

**Every plugin `.mdoc` file must have a `titleTag` field.** Without it, the rendered title may exceed character limits.

**Never include `" | theCLICK"` in the `titleTag` value.** BaseLayout appends it automatically. Including it produces a double suffix: `"Plugin Name | theCLICK | theCLICK"`.

**Plugin titleTag formula:** `{Plugin Name}: {Benefit or Category for Claude Cowork}`

Examples:
- `'Claude Cowork Plugin for SaaS Marketing'` (40 chars, rendered 52)
- `'Newsboy: Newsletter Plugin for Claude Cowork'` (45 chars, rendered 57)
- `'Plugin Coach: From Blank Page to Plugin Spec'` (45 chars, rendered 57)

**Plugin description** serves as both the meta description and the schema description. Keep it 140-160 characters with the primary keyword and at least one concrete detail (timeframe, number, specific outcome).

---

## Good Examples

| Page | Title Prop | Chars | Rendered |
|------|-----------|-------|----------|
| Custom Plugins | `Custom AI Marketing Plugins for Claude Cowork` | 46 | `Custom AI Marketing Plugins for Claude Cowork \| theCLICK` (58) |
| For Teams | `AI Training for Marketing Teams` | 31 | `AI Training for Marketing Teams \| theCLICK` (43) |
| Plugin Index | `Claude Cowork Plugins for AI Marketing` | 39 | `Claude Cowork Plugins for AI Marketing \| theCLICK` (51) |
| Quick Start Index | `Industry Quick Start Plugins for Claude Cowork` | 47 | `Industry Quick Start Plugins for Claude Cowork \| theCLICK` (59) |
| Plugin Detail | `Claude Cowork Plugin for SaaS Marketing` | 40 | `Claude Cowork Plugin for SaaS Marketing \| theCLICK` (52) |

---

## Learned Preferences

- Plugin titleTag fields must never contain `" | theCLICK"`. BaseLayout adds the suffix automatically. (Caught 2026-03-16: 9 plugin files had double suffix.)
- Plugin descriptions that are too short (under 140 chars) get ignored by search engines. Always include a concrete detail like a timeframe or number. (Caught 2026-03-16: healthcare plugin was 107 chars.)
- All title tags must use title case. Russ flagged lowercase keywords in titles as unprofessional. (Caught 2026-03-26: contest matchup titles like "AI SOP generator vs project handoff template" should be "AI SOP Generator vs Project Handoff Template".)
- Never use branded/internal names as keywords in title tags. "AI Marketing Madness" has zero external search volume. Target the problem each page solves (e.g., "AI Brand Voice Generator" instead of "Brand Voice vs Brand Polish"). (Caught 2026-03-26: all 8 contest matchup pages had branded titles instead of keyword-driven titles.)
