# Keyword Research Methodology

How to choose the right primary and secondary keywords for any page on theclick.ai.

---

## The Core Problem

Branded terms and internal project names (e.g., "AI Marketing Madness", "Growth OS Quick Start") are not search phrases. Nobody types them into Google. Every page needs to target keywords that real people actually search for when they have the problem that page solves.

---

## Step-by-Step Process

### 1. Define the Page's Job

Before searching for anything, answer this question in one sentence:

> "A person would land on this page because they want to ______."

Examples:
- "...build a brand voice using AI"
- "...find out if their business is visible to AI search tools"
- "...create a monthly Facebook content calendar without doing it manually"
- "...learn how to price their freelance services"

This sentence is your keyword seed. The key nouns and verbs in it are what you'll research.

### 2. Search for How People Phrase the Problem

Run 2-3 WebSearch queries based on the seed. Look for:

- **Tool/solution queries:** "AI brand voice generator", "website accessibility audit tool"
- **How-to queries:** "how to start a newsletter", "how to qualify leads"
- **Comparison queries:** "best AI SEO tools", "ChatGPT vs Claude for marketing"
- **Problem queries:** "my emails sound robotic", "is my business visible to AI"

For each search, note:
- What terms appear in the top 5 results' title tags
- What "People also ask" questions show up
- What tool names or category names keep recurring
- What language competitors use in their H1s and meta descriptions

### 3. Evaluate Candidates

For each keyword candidate, check:

| Criteria | Good Sign | Bad Sign |
|----------|-----------|----------|
| **Intent match** | Someone searching this would want what our page offers | They'd want something different (wrong intent) |
| **Specificity** | Narrow enough to rank for (not "marketing") | So broad it's unrealistic ("AI tools") |
| **Competition signal** | Multiple dedicated tools/pages target this term | No one targets it (might mean no demand) |
| **Natural fit** | Can appear in a title tag without sounding forced | Requires awkward phrasing to include |

### 4. Select Primary and Secondary Keywords

- **Primary keyword:** The highest-intent, best-fit phrase. Goes in the title tag (first half), H1, and meta description.
- **Secondary keyword:** An alternative phrasing or related query. Goes in the meta description, subheadings, and body content.

### 5. Present for Approval

Show the user:
- Primary keyword and why you chose it
- Secondary keyword and why you chose it
- 1-2 alternatives you considered and why you passed on them

Wait for approval before writing any title tags or meta descriptions.

---

## Keyword Patterns by Page Type

| Page Type | Keyword Pattern | Example |
|-----------|----------------|---------|
| Sales/service | `{what you get} + {for whom}` | "custom AI marketing plugins for Claude Cowork" |
| Article | `{question or problem} + {specific angle}` | "which AI tool should I be using" |
| Training | `{skill or tool name} + {for whom}` | "Claude Cowork tutorial for marketers" |
| Plugin detail | `{what it does} + {tool category}` | "AI newsletter builder plugin" |
| Contest matchup | `{problem keyword A} vs {problem keyword B}` | "AI SOP generator vs project handoff template" |
| Listing/index | `best {category}` or `{category}: {what they are}` | "best AI marketing plugins 2026" |

---

## Common Mistakes

1. **Using internal names as keywords.** "Growth OS Quick Start" means nothing to a searcher. Use "AI marketing setup guide" instead.
2. **Targeting branded terms only.** "theCLICK Pro" has zero search volume from non-customers. Layer in a problem keyword.
3. **Skipping research and guessing.** "This sounds like what people would search" is not keyword research. Run the searches. Look at what actually ranks.
4. **Choosing overly broad terms.** "AI marketing" is too competitive. "AI brand voice generator" is specific enough to rank.
5. **Forcing keywords that don't fit.** If the keyword requires rewriting the page's purpose to match, it's the wrong keyword. Pick one that matches the page's actual content.

---

## Tools Available

- **WebSearch:** Primary research tool. Search for candidate terms and analyze what ranks.
- **Competitor title analysis:** Look at what the top 5 results use in their `<title>` tags for your target query.
- **"People also ask" mining:** Google's PAA box reveals related queries with real demand.
- **SERP feature analysis:** If a query triggers AI Overviews, featured snippets, or video carousels, that signals both demand and the type of content Google wants.

---

## Learned Examples

| Page | Bad Keyword (what we tried) | Good Keyword (what we switched to) | Why |
|------|-----------------------------|-------------------------------------|-----|
| Contest matchup 1 | "Brand Voice vs Brand Polish" | "AI Brand Voice Generator vs Humanize AI Content" | The old title was a creative headline. The new one targets actual search terms. |
| Contest index | "AI Marketing Madness 2026" | "Best AI Marketing Plugins 2026" | Nobody searches for the contest name. They search for the category. |

Add new examples here as corrections are made.
