---
name: content-engine-ship
description: >
  This skill should be used when the user wants to "ship a piece", "finalize
  this for publishing", "mark something shipped", "what's ready to ship", or
  runs the /content-ship command. It takes a reviewed draft, finalizes it for
  its channel, optionally drops a draft into a connected destination, marks it
  shipped in the pipeline, and posts a digest notice if enabled.
version: 1.0.0
---

# Content Engine — Ship

The last verb. Take a draft the user has reviewed and get it out the door: finalize it for its channel, deliver it where they publish, and mark it shipped so the pipeline reflects reality.

Shipping is mostly mechanical, so stay light. The one place judgment matters: confirm a piece is truly final before it goes anywhere external, because sending is hard to take back.

**Read first:**
- `${CLAUDE_PLUGIN_ROOT}/references/extensions-playbook.md` (how `ship-helpers` and `slack-digest` behave and degrade)
- `${CLAUDE_PLUGIN_ROOT}/references/channel-formats.md` (the paste-ready shape per channel)

---

## Step 0 — Preflight

1. Glob `**/content-engine/config.json`. Missing → "Content Engine is not set up yet. Run `/content-setup` first." Stop.
2. Read the pipeline. Find every idea with an `outputs` entry at status `done` (drafted and reviewed, not yet shipped). These are shippable.
3. If none are `done`, say: "Nothing is ready to ship yet. Draft something in `/content-queue` first." Stop.

## Step 1 — Show what's ready

```
Ready to ship:
  1. [title] - [channel]   (drafted [date])
  2. [title] - [channel]
```

Let the user pick one, several, or "ship all ready." Also handle a direct request like "mark [slug] shipped" (jump to Step 4 for that piece, the lightweight path).

## Step 2 — Finalize

For the chosen output, read its `outputPath` file. Do a final pass for the channel per `channel-formats.md`:
- **LinkedIn:** produce the clean, paste-ready text block. Confirm the image or image brief exists if `linkedin-images` was used.
- **Article:** confirm the Markdown is clean, the sources are listed, and links resolve.

Show the final version. Ask: "This is the version that goes live. Ship it?" Confirm before doing anything external.

## Step 3 — Route to a destination (if `ship-helpers` is enabled)

Per the extensions playbook:
- If a destination connector is available (Notion, Gmail, Drive, etc.): offer to create a **draft** there for the human to publish. Confirm before sending. Never auto-publish live.
- If no connector: the finalized local file is the deliverable. Tell the user it is ready to paste or upload where they publish (LinkedIn has no Cowork auto-post, so LinkedIn always ends as paste-ready text plus image).

If `ship-helpers` is off, the finalized local file is the deliverable. That is fine.

## Step 4 — Mark shipped

Update the idea's pipeline JSON:
- Set the shipped output's `status` to `shipped`.
- If every output on the idea is now `shipped`, set the idea's top-level `status` to `shipped`.
- Write it back.

## Step 5 — Digest (if `slack-digest` is enabled)

If `slack-digest` is on and the Slack connector is available, post a one-line "shipped: [title]" notice to the configured channel. If the connector is off, skip with a note. Never fail the ship over the digest.

## Step 6 — Report

```
Shipped: [title] ([channel])
Delivered: [paste-ready file | draft created in [destination] | both]
Pipeline: [output marked shipped | idea fully shipped]

[If more drafts are ready:] [N] more ready to ship. Want the next one?
```

---

## Rules

- No config → `/content-setup`. Nothing `done` → `/content-queue`. Never fake upstream work.
- Confirm "this is final" before anything goes to an external destination. Sending is hard to reverse.
- Never auto-publish live. External pushes are drafts the human sends.
- Extensions degrade gracefully (see the playbook). A missing connector skips that step, it never blocks the ship.
- Updates only the idea's pipeline JSON and writes finalized output files. Does not touch `core/`.
- No politics. No em dashes, no "not X, it's Y", no shame hooks.
