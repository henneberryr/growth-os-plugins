---
name: content-engine-queue
description: >
  This skill should be used when the user wants to "review content ideas",
  "what's in the queue", "let's work on content", "draft something", or runs
  the /content-queue command. It shows the scored ideas in the pipeline, lets
  the user approve or reject them, and routes the chosen idea to the right
  channel drafter. This is where review and approval happen (there is no
  dashboard).
version: 1.0.0
---

# Content Engine — Queue

Show the ideas the scan found, let the user decide what is worth their time, and hand the chosen one to the right drafter. This is the human-in-the-loop hinge of the whole engine: the scan proposes, the user disposes, the drafters execute.

Approval lives here. There is no web dashboard. The user reviews in conversation and you update the pipeline JSON.

---

## Step 0 — Preflight

1. Glob `**/content-engine/config.json`. If missing → "Content Engine is not set up yet. Run `/content-setup` first." Stop.
2. Read all `content-engine/pipeline/*.json`. If there are none, say: "Your pipeline is empty. Run `/content-scan` to go find ideas." Stop.

## Step 1 — Build the queue

Sort `content-idea` entries into three groups:

- **Needs review** — `status: new`. The user approves or rejects these.
- **Ready to draft** — `status: approved` with an `outputs` entry still `pending`, or `approved` with no outputs yet.
- **In progress** — `status: in-production` with a `pending` or `in-progress` output (resume points).

Within each group, sort by `signalScore` descending. Also note any `proof` entries (held proof points) and `signal` entries briefly, but the focus is content-ideas.

## Step 2 — Present the queue

The decision happens on the **needs-review** ideas, so give the user enough to decide. Render those as full detailed cards per `${CLAUDE_PLUGIN_ROOT}/references/review-format.md` (summary, angle, why-it-matters, suggested angles, key facts, linked sources). Number them so the user can pick.

Items the user already decided on stay brief:

```
Content Queue: [date]

== NEEDS REVIEW ([n]) ==
[full detailed card for idea 1, numbered]
[full detailed card for idea 2, numbered]
...

== READY TO DRAFT ([n]) ==
  [n]. [title] - [channels pending]

== IN PROGRESS ([n]) ==
  [n]. [title] - [channel] (resume)

Proof on hand: [count] · Signals logged: [count]
```

If a same-day scan report exists at `content-engine/reports/scan-report-[today].md`, mention it: "Full report: content-engine/reports/scan-report-[today].md." If everything is empty, point them to `/content-scan`.

## Step 3 — Review and approve (the checkpoint)

This is where the user's judgment decides what gets made. Keep it fast.

- Let the user act by number or name: "draft 1", "approve 1 and 2", "reject 3", "tell me more about 2".
- **Approving** an idea sets its `status` to `approved`. **Rejecting** sets `status` to `rejected` (write it back; it stays out of future queues).
- Picking an idea to draft counts as approving it. You do not need a separate approve step before drafting.
- If you notice a pattern worth keeping (the user keeps rejecting a certain source or topic), offer once to record it: "Want me to tell the engine to stop surfacing [X]?" If yes, update `content-engine/config.json`. Do not nag.

## Step 4 — Choose the channel

Once the user picks an idea to draft:

- If the idea suggests one channel, use it.
- If it suggests multiple (or none), ask with `AskUserQuestion`: LinkedIn post, Article, or both. If both, draft one first, then offer the second.
- Only `linkedin` and `article` are live in this version. If the user asks for a channel that is not built yet, say so and offer the live ones.

## Step 5 — Route to the drafter

Hand off to the matching skill with the idea's full context:
- LinkedIn → run `${CLAUDE_PLUGIN_ROOT}/skills/draft-linkedin/SKILL.md`
- Article → run `${CLAUDE_PLUGIN_ROOT}/skills/draft-article/SKILL.md`

The drafter handles the writing, the review loop, saving, and updating the idea's `outputs`. When it returns, you do not need to re-update the pipeline; the drafter already did.

## Step 6 — Offer the next move

After a draft is done, offer the obvious next step: draft the idea's other channel, draft the next idea in the queue, or stop. One suggestion, not a list. Let the user decide.

---

## Rules

- No config → send to `/content-setup`. Empty pipeline → send to `/content-scan`. Never fake upstream work.
- Approval and rejection happen here, in conversation, and get written back to the pipeline JSON. There is no dashboard.
- Present ideas strongest-first so the user spends time on the best ones.
- Route to the drafter; let it do the writing. Do not draft inside this skill.
- Capture durable preferences (rejected sources/topics) to `config.json` only when the user agrees. Do not build a task tracker here; the pipeline JSON is the record.
- No politics. No em dashes, no "not X, it's Y", no shame hooks in anything you write.
