---
name: content-engine-draft-article
description: >
  This skill should be used when the user wants to "draft an article", "write
  the article from this idea", "write a blog post", or when /content-queue
  routes a content-idea to the article channel. It reads the idea plus the
  workspace voice and audience, outlines, drafts a long-form article in the
  brand voice, takes the user's edits, saves plain Markdown, and updates the
  pipeline.
version: 1.0.0
---

# Content Engine — Draft Article

Turn an approved content-idea into a long-form article that sounds like this business. Claude already knows how to write a great article. Your job is to write *this* one: ground it in the idea's angle and sources, write in the brand voice, structure it for this audience, and bring the human in at the outline and the draft.

**Read first:**
- the pipeline entry for this idea (`angle`, `summary`, `painPoints`, `keyFacts`, `tier1Sources`, `source`, `notes`)
- **if `notes` links an interview brief** (`INTERVIEW BRIEF: ...`), read it and build the article around the user's verbatim quotes, stories, and frameworks. That material is what makes the piece theirs and not generic.
- `core/persona.md` and `core/brand-voice.md`
- `${CLAUDE_PLUGIN_ROOT}/references/channel-formats.md` (article shape)

If invoked directly without an idea, ask which pipeline idea to use, or accept a topic.

---

## Step 1 — Outline (the first checkpoint)

Propose a short outline: the working title, the opening angle, and the sections with one line each on what they cover. Where the idea carries `tier1Sources`, note which section each source supports.

Present it and ask the user to react: add, cut, reorder, or change the emphasis. Do not draft the full piece until the outline is confirmed. This checkpoint is where the user's knowledge of their audience shapes the structure.

If the captured sources are thin and a section needs a fact you do not have, fetch the relevant `tier1Sources` URLs to pull specifics. Do not invent statistics, quotes, or names.

## Step 2 — Draft

Write the article per `channel-formats.md` in the brand voice. Earn the read with the opening, deliver the sections, link each external claim to its source, and close on the promise the hook made. Depth over padding.

Apply every hard rule from `core/brand-voice.md` plus the channel-formats fallbacks (no em dashes, no "not X, it's Y", no shame hooks, no politics, no fabricated facts).

## Step 3 — Review (the last mile)

Present the draft. Ask what to change. Revise and re-present until the user is satisfied. If they make a durable voice or structure correction, offer to save it to `core/brand-voice.md` so it persists.

## Step 4 — Save and update the pipeline

1. Save plain Markdown to `content-engine/outputs/articles/[idea-slug].md` with a small header:

   ```markdown
   # [Article title]

   **Idea:** [slug]
   **Channel:** Article
   **Drafted:** [YYYY-MM-DD]
   **Status:** ready for review

   ---

   [the article body in Markdown]

   ---

   ## Sources
   [list each tier-1 source with title and URL]
   ```

2. Update the pipeline JSON for this idea:
   - In `outputs`, find or add `{ "channel": "article", ... }` and set its `status` to `done` and `outputPath` to the saved file.
   - Set the entry's top-level `status` to `in-production` if it is not already `shipped`.

## Step 5 — Report

```
Article saved: content-engine/outputs/articles/[slug].md
Length: ~[N] words · Sources: [count]

Next: review and publish it, then say "mark [slug] shipped" when it's live.
Or run /content-queue to draft the next idea.
```

---

## Rules

- Reads the idea + `core/persona.md` + `core/brand-voice.md` every time. Never draft without the voice file.
- Confirm the outline before drafting the full piece. It is a real checkpoint.
- Never fabricate facts, stats, names, or quotes. Link claims to sources. Verify thin sources by fetching the captured URLs.
- Output is portable Markdown. No CMS-specific syntax. SEO machinery is a later add-on, not part of this draft.
- Writes only to `content-engine/outputs/articles/` and updates the idea's pipeline JSON. May append to `core/brand-voice.md` only when the user approves a captured preference.
- No em dashes, no "not X, it's Y", no shame hooks, no politics.
