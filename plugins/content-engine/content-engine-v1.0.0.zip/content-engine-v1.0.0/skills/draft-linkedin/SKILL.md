---
name: content-engine-draft-linkedin
description: >
  This skill should be used when the user wants to "draft a LinkedIn post",
  "write a LinkedIn post from this idea", or when /content-queue routes a
  content-idea to the LinkedIn channel. It reads the idea plus the workspace
  voice and audience, drafts a post in the brand voice, takes the user's edits,
  saves it, and updates the pipeline. Optionally generates an image.
version: 1.0.0
---

# Content Engine — Draft LinkedIn

Turn an approved content-idea into a LinkedIn post that sounds like this business. You are not learning to write LinkedIn posts; you already can. Your job is to write *this* business's post: pull the idea's angle and facts, apply the brand voice, hit the audience's real problem, and put the human in the loop where their judgment matters.

**Read first:**
- the pipeline entry for this idea (`angle`, `painPoints`, `keyFacts`, `tier1Sources`, `source`, `summary`, `notes`)
- **if `notes` links an interview brief** (`INTERVIEW BRIEF: ...`), read it and lead with the user's verbatim quotes. Their real words are the best hook material you have.
- `core/persona.md` (who this is for) and `core/brand-voice.md` (how this business sounds)
- `${CLAUDE_PLUGIN_ROOT}/references/channel-formats.md` (LinkedIn shape)

If invoked directly without an idea, ask which pipeline idea to use, or accept a topic the user types.

---

## Step 1 — Confirm the angle (quick checkpoint)

Show a tight plan and let the user steer before you write:

```
LinkedIn post
Idea:   [title]
Angle:  [angle]
Hits:   [pain points]
Source: [source]
```

Ask if the angle is right or if they want to push it a different direction. Lead with the angle as-is; let them react. Keep this to one exchange.

## Step 2 — Draft

Write the post per `channel-formats.md` (LinkedIn) in the brand voice. Use the idea's `keyFacts` for substance and reference `tier1Sources` if a claim needs backing. One insight, scroll-stopping first line, short paragraphs, generous white space.

Apply every hard rule from `core/brand-voice.md` and the channel-formats fallback rules (no em dashes, no "not X, it's Y", no shame hooks, no politics, no fabricated facts).

## Step 3 — Review (the last mile)

Show the full post formatted exactly as it will appear on LinkedIn. Ask: "Ready to save, or want changes?" Revise and re-show until the user is happy. This is where their judgment makes the post land. If they give a voice or style correction that is durable ("I never open with a question," "drop the emoji"), offer to save it to `core/brand-voice.md` so it sticks next time.

## Step 4 — Save and update the pipeline

1. Save to `content-engine/outputs/linkedin/[idea-slug].md`:

   ```markdown
   # [Idea title]

   **Idea:** [slug]
   **Channel:** LinkedIn
   **Drafted:** [YYYY-MM-DD]
   **Status:** ready for review

   ---

   [the post text, exactly as it should be pasted into LinkedIn]
   ```

2. Update the pipeline JSON for this idea:
   - In `outputs`, find or add `{ "channel": "linkedin", ... }` and set its `status` to `done` and `outputPath` to the saved file.
   - Set the entry's top-level `status` to `in-production` if it is not already `shipped`.

## Step 5 — Image (only if the `linkedin-images` extension is enabled)

Check `config.extensions` for `linkedin-images` with `enabled: true`.

- **If an image tool is available:** offer 2 to 3 styles with `AskUserQuestion` (for example: gradient quote card, clean quote card, simple concept sketch), generate the chosen one at 1:1, save it next to the post as `[idea-slug]-image.[ext]`, and open it for review.
- **If no image tool is connected (the Cowork default):** do not fail. Produce an **image brief** instead: the pull-quote or concept to illustrate, the suggested style, and the aspect ratio. Save it as `[idea-slug]-image-brief.md` so the user can generate it wherever they have a tool. Tell them how to enable an image tool to automate this.

If the extension is off, skip this step entirely.

## Step 6 — Report

```
LinkedIn post saved: content-engine/outputs/linkedin/[slug].md
[Image saved / Image brief saved / Image step skipped]

Next: review and post it, then say "mark [slug] shipped" when it's live.
Or run /content-queue to draft the next idea.
```

---

## Rules

- Reads the idea + `core/persona.md` + `core/brand-voice.md` every time. Never draft without the voice file.
- Always show the draft and take edits before saving. Never auto-save a final.
- Capture durable voice corrections back to `core/brand-voice.md` (prompted, with the user's OK).
- Connector and tool features (images) degrade gracefully. Never block on a missing tool.
- Writes only to `content-engine/outputs/linkedin/` and updates the idea's pipeline JSON. May append to `core/brand-voice.md` only when the user approves a captured preference.
- No em dashes, no "not X, it's Y", no shame hooks, no politics, no fabricated facts.
