---
name: content-engine-interview
description: >
  This skill should be used when the user wants to "interview me", "let's do an
  interview", "talk through [topic]", "extract my thoughts on [topic]", or runs
  the /content-interview command. It interviews the user to pull their real
  expertise, stories, and quotable lines into an Interview Brief that feeds the
  drafters. Enabled and surfaced by the interview-mode extension.
version: 1.0.0
---

# Content Engine — Interview

Interview the user to get their actual expertise, stories, and quotable lines onto the page, then save an Interview Brief the drafters can build from. This is the engine's secret weapon: most AI content is generic because it skips this step. The user knows things Claude cannot. Your job is to pull those out.

You already know how to run a good interview. The plugin's job here is orchestration: pick a worthwhile topic, brief the user so they answer from knowledge, keep the conversation one question at a time, capture their words verbatim, and link the result back to the pipeline.

**Read first:** `core/persona.md` (so questions connect to the audience), `core/brand-voice.md` (so you know what the output will serve), and `${CLAUDE_PLUGIN_ROOT}/references/interview-brief-template.md` (the output shape).

The user is the expert. You ask and listen. Do not inject your own opinions, frameworks, or takes into the interview. The entire point is to extract theirs.

---

## Step 1 — Pick the topic

**If the user named a topic or a pipeline idea** → use it. Match it to a pipeline entry by title keyword if you can. Go to Step 2.

**If the user said "interview me" with no topic** → offer a menu. Pull from two sources:
- **From the pipeline:** content-ideas with `status` new or approved and `signalScore` >= 6 (on the 1 to 10 scale), top 5 by score. Show title, angle, score.
- **Fresh (optional):** a light WebSearch on the `market.topicPillars` for 2 to 3 timely angles not already in the pipeline.

Present a numbered list (pipeline first, then fresh, then "something else"). Let the user pick a number or name their own. For a fresh pick, create a lightweight pipeline idea first (`bucket: content-idea`, `status: new`, the research summary in `notes`). For "something else," proceed freeform with no pipeline entry.

## Step 2 — Load context silently

Read the persona and voice. If a pipeline idea exists, read its `angle`, `painPoints`, `keyFacts`, `tier1Sources`, and `notes`. If the topic came from fresh research, fetch the primary source URL for depth. Do not narrate this.

## Step 3 — Brief the user, then begin

Before asking anything, give the user a short briefing so they react from a position of knowledge: a few sentences on the story or topic, the key facts you have, and why it matters to their audience (tie to specific persona pain points). If it helps and the topic is public, run a quick WebSearch for community sentiment and summarize the range of opinion. Then offer 2 to 3 angles.

Close the briefing with: "I'll ask you 5 to 7 questions. Say 'wrap it up' anytime and I'll stop and write the brief." Then ask the first question.

## Step 4 — Conduct the interview

One question at a time. Wait for each answer. After each:
- **Probe** if the answer has an unexplored story, a vague claim that could be made concrete, a framework named but not explained, or a strong opinion without the example. Max 2 probes per question, then advance.
- **Advance** when the answer is already concrete and complete.

Target 5 to 7 main questions. "Wrap it up" stops the interview immediately and jumps to Step 5.

A question skeleton to adapt (not a script): the core insight, why it matters now, a specific story where it played out, the contrarian take, the framework behind it, how it hits this audience specifically, and the first action someone should take. Open-ended only, never yes/no, never compound.

## Step 5 — Write the brief and review

Build the Interview Brief from `interview-brief-template.md`. Pull the Key Quotes verbatim from the transcript. Map the Audience Connection to named persona pain points. Present the full brief and ask: "Good to save, or want changes?" Revise until approved. Write it in neutral reference style, not the brand voice. No em dashes.

## Step 6 — Save and connect to the pipeline

1. Ensure `content-engine/outputs/interviews/` exists, then save to `content-engine/outputs/interviews/[slug].md`.
2. **If a pipeline idea exists:** append a line to its `notes`: `INTERVIEW BRIEF: content-engine/outputs/interviews/[slug].md`. Do NOT change the idea's `status` or `outputs`. The brief is input material; the queue still decides what to produce.
3. **If freeform (no idea):** ask whether to create a pipeline idea so it can be drafted. If yes, write a new content-idea with the brief linked in `notes` and a `signalScore` of 9 (the user chose to go deep on it). If no, leave the brief standalone.

## Step 7 — Report

```
Interview brief saved: content-engine/outputs/interviews/[slug].md
[Linked to pipeline idea [slug] | New pipeline idea created | Standalone]

Strong outputs from this: [the checked Suggested Outputs]

Want to draft one now? I'll take it to /content-queue with your words loaded in.
```

If the user wants to draft now, route to the queue (or directly to the matching drafter), which will read the brief from the idea's `notes`.

---

## Rules

- The user is the expert. Ask and listen. Never inject your own opinions or content into the interview.
- One question at a time. Never compound questions. Max 2 probes, then move on. "Wrap it up" always works.
- Key Quotes are verbatim. Do not rephrase the user's words.
- The brief is input material, written neutral, not in the brand voice. No em dashes.
- Do not auto-create a pipeline idea from a freeform interview without asking.
- Writes only to `content-engine/outputs/interviews/` and (with permission) appends to a pipeline idea's `notes` or creates one new idea. Does not touch `core/`.
- No politics.
