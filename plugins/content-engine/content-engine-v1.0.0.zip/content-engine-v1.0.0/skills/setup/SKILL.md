---
name: content-engine-setup
description: >
  This skill should be used when the user wants to "set up Content Engine",
  "configure Content Engine", "get started with Content Engine", "reconfigure
  my content engine", or runs the /content-setup command. It is the first mile:
  it learns the user's business, audience, and voice, then configures what the
  engine scans, which channels it drafts for, and which extensions are on.
  It produces core/persona.md, core/brand-voice.md, content-engine/config.json,
  and the pipeline scaffolding the other Content Engine skills read.
version: 1.0.0
---

# Content Engine — Setup (The First Mile)

Your job is to turn an empty plugin into a content operation tuned to this specific business. By the end, the workspace knows who the user serves, how they sound, and exactly what to scan, score, draft, and ship.

This is the most important skill in the plugin. Everything the engine does later reads the files you create here. If you do a thin job, every scan and every draft starts from a weaker place. Do it well and the very first scan feels like it was made for them.

**The principle:** You are not filling out a form. You are setting up a collaborator. Gather what Claude cannot infer (their offer, audience, voice, what they want watched), confirm what you can infer, and write it down so it compounds.

---

## How to run this (read before starting)

1. **Sell each step.** Before each part, say in one line what it unlocks. Not "let's pick sources" but "this decides what the engine watches for you every week."
2. **Be suggestive, not interrogative.** Lead with a recommendation drawn from what you already know, then let the user react. Never make them generate answers from a blank page.
3. **Confirm, don't assume.** After reading a website or existing files, present what you found and ask "right?" before building on it.
4. **One decision at a time.** Use `AskUserQuestion` for the structured choices. Use plain conversation for free-text (URL, samples, Slack channel names). Never dump every question at once.
5. **Reuse before you create.** If `core/persona.md` or `core/brand-voice.md` already exist, read and confirm them. Do not overwrite work another plugin or the user already did.
6. **Skip is OK.** Any optional step can be skipped. "Good enough" means move on.
7. **No em dashes. No "not X, it's Y" reframes. No shame hooks.** These are hard rules in everything you write.

The exact question wording and options for every `AskUserQuestion` step live in `${CLAUDE_PLUGIN_ROOT}/references/onboarding-questions.md`. Read that file before you begin and use it as the source of truth for options. The config you write must match `${CLAUDE_PLUGIN_ROOT}/references/config-schema.md`.

---

## Step 0 — Locate the workspace and detect existing context

Before asking anything, get your bearings silently. Do not narrate this.

1. **Find where files should live.** Use Glob to look for an existing structure:
   - `**/core/` → a Growth OS workspace. Shared static files (persona, voice, offer) go here.
   - `**/team/` or `**/workflows/` → place the `content-engine/` home folder inside it.
   - If none exist, create `core/` and `content-engine/` at the workspace root.

2. **Read what already exists.** Glob and read any of:
   - `**/core/persona.md`, `**/persona.md` — audience and pain points
   - `**/core/brand-voice.md`, `**/brand-voice*.md` — voice and tone
   - `**/core/offers.md`, `**/offer*.md` — what they sell
   - `**/CLAUDE.md` — workspace context and any business blueprint

   Whatever you find, you reuse. Extract the key facts and skip the questions those files already answer.

3. **Check for a prior Content Engine setup.** If `**/content-engine/config.json` exists, this is a reconfigure, not a fresh setup. Tell the user what is configured and ask (via `AskUserQuestion`) what they want to change. Run only the steps that choice needs. Never delete their pipeline.

---

## Step 1 — Welcome and ingest the business

**Sell it:** "I'm going to set up a content operation for your business. Give me about ten minutes and the engine will know who you serve, how you sound, and exactly what to watch for. Let's start with the basics."

1. If the user gave a URL or description as an argument, use it. Otherwise ask, in plain text: **"What's your business? Drop your website and I'll read it to get up to speed. No site is fine, just tell me what you do."**

2. **If a URL is provided, read it.** Use WebFetch on the homepage and one or two obvious pages (about, services, blog). Absorb: what they sell, who they serve, how they talk, proof, and any topics they already publish about. Do not narrate the crawl.

3. **If no site,** ask three quick free-text questions: what you sell, who you serve, what makes you different.

4. **Offer to read samples.** "Got anything you've written that sounds like you? A post, an email, a page. It helps me nail your voice." Read whatever they share.

---

## Step 2 — Confirm the audience (persona)

**Sell it:** "This is the lens the engine scores ideas through. An idea is worth writing when it hits a real problem your audience has."

**If `core/persona.md` already exists:** summarize it in two or three sentences and use `AskUserQuestion` to confirm: keep as is, refine, or replace. If they keep it, move on. Do not rewrite it.

**If it does not exist:** propose a persona from what you learned, then confirm.

1. Present the inferred audience: "Here's who I think you're for: [one-paragraph description]." Use `AskUserQuestion` to confirm or correct (see onboarding-questions.md, "Audience").
2. Capture their **pain points** as vivid, first-person problems (these are the scoring lens). Lead with 4 to 6 you inferred and let the user add or cut. Real human language, not marketing speak.
3. Write `core/persona.md` from the template at `${CLAUDE_PLUGIN_ROOT}/references/business-context-templates/persona-template.md`. Show a tight summary, never the full file.

---

## Step 3 — Capture the voice

**Sell it:** "After this, every draft sounds like you on a good day. Not a chatbot, not a textbook. You."

**If `core/brand-voice.md` already exists:** confirm it the same way (keep / refine / replace) and move on if kept.

**If it does not exist:**

1. If the user gave writing samples, analyze them for tone, sentence rhythm, vocabulary, humor, formality, and signature moves. If not, use `AskUserQuestion` to pick a starting voice (see onboarding-questions.md, "Voice").
2. **Voice test:** write two or three sentences about their business in the captured voice and ask "does this sound like you?" Adjust if not.
3. Capture any hard rules they state (words they hate, things they never do). These become voice rules.
4. Write `core/brand-voice.md` from `${CLAUDE_PLUGIN_ROOT}/references/business-context-templates/voice-template.md`. Show a short summary.

---

## Step 4 — What to scan (the core configuration)

**Sell it:** "This decides what the engine watches for you. Pick the sources where your best ideas actually come from."

1. Use `AskUserQuestion` (multi-select) with the "Scan sources" question from onboarding-questions.md. Options include industry news and trends, competitor content, community questions, your Slack workspace, and customer conversations.

2. **For each connector-based source they pick, follow up in plain conversation to capture the details the scan will need:**
   - **Slack:** "Which channels should I watch, and what should I look for in each (member wins, questions, content ideas)?" Capture channel names and a one-line focus per channel. Note: Slack scanning needs the Slack connector enabled in Cowork. If it is off, tell them the engine will skip Slack until they turn it on, and continue.
   - **Customer conversations (Gmail / Drive):** capture which mailbox or folder and what to look for. Same connector caveat.

3. **Always capture the market definition** (free text), because the web sources need it: "Who are two or three competitors, and what topics should the engine treat as your lane?" Store competitors and topic pillars in the config.

4. **Graceful degradation rule to record:** any source that needs a connector is marked `requires_connector` in the config. The scan runs the available sources and skips the rest with a note. It never fails because a connector is off.

---

## Step 5 — Channels and cadence

**Sell it:** "Now the output side. Which formats should it draft, and how often will you run it?"

1. Use `AskUserQuestion` for **channels** (onboarding-questions.md, "Channels"). In v1.0.0 the drafters are LinkedIn and articles; present those two and note newsletter and video are coming.
2. Use `AskUserQuestion` for **cadence** and **volume** (how often they will scan, how many ideas per scan).
3. Use `AskUserQuestion` for the **first-scan lookback** (onboarding-questions.md, "First scan lookback"): how far back the very first scan should reach, since the engine has no history yet. This sets the initial `lastScanDate`. After the first scan, every scan moves the window forward to "since last scan."

---

## Step 6 — Extensions (extend the engine)

**Sell it:** "Optional power-ups. Turn on what helps, skip the rest. You can change these anytime by running setup again."

Use `AskUserQuestion` (multi-select) with the "Extensions" question from onboarding-questions.md:
- **Interview mode** — Claude interviews you to pull your real expertise into a draft before writing.
- **Auto images for LinkedIn** — generate an image per post. Record that this needs an image tool connected; if none is, the engine produces an image brief instead.
- **Ship helpers** — publish-ready formatting and, if a connector exists, a draft to your email platform.
- **Slack digest** — post each scan summary to a Slack channel (needs the Slack connector).

For any extension that needs a connector or tool, mark it `requires_connector` in the config and tell the user what to enable. Never block on it.

---

## Step 7 — Write the configuration and scaffold the workspace

Create the engine's home. Use the chosen location from Step 0.

1. **Scaffold folders:**
   ```bash
   mkdir -p [base]/content-engine/pipeline [base]/content-engine/reports [base]/content-engine/outputs/linkedin [base]/content-engine/outputs/articles
   ```
   (`reports/` holds the human-readable scan digests; `pipeline/` holds the machine-readable JSON records.)

2. **Write `content-engine/config.json`** matching `${CLAUDE_PLUGIN_ROOT}/references/config-schema.md`. It records: persona and voice file paths, market definition (competitors, topic pillars), enabled sources with per-source detail, channels, cadence and volume, and enabled extensions. Mark connector-dependent items with `requires_connector`.

3. **Write `content-engine/last-scan.json`** with `lastScanDate` set to the first-scan lookback the user chose in Step 5 (7, 30, or 90 days before now) and an empty `sourcesScanned` array. This is the window for the very first scan. After that, each scan moves `lastScanDate` forward to its own run time, so ongoing windows are simply "since last scan."

4. **Leave a breadcrumb, do not build a task manager.** If a `CLAUDE.md` exists at the workspace root, add a short Content Engine note under any existing team or tools section: what the engine is, where its config and pipeline live, and the commands. If a "Passive Capture Rules" section exists, register these routing rules:
   - A scan-source or topic preference ("watch Reddit too", "stop surfacing competitor X") routes to `content-engine/config.json`.
   - A voice or style preference routes to `core/brand-voice.md`.
   - A new audience problem routes to `core/persona.md`.
   If no `CLAUDE.md` exists, skip this step quietly. Do not create workspace-wide files this plugin does not own.

---

## Step 8 — First experience of value

Setup has to end with the user seeing the point, not just a "done."

1. Show a tight summary of the configured engine:
   ```
   Content Engine is set up.

   Audience:   [one line]
   Voice:      [one line]
   Watching:   [list of enabled sources]
   Drafts:     [channels]
   Cadence:    [how often] · [volume] ideas per scan
   Extensions: [list, or "none yet"]
   ```

2. Bridge to the first real value: "Next, run `/content-scan` and I'll go watch those sources and bring back the ideas worth writing, scored so the best ones are on top." (In this build, `/content-scan` arrives in the next phase. If it is not yet installed, tell the user setup is complete and the scan command is coming.)

3. Remind them setup is re-runnable: "Run `/content-setup` anytime to add a source, flip on an extension, or refine your voice."

---

## What this skill creates

| File | Type | Purpose |
|------|------|---------|
| `core/persona.md` | static | Audience and pain points (the scoring lens). Reused if present. |
| `core/brand-voice.md` | static | Voice and tone for every draft. Reused if present. |
| `content-engine/config.json` | static | What to scan, channels, cadence, extensions. Edited by re-running setup. |
| `content-engine/pipeline/` | living | The idea inventory (machine-readable JSON). Grows every scan. |
| `content-engine/reports/` | living | Human-readable scan digests with detailed cards. What the user actually reads. |
| `content-engine/outputs/` | living | Drafted pieces by channel. |
| `content-engine/last-scan.json` | living | Scan window tracker. |

## Rules

- Reuse existing `core/` files. Never overwrite the user's or another plugin's work.
- Confirm inferences before building on them. The user reacts to proposals; they do not start from blank pages.
- Mark every connector-dependent source and extension as `requires_connector`. The engine degrades gracefully, it never blocks.
- Show summaries in chat, never paste full files.
- No em dashes, no "not X, it's Y" reframes, no shame hooks, no politics.
- This plugin only writes to `core/` (shared static context) and its own `content-engine/` folder, plus an optional note in an existing `CLAUDE.md`. It does not touch other plugins' files.
