---
name: content-engine-scan
description: >
  This skill should be used when the user wants to "scan for content", "run a
  content scan", "run the content engine", "find content ideas", "what should I
  write about", or runs the /content-scan command. It reads the Content Engine
  config, watches the user's configured sources for content-worthy signals,
  scores the ideas worth writing, and writes them to the pipeline. It does NOT
  draft anything; drafting happens in /content-queue.
version: 1.0.0
---

# Content Engine — Scan

Watch the user's configured sources, find the ideas worth writing, score them, and write them to the pipeline. This is the engine going out to look. It does not draft. It fills the pipeline so the user can review and draft in `/content-queue`.

Your job here is orchestration: read the config, run each source the way the playbook says, judge what you find against the persona and the rubric, dedup, and write clean JSON. Claude already knows how to read a webpage and judge relevance. The plugin's job is to point it at the right sources, the right lens, and the right output format.

**Read these references before scanning** (they are the source of truth):
- `${CLAUDE_PLUGIN_ROOT}/references/scan-source-playbook.md` — how to run each source
- `${CLAUDE_PLUGIN_ROOT}/references/scoring-rubric.md` — how to score and what to capture per idea
- `${CLAUDE_PLUGIN_ROOT}/references/pipeline-schema.md` — the JSON to write
- `${CLAUDE_PLUGIN_ROOT}/references/review-format.md` — the detailed cards and digest file to produce

---

## Step 0 — Preflight

1. **Find the config.** Glob `**/content-engine/config.json`. If it does not exist, stop and say: "Content Engine is not set up yet. Run `/content-setup` first so I know what to watch and who I am writing for." Do not guess at sources or audience. Do not fake the upstream setup.

2. **Read context.** Read `config.json`, the persona file at `config.personaPath`, and the voice file at `config.voicePath`. The persona's pain points are your scoring lens.

3. **Determine the scan window.** Read `content-engine/last-scan.json`. The window runs from `lastScanDate` to now. If the file is missing or malformed, default the start to 7 days ago. **The window is a hard boundary for time-sensitive material** (news, releases, announcements, anything with a publish date): if it was published before `lastScanDate`, it does not belong in this scan, no matter how relevant. Note the exact window dates (start and end) and apply them while gathering and while filtering. Evergreen, undated material (trends, how-tos, recurring questions) is handled separately in Step 2.

4. **Build the dedup index once.** Read every existing `content-engine/pipeline/*.json` and hold an in-memory index of `sourceId`, `title`, and `bucket`. Do not re-read these files per item. If the pipeline is empty, the index is empty.

5. **Set a `scanId`** (the current ISO timestamp). Every entry from this run shares it.

---

## Step 1 — Run each enabled source

From `config.sources`, take every entry where `enabled` is true. Run each one per the playbook.

- For sources with `requires_connector` set, attempt the source. If the connector is unavailable or the call errors, record `"[source] skipped (connector not available)"` and continue. Never abort the whole scan because one connector is off.
- Wrap each source independently. One source failing or returning nothing must not stop the others.
- Use the scan window, `market.topicPillars`, and `market.competitors` as inputs. **Scope every query to the window, not just the year.** Add recency terms (the current month, "this week", "past 7 days", or explicit dates from the window). Searching at the year level (`...2026`) pulls months-old material and is wrong.
- **Confirm the date of every time-sensitive finding before keeping it.** If a result's date is unclear, fetch the source to pin it down. Drop anything published before `lastScanDate`. Never let an undated news item through on a guess.

For each raw finding, capture: a title, a one or two sentence summary, the human-readable `source`, the `sourceId` (URL or permalink, the dedup key), and the **publish date** (or mark it undated/evergreen).

---

## Step 2 — Categorize, score, and enrich

For each finding:

1. **Bucket it** per `pipeline-schema.md`: `content-idea`, `proof`, or `signal`.
2. **Tag recency and apply the window gate:**
   - **Time-sensitive** (news, releases, announcements, anything with a publish date): it must be published inside the window. If it is older than `lastScanDate`, **discard it** here, even if it scores well on relevance. If it is in-window, set `recency` to `"fresh"`.
   - **Evergreen** (trends, how-tos, recurring community questions with no firm date): allowed, but set `recency` to `"evergreen"` and never present it as breaking news. Keep evergreen to at most half the kept ideas so a scan is not just timeless listicles.
3. **Score it** per `scoring-rubric.md` (content-idea and proof get a `signalScore` 1 to 10 and `signalNotes`, with audience relevance as the dominant axis). If the score lands at 1 or 2 and nothing is compelling, drop it. Quality over volume.
4. **Enrich content-ideas fully** per `scoring-rubric.md`. Every content-idea must carry enough for the user to decide without opening anything else: a real 2 to 4 sentence `summary`, the one-sentence `angle`, a `whyItMatters` line naming the persona pain point it hits, the `recency` tag, 2 to 3 `suggestedAngles`, 2+ `keyFacts`, and 2 to 3 `tier1Sources` with real URLs and dates (for external ideas). If you cannot gather at least a summary, a why-it-matters, and one source, the idea is not ready: drop it or downgrade it to a `signal`.
5. **Enrich proof:** write the `proofLine` and a `category` tag.

---

## Step 3 — Deduplicate

Before writing, check each survivor against the dedup index:

- **Same `sourceId`** as an existing entry → skip.
- **Same topic + same bucket** as an existing entry (even from a different source) → skip.
- When unsure, skip. A missed idea is caught next scan; a duplicate wastes review time.

A single source can legitimately produce entries in more than one bucket (a Slack thread might be both a `proof` and a `content-idea`). That is allowed.

---

## Step 4 — Write the pipeline

For each new entry, write `content-engine/pipeline/[YYYY-MM-DD]-[kebab-title].json` using the template in `pipeline-schema.md`. Set `status` to `new`, fill `dateFound` and `scanId`, and populate only the fields the bucket needs.

Respect the configured volume (`config.volume`): `focused` keeps the top 3 to 5 by score, `batch` keeps 6 to 10, `wide` keeps everything that cleared the quality bar.

---

## Step 5 — Update scan state

Overwrite `content-engine/last-scan.json`:

```json
{
  "lastScanDate": "[now, ISO]",
  "lastScanId": "[scanId]",
  "sourcesScanned": ["industry-news", "community", "..."],
  "note": "Found N content-ideas, M proof, K signals. Skipped: [any connector-skipped sources]."
}
```

---

## Step 6 — Write the digest, then present cards (the last mile)

The user decides what to build from this output, so give them enough to decide. Follow `review-format.md`.

1. **Write the digest file.** Build `content-engine/reports/scan-report-[YYYY-MM-DD].md` with a full detailed card for every idea (content-ideas sorted by score, then proof, then signals), plus the sources-run/skipped header. Create `content-engine/reports/` if it does not exist. If a report for today already exists, append under a `## Rescan [time]` heading rather than overwriting.

2. **Open it** so the user can read it outside chat: `open content-engine/reports/scan-report-[YYYY-MM-DD].md`.

3. **Present in chat.** Print the full content-idea cards (respect `config.volume`: `focused` shows the top 3 to 5, `batch` 6 to 10, `wide` all). Each card carries the summary, angle, why-it-matters, suggested angles, key facts, and linked sources per `review-format.md`. Summarize proof and signals as short counts with "see the report for detail," unless there are only a few.

4. Close with: "Saved and opened the full report. Run `/content-queue` to review and draft the ones you like."

Do not auto-draft. Reviewing and approving happens in `/content-queue`. Present, then stop.

**If the `slack-digest` extension is enabled** (and the Slack connector is available), also post this summary to the configured channel. If the connector is off, skip the digest with a note.

---

## Rules

- Never scan without a config. If setup has not run, send the user to `/content-setup`.
- Never let one source (especially a connector-based one) abort the scan. Skip and continue.
- The persona's pain points are the scoring lens. An idea is "worth writing" when it hits a real problem this audience has.
- **Respect the window.** Scope queries to it, and drop time-sensitive items published before `lastScanDate`. Stale news is not a low score, it is out. Evergreen items are allowed but tagged and capped.
- Quality over quantity. Three strong ideas beat ten weak ones. Respect the configured volume.
- Deduplicate against the existing pipeline. Never write the same `sourceId` twice.
- No politics, ever. Skip political topics entirely.
- No em dashes, no "not X, it's Y" reframes, no shame hooks in anything you write (angles, summaries, proof lines).
- This skill writes only to `content-engine/pipeline/`, `content-engine/reports/`, and `content-engine/last-scan.json`. It does not draft and does not touch `core/`.
- Every content-idea written to the pipeline must be reviewable on its own: real summary, why-it-matters, suggested angles, key facts, and linked sources. A bare one-liner is not acceptable output.
