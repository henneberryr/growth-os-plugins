# Content Engine v1.0.0

> Scans your market, scores the ideas worth writing, drafts across channels, and ships. The kind of output that used to take a team of writers, a strategist, and an editor.

Content Engine is a Claude Cowork **team member** for content. You install it once, set it up in one session, and it becomes a content operation tuned to your business: it watches your market for what's worth saying, ranks the ideas, drafts them in your voice, and gets them ready to ship.

It is not a generic AI writer. It learns your audience, your voice, and what *you* want it to watch, then puts Claude's writing ability to work inside that context.

---

## What it does

| Stage | What happens |
|-------|--------------|
| **Scan your market** | Watches the sources you choose for content-worthy signals: industry news, competitor moves, community questions, and (optionally) your own Slack and customer conversations. |
| **Score the ideas worth writing** | Ranks every idea so the best ones surface first, scored against your audience's real problems. |
| **Draft across channels** | Turns an approved idea into a LinkedIn post or a long-form article, written in your voice. |
| **Ship** | Finalizes the piece for publishing and keeps a record so nothing falls through the cracks. |

## Commands

| Command | Status | What it does |
|---------|--------|--------------|
| `/content-setup` | **Live** | The first mile. Interviews you, learns your business and voice, and configures what the engine scans. Run this first. |
| `/content-scan` | **Live** | Scans your configured sources, scores the ideas worth writing, and saves a readable report of detailed cards (with sources) so you can decide what to build. |
| `/content-queue` | **Live** | Shows the scored ideas, lets you approve or reject, and drafts the one you pick into a LinkedIn post or article in your voice. |
| `/content-interview` | **Live** | Interviews you on a topic to pull your real expertise into a brief the drafters write from. |
| `/content-ship` | **Live** | Finalizes a reviewed draft for publishing, optionally drafts it into a connected destination, and marks it shipped. |

Run `/content-setup` before anything else. Without setup, the engine has no context and the other commands will send you back here first.

## What setup creates in your workspace

```
content-engine/
├── config.json          what to scan, which channels, which extensions are on
├── pipeline/            one JSON file per idea (the machine-readable record)
├── reports/             readable scan digests with detailed cards (what you review)
├── outputs/
│   ├── linkedin/
│   └── articles/
└── last-scan.json       scan window tracker
```

You review ideas in the scan report (detailed cards), not raw JSON. The pipeline JSON is the system of record that tracks status and prevents duplicates behind the scenes.

Your audience and voice live in shared `core/` files (`core/persona.md`, `core/brand-voice.md`) so every Growth OS tool reads the same source of truth. If you already ran Growth OS Quick Start, Content Engine reuses those files instead of duplicating them. If you haven't, setup creates lightweight versions for you.

## Requirements

**Core engine:** Works with Claude Cowork's built-in tools only. No extra setup required.

**Optional connectors** (enable in Cowork → Connectors; the engine works without them and nudges you if one would help):

- **Slack** — to scan your Slack workspace for member wins, questions, and content ideas.
- **Gmail / Google Drive** — to scan customer conversations and notes (optional source).
- An **image tool** — to auto-generate images for LinkedIn posts. If none is connected, the engine delivers an image brief you can use anywhere.

## Claude Cowork compatibility

Built and verified against Claude Cowork's constraints:

- Uses only built-in tools for the core flow (file read/write, web search/fetch, `AskUserQuestion`).
- No custom MCP servers and no subagents (neither is supported in Cowork).
- Connector-based sources (Slack, Gmail) degrade gracefully: if the connector is off, that source is skipped and the rest of the scan runs.
- File access uses workspace-relative paths and `**/` lookups, compatible with Cowork's scoped folders.

---

## Version history

**v1.0.0** — First release. The full engine: scan, score, draft (LinkedIn + articles), interview, and ship, adapted to any business through guided onboarding.
- First mile: plugin scaffold + `/content-setup` onboarding (the `AskUserQuestion`-driven wizard that configures the engine, including what to scan with Slack as a source option).
- Scan: `/content-scan` watches the configured sources, scores ideas with the multi-factor rubric, and writes a readable report of detailed cards (summary, why your audience cares, suggested angles, key facts, and linked sources) so you can decide what to build. Connector sources degrade gracefully.
- Queue + drafting: `/content-queue` shows ideas needing review as full detail cards, then drafts the one you pick into a LinkedIn post or article in the brand voice. LinkedIn supports an optional image (or an image brief if no image tool is connected).
- Ship: `/content-ship` finalizes a reviewed draft, optionally drafts it into a connected destination, marks it shipped, and posts a digest. Extensions (`ship-helpers`, `slack-digest`, `linkedin-images`) degrade gracefully when a connector is missing.
- Interview: `/content-interview` pulls your real expertise, stories, and quotes into a brief, then the drafters write from your actual words instead of generic angles.
- Scan window: scans are time-boxed. Setup asks how far back the first scan should reach (7 / 30 / 90 days); after that each scan covers everything since the last one. Stale news outside the window is dropped, and undated evergreen ideas are labeled as such so they never pose as fresh.

## Roadmap

| Phase | Adds |
|-------|------|
| 0–1 ✅ | Scaffold + `/content-setup` onboarding |
| 2 ✅ | `/content-scan` + idea pipeline + scoring |
| 4 ✅ | `/content-queue` + LinkedIn & article drafters |
| 5 ✅ | `/content-ship` + optional extensions (images, Slack digest, ship-helpers) |
| 6 ✅ | `/content-interview` (expertise extraction) |
| 7 ✅ | Dogfooded on theCLICK; first release cut as v1.0.0 |
| later | SEO signal sources (search demand, keyword gaps) as an optional add-on |

Built by theCLICK.
