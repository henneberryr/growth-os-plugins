---
description: Set up Content Engine for your business, or reconfigure an existing setup
allowed-tools: Read, Write, Edit, Bash, Glob, Grep, WebSearch, WebFetch, AskUserQuestion
argument-hint: "[optional: your website URL or a one-line description of your business]"
---

Run the Content Engine setup (the first mile).

**First, detect existing state.** Use Glob to scan the user's workspace for Content Engine files:

- `**/content-engine/config.json`
- `**/content-engine/pipeline/`
- `**/core/persona.md` and `**/core/brand-voice.md` (shared Growth OS context)

Decide the entry point from what you find:

- **If `content-engine/config.json` exists** → setup is already complete. Read it and tell the user what's currently configured (sources, channels, extensions). Then ask, using `AskUserQuestion`, whether they want to **reconfigure** (re-run the relevant onboarding steps), **add a source** (e.g., turn on Slack), **toggle an extension**, or **leave it as is**. Only run the steps needed for their choice. Do not wipe their pipeline.

- **If no `config.json` exists** → this is a fresh install. Run the full onboarding.

**Then run the setup skill** at `${CLAUDE_PLUGIN_ROOT}/skills/setup/SKILL.md`. Follow it end to end.

If the user passed an argument (a URL or a business description), hand it to the skill as the starting point so it does not ask for what it already has.

The skill produces:
- `core/persona.md` and `core/brand-voice.md` (reused if they already exist, created if not)
- `content-engine/config.json` (sources, channels, extensions)
- the `content-engine/pipeline/` and `content-engine/outputs/` scaffolding
- `content-engine/last-scan.json`

When setup finishes, the engine is ready for `/content-scan`.
