---
description: Scan your configured sources for content ideas and score them into your pipeline
allowed-tools: Read, Write, Edit, Bash, Glob, Grep, WebSearch, WebFetch, AskUserQuestion
argument-hint: "[optional: a topic to focus this scan on]"
---

Run the Content Engine scan.

**First, confirm setup exists.** Use Glob to look for `**/content-engine/config.json`.

- **If it does not exist** → setup has not run. Tell the user: "Content Engine is not set up yet. Run `/content-setup` first so I know what to watch and who I am writing for." Stop. Do not invent sources or audience.

- **If it exists** → run the scan skill at `${CLAUDE_PLUGIN_ROOT}/skills/scan/SKILL.md`. Follow every step in order.

If the user passed an argument (a focus topic), bias this scan toward that topic: prioritize sources and queries related to it, but still respect the configured sources and scoring.

**Connectors:** sources that need a connector (Slack, Gmail) are attempted only if the connector is available. If one is off, the scan skips it with a note and runs the rest. The scan never fails because a connector is missing.

The scan writes scored ideas to `content-engine/pipeline/` (status `new`) and updates `content-engine/last-scan.json`. It does not draft anything. When it finishes, point the user to `/content-queue` to review and draft.
