---
description: Interview you to pull your real expertise into a content brief the drafters can use
allowed-tools: Read, Write, Edit, Bash, Glob, Grep, WebSearch, WebFetch, AskUserQuestion
argument-hint: "[optional: a topic, or a pipeline idea title]"
---

Run the Content Engine interview.

**First, confirm setup exists.** Use Glob for `**/content-engine/config.json`.

- If it does not exist → "Content Engine is not set up yet. Run `/content-setup` first so I know who your audience is." Stop.
- Otherwise → run the interview skill at `${CLAUDE_PLUGIN_ROOT}/skills/interview/SKILL.md`.

If the user passed a topic or pipeline idea as an argument, use it as the interview topic and skip the topic menu.

The interview pulls the user's actual expertise, stories, and quotable lines into an Interview Brief saved in `content-engine/outputs/interviews/`, then links it to the relevant pipeline idea so the drafters write from the user's real words instead of generic angles. The brief is input material, not a finished piece.
