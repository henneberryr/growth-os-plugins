---
description: Review the scored content ideas in your pipeline and draft the ones you pick
allowed-tools: Read, Write, Edit, Bash, Glob, Grep, WebSearch, WebFetch, AskUserQuestion
argument-hint: "[optional: an idea number or title to jump straight to drafting]"
---

Run the Content Engine queue.

**First, confirm state.** Use Glob:

- No `**/content-engine/config.json` → "Content Engine is not set up yet. Run `/content-setup` first." Stop.
- Config exists but `**/content-engine/pipeline/*.json` is empty → "Your pipeline is empty. Run `/content-scan` to find ideas." Stop.
- Otherwise → run the queue skill at `${CLAUDE_PLUGIN_ROOT}/skills/queue/SKILL.md`.

If the user passed an argument naming an idea, skip the list and go straight to drafting that idea (still confirm the channel).

The queue is where review and approval happen (there is no dashboard). It shows ideas strongest-first, lets the user approve or reject, then routes the chosen idea to the LinkedIn or article drafter, which writes in the business's voice and updates the pipeline.
