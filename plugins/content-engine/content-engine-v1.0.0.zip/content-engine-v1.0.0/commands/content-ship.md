---
description: Finalize a reviewed draft for publishing and mark it shipped
allowed-tools: Read, Write, Edit, Bash, Glob, Grep, WebSearch, WebFetch, AskUserQuestion
argument-hint: "[optional: an idea title or slug to ship]"
---

Run the Content Engine ship step.

**First, confirm state.** Use Glob:

- No `**/content-engine/config.json` → "Content Engine is not set up yet. Run `/content-setup` first." Stop.
- Config exists but no pipeline idea has an output at status `done` → "Nothing is ready to ship. Draft something in `/content-queue` first." Stop.
- Otherwise → run the ship skill at `${CLAUDE_PLUGIN_ROOT}/skills/ship/SKILL.md`.

If the user passed an argument naming an idea, ship that one directly (still confirm it is final before anything goes external).

Ship finalizes the reviewed draft for its channel, optionally drops a draft into a connected destination (only if the `ship-helpers` extension is on and a connector is available), marks the piece `shipped` in the pipeline, and posts a digest notice if `slack-digest` is on. It never auto-publishes live and never fails because a connector is missing.
