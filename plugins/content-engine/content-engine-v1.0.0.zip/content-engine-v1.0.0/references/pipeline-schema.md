# Pipeline Schema — One JSON File Per Idea

The scan writes each finding as a JSON file in `content-engine/pipeline/`. This is the engine's **living idea inventory**: it grows every scan, and the queue and draft skills read from it. Plain JSON in the workspace, no database, no CMS.

**Slug / filename:** `[YYYY-MM-DD]-[kebab-case-short-title].json` (e.g., `2026-05-25-ai-pricing-shift.json`).

---

## Buckets

Every entry has a `bucket`. It decides what happens to the idea later.

| Bucket | What qualifies | What happens to it |
|--------|----------------|--------------------|
| `content-idea` | A publishable angle worth writing. The main bucket. | Scored, reviewed in `/content-queue`, drafted into a LinkedIn post or article. |
| `proof` | A specific, attributable customer or member win (mostly from Slack or customer conversations). | Held as a proof point you can showcase. Not auto-drafted. |
| `signal` | A question, gap, or trend worth knowing but not directly draftable. | Logged so you see the pattern. No draft. |

## Status flow

```
new  ->  approved  ->  in-production  ->  shipped
   \-> rejected
```

- **new** — the scan found it. Waiting for review in `/content-queue`.
- **approved** — the user approved it for drafting (happens conversationally in `/content-queue`, since there is no dashboard).
- **in-production** — a draft has been started for at least one channel.
- **shipped** — the piece is finalized and published.
- **rejected** — not worth pursuing.

Review and approval happen in `/content-queue` (Cowork-native, conversational). There is no web dashboard.

---

## Fields

| Field | Type | Notes |
|-------|------|-------|
| `title` | string | Short, human-readable. `[topic] - [short description]`. |
| `bucket` | string | `content-idea`, `proof`, or `signal`. |
| `status` | string | See status flow. Scan always writes `new`. |
| `summary` | string | content-idea: a real 2 to 4 sentence summary of what surfaced, what is interesting, and what is at stake. Not a fragment. This is what the user reads to decide. Proof/signal: one or two sentences. |
| `angle` | string | content-idea only: the lead hook in one sentence. The draft starts here. |
| `whyItMatters` | string | content-idea only: one sentence tying the idea to a NAMED persona pain point and why it lands for the audience right now. Required on content-ideas. |
| `recency` | string | content-idea: `"fresh"` (time-sensitive, published inside the scan window) or `"evergreen"` (undated/timeless). Time-sensitive items published before the window are dropped, not stored. Drives the freshness score and the card label. |
| `painPoints` | string[] | Which persona pain points this hits (use the labels from `core/persona.md`). The scoring lens. |
| `suggestedAngles` | string[] | content-idea only: 2 to 3 alternative hooks, so the user sees the range before committing. |
| `channels` | string[] | Suggested target channels (`linkedin`, `article`), or empty. |
| `source` | string | Human-readable origin. e.g., `"Reddit r/marketing, May 24 2026"`, `"Slack #wins, May 24 2026"`. |
| `sourceId` | string | The dedup key: URL, Slack permalink, or message id. |
| `signalScore` | integer | 1 to 10 (audience relevance dominant). See `scoring-rubric.md`. Required on content-idea and proof. |
| `signalNotes` | string | Brief reason for the score. |
| `tier1Sources` | object[] | content-idea: 2 to 3 verified references (more if available), each `{ "outlet": "...", "date": "...", "title": "...", "url": "..." }`. Required for content-ideas from external sources. For internal sources (Slack, customer), capture what exists (channel/permalink) and note if no public URL. |
| `keyFacts` | string[] | content-idea only: 2+ specific facts/quotes pulled at scan time, so the draft does not start from scratch and the user can judge substance. |
| `proofLine` | string | proof only: `[Name] [past-tense verb] [specific result]`, under ~20 words. |
| `category` | string | proof only: a free-text tag like `time-savings` or `revenue`. |
| `outputs` | object[] | Per-channel draft tracking, populated when drafting starts. Each `{ "channel": "linkedin", "status": "pending", "outputPath": "" }`. Output status: `pending` -> `in-progress` -> `done` -> `shipped`. |
| `notes` | string | Anything else. Production guidance, interview-brief links, etc. |
| `dateFound` | string | `YYYY-MM-DD`. |
| `scanId` | string | ISO timestamp grouping entries from the same scan run. |

---

## Template

```json
{
  "title": "",
  "bucket": "content-idea",
  "status": "new",
  "summary": "",
  "angle": "",
  "whyItMatters": "",
  "recency": "fresh",
  "painPoints": [],
  "suggestedAngles": [],
  "channels": [],
  "source": "",
  "sourceId": "",
  "signalScore": 1,
  "signalNotes": "",
  "tier1Sources": [],
  "keyFacts": [],
  "proofLine": "",
  "category": "",
  "outputs": [],
  "notes": "",
  "dateFound": "",
  "scanId": ""
}
```

Populate only what the bucket needs:
- A `content-idea` must fill `summary` (2 to 4 sentences), `angle`, `whyItMatters`, `recency`, `painPoints`, `suggestedAngles` (2 to 3), `keyFacts` (2+), and `tier1Sources` (2 to 3 linked, for external ideas). These are what make an idea reviewable. An idea missing them is not ready to write to the pipeline. A time-sensitive idea published before the scan window is not written at all.
- A `proof` fills `proofLine`, `category`, and the source.
- A `signal` needs only the common fields plus a clear `summary`.
