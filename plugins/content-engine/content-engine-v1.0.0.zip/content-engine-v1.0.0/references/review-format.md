# Review Format — Detailed Cards and the Scan Digest

How the scan and the queue present ideas so the user can actually decide what to build. Every idea shows as a **detailed card**, not a one-line summary. The scan also writes all the cards to a readable **digest file** so the user reviews in a doc instead of raw JSON.

This is the single source of truth for the card layout. Both `skills/scan` and `skills/queue` render from here.

---

## The audience label

The cards say "Why [audience] cares." Pull a short label for the audience from `core/persona.md` (its one-liner or title). If there is a clear name or label, use it (e.g., "Why solo founders care"). If not, use "Why your audience cares." Keep it consistent within a scan.

## Source links

Always render sources as Markdown links: `[Outlet (date)](url)`. For internal sources without a public URL (a Slack message, an email), write `Slack #channel (date)` or `Customer email (date)` with no link. Never show a bare idea with zero sources for an external content-idea; if you could not capture a link, say so explicitly: `Source link not captured`.

---

## Content-idea card (full detail)

```
### [N]. [Title] — "[the angle in a few words]"   ·   Score [X]/10

**The idea:** [2 to 4 sentences. What surfaced, what is actually interesting
about it, and what is at stake. Enough that the user can decide without
opening anything else.]

**Angle:** [the lead hook in one sentence]

**Why [audience] cares:** [named pain point from persona.md] — [one sentence on
why it lands for them right now]

**Other angles you could take:**
- [alternative hook a]
- [alternative hook b]

**Key facts:**
- [specific fact, number, or quote with enough detail to be usable]
- [another]

**Sources:**
- [Outlet (date)](url)
- [Outlet (date)](url)

**Bucket:** content-idea · **Recency:** [fresh, published [date] | evergreen] · **Channels:** [suggested] · **Found:** [date] · **Why this score:** [signalNotes, short]
```

## Proof card (light)

```
### [N]. [Person] — [result]   ·   Score [X]/10
**Proof line:** "[the proof line]"
**Source:** [Slack #channel (date) | Customer email (date)]  ·  **Category:** [tag]
```

## Signal card (light)

```
### [N]. [Title]   (signal)
**What it is:** [one to two sentences]
**Source:** [linked or labeled source]
```

---

## The digest file

After a scan, write all cards to `content-engine/reports/scan-report-[YYYY-MM-DD].md`, then open it for the user (`open` the path) so they can read it outside chat.

Structure:

```markdown
# Content Scan — [date]

Found: [X] content ideas · [Y] proof · [Z] signals
Sources run: [list]   Skipped: [list with reason, or "none"]

---

## Content Ideas
[every content-idea card, sorted by score descending]

## Proof
[every proof card, or "None this scan."]

## Signals
[every signal card, or "None this scan."]

---

Next: run /content-queue to review and draft. Ideas live in content-engine/pipeline/.
```

If a previous `scan-report-[same-date].md` exists, append the new cards under a `## Rescan [time]` heading rather than overwriting, so a second scan the same day does not erase the first.

---

## In chat

- **Scan:** print the content-idea cards (respecting the configured volume), then tell the user the digest was saved and opened. Keep proof and signals to a short count with "see the report for detail" unless there are only a few.
- **Queue:** render full cards for ideas that need review (`status: new`). Already-approved and in-progress items stay as brief one-line entries, since the decision on those is already made.

The cards are what let the user decide. Never collapse a content-idea down to a single line during review.
