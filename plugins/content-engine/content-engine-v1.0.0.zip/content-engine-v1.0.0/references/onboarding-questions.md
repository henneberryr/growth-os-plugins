# Onboarding Questions — AskUserQuestion Source of Truth

The setup skill runs these as `AskUserQuestion` calls. This file holds the canonical wording, options, and follow-up logic so the questions stay consistent. The skill orchestrates; this file supplies the content.

**Rules for every question below:**
- Always lead with a recommendation in the surrounding chat before asking, drawn from the website read and any existing files. The user reacts; they do not start blank.
- The user can always choose "Other" and type their own answer (Cowork adds this automatically). Treat free-text answers as first-class.
- Skip any question whose answer you already have from existing `core/` files or the website.
- Group at most 4 questions per `AskUserQuestion` call. The groupings below are deliberate.

---

## Audience

Asked in Step 2, only if `core/persona.md` does not already confirm the audience.

**Question:** "Here's who I think your content is for: [inferred one-paragraph description]. Is that right?"
**Header:** `Audience`
**multiSelect:** false
**Options:**
- **That's them** — Use this audience as the scoring lens.
- **Close, let me refine** — Mostly right; the user adjusts the details.
- **Different audience** — The inference is off; capture it fresh.

After this, capture pain points conversationally: lead with 4 to 6 inferred first-person problems and let the user add or cut. These are the scoring lens, so make them specific and real.

---

## Voice

Asked in Step 3, only if `core/brand-voice.md` does not already define the voice and the user gave no writing samples.

**Question:** "Which best describes how your brand sounds?"
**Header:** `Voice`
**multiSelect:** false
**Options:**
- **Witty and conversational** — Sharp, friendly, a little snarky. Talks with the reader.
- **Bold and persuasive** — High energy, emotional, pushes toward a decision.
- **Warm expert guide** — Calm authority, reassuring, teaches generously.
- **Clear and straightforward** — Plain, direct, no flourish.

Always follow with the voice test (write 2 to 3 sentences in the chosen voice, ask "does this sound like you?"). The samples and the test matter more than the label.

---

## Scan sources

Asked in Step 4. This is the core configuration question.

**Question:** "What should Content Engine watch for content ideas?"
**Header:** `Scan sources`
**multiSelect:** true
**Options:**
- **Industry news and trends** — Web search and fetch for what is moving in your field. No connector needed.
- **Competitor content** — Watch what your named competitors publish, and find the gaps. No connector needed.
- **Community questions** — Reddit, forums, and groups where your audience asks for help. No connector needed.
- **Your Slack workspace** — Member wins, questions, and ideas from your channels. Needs the Slack connector.
- **Customer conversations** — Email and notes from real customer exchanges. Needs the Gmail or Drive connector.

**Follow-ups (plain conversation, per selection):**
- Slack → capture channel names plus a one-line focus for each. Note the Slack connector requirement; if off, the engine skips Slack until enabled.
- Customer conversations → capture the mailbox or folder and what to look for. Same connector note.
- Always, regardless of selections → capture the **market definition**: two or three competitor names and the topic pillars that define your lane. The web sources need this.

---

## Channels

Asked in Step 5.

**Question:** "Which formats should the engine draft?"
**Header:** `Channels`
**multiSelect:** true
**Options:**
- **LinkedIn posts** — Short, scroll-stopping posts in your voice.
- **Articles** — Long-form pieces for your blog or site.
- **Newsletter (coming soon)** — Email issues. Not in this version yet.
- **Video scripts (coming soon)** — Hooks and scripts. Not in this version yet.

Only LinkedIn and Articles are live in v1.0.0. If the user picks a "coming soon" option, acknowledge it, record the interest in the config, and explain it is not yet available.

---

## Cadence and volume

Asked in Step 5, as one `AskUserQuestion` call with two questions.

**Question 1:** "How often will you run a scan?"
**Header:** `Cadence`
**multiSelect:** false
**Options:**
- **Weekly** — A steady rhythm. Best for most people.
- **Daily** — High output, fast-moving market.
- **On demand** — Only when you ask.

**Question 2:** "How many ideas per scan?"
**Header:** `Volume`
**multiSelect:** false
**Options:**
- **Just the best (3 to 5)** — Tightly filtered, only the strongest.
- **A solid batch (6 to 10)** — A working set to pick from.
- **Everything worth noting** — Wide net, you triage.

---

## First scan lookback

Asked in Step 5. The engine has no history yet, so the first scan needs a starting window. After this first run, every scan just looks at everything since the last scan.

**Question:** "Your first scan has no history to work from. How far back should it reach this one time?"
**Header:** `First scan`
**multiSelect:** false
**Options:**
- **Last 7 days** — Just the freshest. Best if you want a tight, current first batch.
- **Last 30 days** — A fuller catch-up on what you have missed recently.
- **Last 90 days** — A deep first sweep of the quarter. More to triage, but nothing big slips by.

Set `last-scan.json` `lastScanDate` to the chosen number of days before now. This only affects the first scan; ongoing scans use "since last scan."

---

## Extensions

Asked in Step 6.

**Question:** "Want to turn on any power-ups? Skip any you don't need."
**Header:** `Extensions`
**multiSelect:** true
**Options:**
- **Interview mode** — Claude interviews you to pull your real expertise into a draft before writing.
- **Auto images for LinkedIn** — Generate an image per post. Needs an image tool connected; otherwise the engine writes an image brief instead.
- **Ship helpers** — Publish-ready formatting and, where a connector exists, a draft to your email platform.
- **Slack digest** — Post each scan summary to a Slack channel. Needs the Slack connector.

Mark any selected extension that needs a connector or tool as `requires_connector` in the config and tell the user what to enable. Never block setup on it.

---

## Reconfigure (returning users)

Asked at the top of Step 0 when `content-engine/config.json` already exists.

**Question:** "Content Engine is already set up. What do you want to change?"
**Header:** `Reconfigure`
**multiSelect:** false
**Options:**
- **Add or change a source** — Jump to the scan-sources step.
- **Toggle an extension** — Jump to the extensions step.
- **Refine voice or audience** — Re-run the persona or voice step.
- **Leave it as is** — No changes; exit setup.

Run only the steps the choice requires. Never wipe the pipeline.
