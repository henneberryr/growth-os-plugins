# Extensions Playbook

The optional power-ups a user can turn on during `/content-setup`. Each is stored in `config.extensions` with `enabled` and, where relevant, `requires_connector`. This file is the single source of truth for how each one behaves and how it degrades when a connector or tool is missing.

**The universal rule:** an extension never blocks the core flow. If the connector or tool it needs is unavailable, the engine does the best version it can without it and tells the user how to enable the full version. It does not fail.

**Outward-facing rule:** anything that sends content to an external place (an email draft, a Notion page, a Slack message) is confirmed with the user the first time before it happens. The user enabled the extension, but a specific send still gets a yes.

---

## `linkedin-images`

**What it does:** generates an image for each LinkedIn post.
**Needs:** an image generation tool connected.
**Where it runs:** the LinkedIn drafter, after the post is saved.

- If an image tool is available: offer 2 to 3 styles via `AskUserQuestion`, generate at 1:1, save beside the post, and open it.
- If no image tool is connected (the Cowork default): write an **image brief** instead (the pull-quote or concept, the style, the aspect ratio) so the user can generate it wherever they have a tool. Do not fail.

## `ship-helpers`

**What it does:** turns a reviewed draft into a publish-ready deliverable and, where possible, drops a draft into the user's publishing destination.
**Needs:** nothing for the core behavior; a destination connector (Notion, Gmail, Drive, or similar) for the optional push.
**Where it runs:** the ship skill.

- Always: produce the final, paste-ready version of the piece (clean formatting for the channel, sources listed for articles).
- If a destination connector is available: offer to create a **draft** there (a Notion page, a Gmail draft, a Drive doc). Confirm before sending. Never publish live automatically; always leave it as a draft for the human to send.
- If no destination connector: finalize the local Markdown file and tell the user it is ready to paste or upload wherever they publish.

## `slack-digest`

**What it does:** posts engine updates to a Slack channel so the user (or their team) sees activity without opening the workspace.
**Needs:** the Slack connector. The target channel is in the extension's `detail.channel`.
**Where it runs:** the scan skill (scan summaries) and the ship skill (shipped notices).

- Scan: after a scan, post the summary (counts + top ideas).
- Ship: after a piece ships, post a one-line "shipped: [title]" notice.
- If the Slack connector is off: skip the post with a note. Never fail the scan or the ship because the digest could not post.

## `interview-mode`

**What it does:** lets Claude interview the user to pull their real expertise into a piece before drafting.
**Needs:** nothing (built-in tools).
**Where it runs:** enables `/content-interview` (arrives in Phase 6) and offers an interview as an option before drafting a high-value idea in the queue.

- When on, the queue may offer "want to do a quick interview first?" on strong ideas before routing to a drafter.
- When off, drafting proceeds straight from the idea's angle and captured facts.

---

## Reading the config

Before acting on any extension, read `config.extensions`, find the entry by `id`, and check `enabled`. If `enabled` is false, skip it silently. If `enabled` is true and it names a `requires_connector`, attempt the connector and degrade per the rules above if it is unavailable.
