# Interview Brief Template

The interview skill writes this to `content-engine/outputs/interviews/[slug].md`. It is **input material**, not a finished piece. Write it in clean, neutral reference style, not the brand voice. The drafters read it later to pull the user's actual words into a post or article.

The most valuable part is the verbatim quotes. Capture them exactly as the user said them. Those become hooks, pull quotes, and openers no AI could have generated.

---

```markdown
# Interview Brief: [Topic]

**Date:** [YYYY-MM-DD]
**Pipeline idea:** [slug, or "none (freeform)"]
**Source:** [pipeline source, or "Original interview, [date]"]

---

## Core Argument

[2 to 3 sentences. The single thesis the user is making. Third person:
"They argue that..."]

## Key Quotes

[5 to 10 direct quotes pulled verbatim from the user's answers, one per line in
quotation marks. The sharpest, most specific, most quotable lines. Do not
rephrase. These become hooks and pull quotes.]

1. "[exact quote]"
2. "[exact quote]"

## Stories & Examples

[Concrete stories and examples the user shared, 2 to 3 sentences each, with
enough detail to reconstruct later.]

- **[Story label]:** [summary]

## Frameworks & Mental Models

[Any process or model the user described, as steps or bullets. Omit if none.]

## Contrarian Takes

[Where the user says the conventional wisdom is wrong. These make strong hooks.]

- [take]

## Audience Connection

[How this maps to the audience's pain points from core/persona.md. Name the
specific pain points it addresses and why.]

## Suggested Outputs

[Which channels this material could feed. Check the strong ones.]

- [ ] **LinkedIn post** — [one-line hook suggestion]
- [ ] **Article** — [one-line angle suggestion]

## Raw Transcript

### Q1: [question]
**A:** [the user's full answer, lightly cleaned for readability, not rewritten]

### Q2: [question]
**A:** [answer]

[Include every question and answer, probes included.]
```
