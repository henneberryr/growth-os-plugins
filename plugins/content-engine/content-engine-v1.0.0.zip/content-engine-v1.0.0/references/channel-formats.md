# Channel Formats

The structural constraints for each channel the drafters target. This is **not** a writing tutorial. Claude already knows how to write a LinkedIn post or an article. This file holds only the format choices that are specific to how Content Engine ships each channel, so the output is consistent and paste-ready.

The voice comes from `core/brand-voice.md`. The audience comes from `core/persona.md`. This file only covers shape.

---

## LinkedIn post

- **Length:** 150 to 600 words. The sweet spot is 300 to 400.
- **Hook:** the first one or two lines must stand on their own. They are what shows before "see more." Sharp, surprising, or pattern-interrupting.
- **One idea:** the whole post develops a single insight. No multi-topic posts.
- **Rhythm:** short paragraphs, one or two sentences each. A blank line between every paragraph. White space is the format.
- **Close:** end on a question that invites comments, or a one-liner that lands the insight.
- **No** hashtag walls (three relevant ones at the very bottom, max, separated by a blank line), no emoji in the body, no "I" as the very first word (lead with the insight).
- **Output:** plain text exactly as it should be pasted into LinkedIn, saved inside a markdown wrapper.

## Article

- **Length:** whatever the idea earns, typically 800 to 1,800 words. Depth over padding.
- **Shape:** a clear opening that earns the read, scannable sections with descriptive subheads, and a close that resolves the promise of the hook.
- **Structure step:** propose a short outline (the sections and what each covers) and confirm it with the user before drafting the full piece. The outline is a human checkpoint, not a formality.
- **Sources:** if the idea carries `tier1Sources` and `keyFacts`, weave them in and link each claim to its source. If sources are thin, do light verification by fetching the captured URLs. Do not invent statistics or quotes.
- **Formatting:** plain Markdown. Use subheads, lists, and the occasional pull quote or table where they help. Portable, no CMS-specific syntax, no front-loaded SEO machinery (that arrives in a later add-on).
- **Output:** a Markdown file the user can take anywhere.

---

## Hard rules (both channels, inherited from brand voice)

These hold even if the brand-voice file is sparse:

- No em dashes. Use periods, commas, colons, or parentheses.
- No "not X, it's Y" reframe constructions.
- No shame hooks or "you're doing it wrong" openers.
- No politics.
- No fabricated facts, stats, names, or quotes.

If `core/brand-voice.md` adds its own rules, those apply on top of these.
