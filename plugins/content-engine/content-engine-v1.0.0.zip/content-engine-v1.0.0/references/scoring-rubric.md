# Scoring Rubric — Which Ideas Are Worth Writing

Every `content-idea` (and `proof`) entry gets a `signalScore` from 1 to 10 and a one-line `signalNotes`. Higher scores surface first in `/content-queue`, so the user spends their time on the strongest ideas.

This rubric is the engine's judgment layer. It does **not** use search-volume or SEO demand data (that arrives in a later add-on). It scores on relevance, corroboration, timing, fit, and engagement.

---

## The window gate (apply before scoring)

Scoring only happens for items that belong in this scan. A **time-sensitive** item (news, release, announcement) published before the scan window's `lastScanDate` is **out**: drop it, do not score it. The window is a gate, not a penalty. A stale story is not a low-scoring idea, it is not an idea for this scan at all.

**Evergreen** items (trends, how-tos, recurring questions with no firm date) pass the gate but are tagged `recency: "evergreen"`, scored without the freshness factor, and capped at half the kept ideas so a scan does not fill up with timeless content.

## How to score

Sum the factors below for a score from 1 to 10. There is no compression cap: the scale is wide on purpose so the best ideas separate from the merely good. Floor at 1.

**Audience relevance is the dominant axis (0 to 4)** — worth as much as everything else combined. An idea that hits a real, acute pain point is worth more than a timely-but-tangential one, and the score should say so.

| Factor | Points | How to judge it |
|--------|:------:|-----------------|
| **Audience relevance** | 0 to 4 | Read `core/persona.md`. **4** = hits a named pain point hard and obviously; the audience will feel it. **3** = clearly tied to a pain point. **2** = relevant but secondary. **1** = tangential. **0** = a stretch (drop it). |
| **Corroboration** | 0 to 2 | **2** = same topic across 2+ sources or 2+ people this scan. **1** = one strong source. **0** = thin or a passing mention. |
| **Strategic fit** | 0 to 2 | **2** = squarely inside one of the user's `topicPillars` (from config). **1** = adjacent. **0** = off-pillar. |
| **Freshness** | 0 to 1 | Time-sensitive items only (already inside the window). **1** = broke in the last 48 hours or a live moment now. **0** = otherwise. Evergreen: N/A, skip it, no penalty. |
| **Engagement** | 0 to 1 | **1** = visible heat (busy thread, high replies, lots of reactions). **0** = quiet. |

Max 10 (9 for evergreen, which cannot earn the freshness point, so fresh news edges out evergreen all else equal).

**Bands (how to read a score):**
- **8 to 10** — write this first.
- **5 to 7** — solid, worth a look.
- **3 to 4** — marginal; only if it fills a real gap.
- **1 to 2** — skip; do not write it to the pipeline unless something special.

**Tie-break** when two ideas score the same: the more acute pain point wins, then fresher, then better sources.

**Always write `signalNotes`** as a short explanation, e.g.:
`"Score 8: hits the 'inconsistent pipeline' pain hard (4), across 2 sources (2), on-pillar (2)."`

---

## Enriching a content-idea (required, this is what makes it reviewable)

A content-idea is only worth writing to the pipeline if the user can decide on it without opening anything else. For each content-idea, capture all of:

- **`summary`** — 2 to 4 sentences: what surfaced, what is actually interesting, and what is at stake. Not a fragment.
- **`angle`** — the lead hook in one sentence. "Why would *this* audience stop and read?" Framed from the persona's pain points and the brand voice.
- **`whyItMatters`** — one sentence naming the specific persona pain point this hits and why it lands for the audience right now.
- **`suggestedAngles`** — 2 to 3 alternative hooks, so the user sees the range before committing.
- **`keyFacts`** — 2 or more specific facts, numbers, or quotes, so the substance is visible and the draft does not start from zero.
- **`tier1Sources`** — for external ideas (news, competitor, community), 2 to 3 verified references, each with outlet, date, and a real URL. Capture the links at scan time. For internal ideas (Slack, customer), capture the channel or permalink and note if there is no public URL.
- **`recency`** — `"fresh"` for a time-sensitive item published inside the window, or `"evergreen"` for undated/timeless material. This drives the freshness factor and how the card is labeled.

Do not write the full piece here. Capture the materials a person needs to make a build-or-skip call. If you cannot gather at least a real summary, a why-it-matters, and one source, the idea is not ready: drop it or mark it a `signal` instead.

---

## What does NOT raise a score

- A time-sensitive story published before the scan window. Do not score it, drop it. The window is a gate, not a deduction.
- Generic advice the whole market already repeats.
- Vague praise with no specific result (that is not `proof`; `proof` needs an attributable, concrete win).
- A topic the user already covered recently. If you can tell it is a repeat of existing work, subtract a point or skip it.
- Anything political. Skip it entirely. This is a hard rule.

## Quality bar

Three strong ideas beat ten weak ones. When the score lands at 1 or 2 and nothing about the idea is compelling, do not write it to the pipeline. A missed idea gets caught next scan. A weak idea just costs the user review time.
