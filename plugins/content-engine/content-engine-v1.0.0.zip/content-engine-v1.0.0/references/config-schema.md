# config.json — Schema and Template

The setup skill writes `content-engine/config.json`. Every other Content Engine skill reads it. This file is **static**: it changes only when the user re-runs `/content-setup`.

Keep it minimal and readable. Do not store anything Claude can infer at runtime; store only the user's decisions.

---

## Field reference

| Field | Type | Notes |
|-------|------|-------|
| `version` | string | Config schema version. `"1.0.0"` for this build. |
| `business.name` | string | Business name. |
| `business.url` | string | Website, or `""`. |
| `personaPath` | string | Path to the persona file, usually `core/persona.md`. |
| `voicePath` | string | Path to the voice file, usually `core/brand-voice.md`. |
| `market.competitors` | string[] | Two or three competitor names or domains. |
| `market.topicPillars` | string[] | The topics that define the user's lane. |
| `sources` | object[] | Enabled scan sources. See below. |
| `channels` | string[] | Drafting channels. v1.0.0 supports `"linkedin"` and `"article"`. |
| `cadence` | string | `"weekly"`, `"daily"`, or `"on-demand"`. |
| `volume` | string | `"focused"` (3 to 5), `"batch"` (6 to 10), or `"wide"`. |
| `extensions` | object[] | Enabled power-ups. See below. |
| `interestedSoon` | string[] | "Coming soon" channels the user wanted (e.g., `"newsletter"`), recorded for later. |

### `sources[]` entries

| Field | Type | Notes |
|-------|------|-------|
| `id` | string | One of `industry-news`, `competitors`, `community`, `slack`, `customer-conversations`. |
| `enabled` | boolean | Whether to run this source. |
| `requires_connector` | string \| null | Connector needed (e.g., `"slack"`, `"gmail"`), or `null` for built-in web sources. |
| `detail` | object | Source-specific config. For `slack`: `{ "channels": [ { "name": "#wins", "focus": "member results" } ] }`. For `customer-conversations`: `{ "location": "...", "focus": "..." }`. Empty `{}` for web sources. |

### `extensions[]` entries

| Field | Type | Notes |
|-------|------|-------|
| `id` | string | One of `interview-mode`, `linkedin-images`, `ship-helpers`, `slack-digest`. |
| `enabled` | boolean | |
| `requires_connector` | string \| null | e.g., `"image-tool"`, `"slack"`, or `null`. |
| `detail` | object | Extension-specific config (e.g., `slack-digest` → `{ "channel": "#content" }`). |

---

## Template

```json
{
  "version": "1.0.0",
  "business": {
    "name": "",
    "url": ""
  },
  "personaPath": "core/persona.md",
  "voicePath": "core/brand-voice.md",
  "market": {
    "competitors": [],
    "topicPillars": []
  },
  "sources": [
    { "id": "industry-news", "enabled": true, "requires_connector": null, "detail": {} },
    { "id": "competitors", "enabled": true, "requires_connector": null, "detail": {} },
    { "id": "community", "enabled": true, "requires_connector": null, "detail": {} },
    { "id": "slack", "enabled": false, "requires_connector": "slack", "detail": { "channels": [] } },
    { "id": "customer-conversations", "enabled": false, "requires_connector": "gmail", "detail": {} }
  ],
  "channels": ["linkedin", "article"],
  "cadence": "weekly",
  "volume": "focused",
  "extensions": [
    { "id": "interview-mode", "enabled": false, "requires_connector": null, "detail": {} },
    { "id": "linkedin-images", "enabled": false, "requires_connector": "image-tool", "detail": {} },
    { "id": "ship-helpers", "enabled": false, "requires_connector": null, "detail": {} },
    { "id": "slack-digest", "enabled": false, "requires_connector": "slack", "detail": {} }
  ],
  "interestedSoon": []
}
```

## last-scan.json

Written alongside config at setup. Tracks the scan window for `/content-scan`. The window runs from `lastScanDate` to now, and it is a hard gate for time-sensitive items.

At setup, `lastScanDate` is set from the **first-scan lookback** the user chose (7, 30, or 90 days before now), not a fixed default. After the first scan, each run advances `lastScanDate` to its own run time, so ongoing windows are "since last scan."

```json
{
  "lastScanDate": "[ISO date, the first-scan lookback chosen at setup: 7, 30, or 90 days before now]",
  "lastScanId": "setup-initial",
  "sourcesScanned": [],
  "note": "Initialized at setup from the first-scan lookback. First scan window starts here."
}
```
