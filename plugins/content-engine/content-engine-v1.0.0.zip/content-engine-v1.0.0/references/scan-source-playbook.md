# Scan Source Playbook

How to run each scan source. The scan skill reads `content-engine/config.json`, runs every source where `enabled` is true, and uses this playbook for the mechanics. Sources marked `requires_connector` are tried only if the connector is available; if not, skip with a note and keep going.

**Inputs every source uses:** the scan window (from `last-scan.json`), the `market.topicPillars` and `market.competitors` (from config), and the audience pain points (from `core/persona.md`).

**Scope every query to the window.** Add recency terms (the current month, "this week", "past 7 days", or explicit window dates) so results come back recent. A year-level query (`...2026`) is too broad and pulls stale material. For time-sensitive results (news, releases, announcements), confirm the publish date (fetch the source if unclear) and drop anything published before the window start. Undated, evergreen material (trends, how-tos, recurring questions) is allowed but tagged `evergreen` during categorization, not treated as fresh.

**The golden rule:** never let one source's failure abort the scan. Wrap each source in its own attempt. On error or empty result, log it and move to the next.

---

## Web sources (built-in, no connector)

### `industry-news` — Industry news and trends

Use WebSearch across the topic pillars to find what is moving right now. For each pillar, run a window-scoped query like `[pillar] news OR launch [current month] [year]` or `[pillar] this week`. Use WebFetch to open the most relevant results and pull the headline, the key facts, the **publish date**, and the outlet.

Look for: developments the audience would want explained, shifts that affect how they work, new tools or moves in the space. Skip: thin listicles, opinion with no news hook, and **anything published before the window start** (confirm the date, drop it if it is stale).

### `competitors` — Competitor content and gaps

For each name in `market.competitors`, WebFetch their blog or content hub (try `/blog`, `/resources`, or their site root). Note what they are publishing lately. Two kinds of finding qualify:
- A topic they are covering that the audience clearly cares about (a `content-idea` you can cover with a sharper angle).
- A gap: something on-pillar they are NOT covering well (a `content-idea` with an opening).

Do not copy a competitor's piece. Capture the topic and a differentiated angle.

### `community` — Community questions

Use WebSearch with site scoping to find where the audience asks for help: `[pillar] site:reddit.com`, `[pillar] site:quora.com`, plus any forums relevant to the niche. WebFetch high-engagement threads.

Look for: recurring questions (those are `content-idea` gold), strong opinions, and problems stated in the audience's own words. A question asked repeatedly is a high-corroboration content idea. Skip: spam, self-promotion, one-off niche questions with no pattern.

---

## Connector sources (graceful degradation)

These need a Cowork connector. Attempt the source; if the connector is off or the call errors, record `[source] skipped (connector not available)` and continue. Never block.

### `slack` — Your Slack workspace

Requires the **Slack** connector. Read the configured channels and per-channel focus from `config.sources` (the `slack` entry's `detail.channels`).

For each channel, search for messages in the scan window (an `after:` filter on the date). Match each message against that channel's stated focus, for example:
- A "wins" channel → `proof`: a specific, attributable result. Write a `proofLine`.
- A "questions" or "help" channel → `signal` (a gap) or `content-idea` (a recurring question worth answering publicly).
- An "ideas" or general channel → `content-idea`.

Skip: join/leave notices, bot messages, pure logistics, low-signal chatter.

### `customer-conversations` — Email and notes

Requires the **Gmail** or **Drive** connector (whichever `requires_connector` names). Read the configured location and focus from `config`. Search the scan window for customer exchanges that reveal a win (`proof`), a recurring question (`content-idea` or `signal`), or a strong quote. Respect privacy: capture the insight, not personal identifiers beyond a first name.

---

## After gathering (handled by the scan skill, not here)

Once each source has produced raw findings, the scan skill categorizes them into buckets (`pipeline-schema.md`), scores them (`scoring-rubric.md`), deduplicates against existing pipeline files, and writes the survivors. This playbook only covers how to gather from each source.
