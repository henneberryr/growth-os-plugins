# Persona Template

The setup skill writes this to `core/persona.md` **only if that file does not already exist**. If it exists, reuse it. This is a shared static file every Growth OS tool reads, so keep it clean and business-agnostic in structure.

Fill the brackets from what the user told you and what you read on their site. Leave a field out rather than inventing it. The pain points matter most: they are the lens Content Engine scores every idea against, so make them specific and written in the audience's real voice.

---

```markdown
# Audience — [Business Name]

> Who this business creates content for. Content Engine scores every idea against the pain points below: an idea is worth writing when it hits one of these.

Last updated: [date]

## Who They Are

- **One-liner:** [one sentence describing the ideal audience member]
- **Role / situation:** [what they do, their stage]
- **Context:** [business size, market, anything that shapes how they buy and read]

## What They Care About

[3 to 6 bullets on goals, motivations, and what "winning" looks like for them.]

## Pain Points (the scoring lens)

[4 to 8 specific, first-person problems. Real language, not marketing speak. Each one is something an idea could speak to.]

1. **[Short label]** — "[first-person quote of the frustration]"
2. **[Short label]** — "[first-person quote]"
3. **[Short label]** — "[first-person quote]"

## How They Talk About the Problem

[A few phrases they actually use. These help the engine recognize relevant signals during a scan and write hooks that resonate.]

## Where They Spend Time

[Channels, communities, publications. Useful for choosing scan sources.]
```
