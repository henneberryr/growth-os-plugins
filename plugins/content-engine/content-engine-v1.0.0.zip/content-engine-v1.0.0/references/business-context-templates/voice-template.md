# Voice Template

The setup skill writes this to `core/brand-voice.md` **only if that file does not already exist**. If it exists, reuse it. This is a shared static file every drafting skill reads.

Capture what Claude cannot infer: this specific brand's sound, signature moves, and hard rules. Do not write a lecture on copywriting. Claude already knows how to write. This file tells it how to write like *this* business.

Fill the brackets from writing samples (best), the voice test, and what the user said.

---

```markdown
# Brand Voice — [Business Name]

> How this business sounds. Every Content Engine draft reads from here.

Last updated: [date]

## Summary

[2 to 3 sentences capturing the personality. e.g., "Witty and direct. Talks to the reader like a sharp friend who has done the work. Confident, never preachy."]

## Tone Dimensions

| Dimension | Where this brand lands |
|-----------|------------------------|
| Formality | [casual ... formal] |
| Energy | [calm ... high] |
| Humor | [none ... frequent, and what kind] |
| Authority | [how it earns trust: specifics, proof, experience] |

## Signature Moves

[What makes this voice recognizable. Sentence rhythm, parenthetical asides, one-sentence paragraphs, direct address, analogies. Pull these from the samples.]

## Hard Rules (never break)

[Things this brand never does. Capture the user's stated rules plus the Content Engine defaults below.]

- No em dashes. Use periods, commas, colons, or parentheses.
- No "not X, it's Y" reframe constructions.
- No shame hooks or "you're doing it wrong" openers.
- No politics.
- [User's own rules: words they hate, things they never say.]

## Words and Phrases

- **Use:** [signature words this brand likes]
- **Avoid:** [words this brand never uses]
```
