---
description: Upgrade your Growth OS for E-Commerce workspace to the latest plugin version
allowed-tools: Read, Write, Edit, Bash, AskUserQuestion, TodoWrite
---

Read the Quick Start skill at `${CLAUDE_PLUGIN_ROOT}/skills/quick-start/SKILL.md`.

Check whether `progress.md` exists in the workspace root:

- If progress.md does NOT exist, tell the user: "It looks like the Quick Start hasn't been run yet. Say 'quick start' or type /quick-start to get started."
- If progress.md exists but the Quick Start is NOT complete, tell the user: "Your Quick Start is still in progress. Say 'continue setup' or type /quick-start to pick up where you left off."
- If progress.md exists AND the Quick Start is complete, check for new features that need to be added. Run the "Upgrading from v1.0" section of the SKILL.md. If the workspace is already up to date (all features present), tell the user: "Your workspace is already up to date. Nothing to upgrade."
