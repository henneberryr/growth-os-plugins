# Growth OS for E-Commerce -- Quick Start

Guided setup that builds an AI marketing workspace for your online store in one session.

## What It Does

The Quick Start collects your store assets (website, product pages, social profiles, email campaigns, ad creative), then walks you through creating your core operational files: product catalog, customer persona with pain/pleasure quotes, brand voice guide (with product description approach), personalized morning routine with scheduled automation, and tailored customer growth ideas. When it's done, Claude knows your store, your customers, your voice, and your daily rhythm, and you have a prioritized list of ideas for growing your revenue.

Built specifically for e-commerce: DTC brands, Shopify stores, Amazon sellers, multi-channel retailers, subscription boxes, and digital product creators. Uses a 10-stage Buyer Journey framework (not a generic marketing funnel) that maps to how online shoppers actually discover, evaluate, purchase, and return.

## How to Use

1. Install the plugin in Claude Cowork
2. Say "quick start", "set up my workspace", or type `/quick-start`
3. Follow the guided interview. Claude will ask questions, crawl your website, process your uploads, and build each document with your input

The setup takes 30-60 minutes depending on how much context you provide. You can stop at any point and pick up later with "continue setup."

## Components

| Component | Type | Description |
|-----------|------|-------------|
| quick-start-ecommerce | Skill | 7-phase guided workspace builder with store asset intake, document creation, and workflow setup |
| /quick-start | Command | Starts or resumes the Quick Start process |
| /upgrade | Command | Adds new features to an existing workspace without re-running setup |

## Skills Included

### Quick Start for E-Commerce

The core skill that powers the entire guided setup. It has 7 steps (Getting to Know Your Store, Mapping Your Product Catalog, Defining Your Ideal Customer, Capturing Your Brand Voice, Building Your Daily Store Gameplan, Wiring It All Together, Growth Ideas for Your Store) plus optional Tier 2 enhancements (Store Info, Brand Design, Content Rules with compliance notes).

**Trigger phrases:** "quick start", "run the quick start", "set up my workspace", "build my workspace", "get started", "continue setup", "good morning" (if Quick Start is incomplete)

## E-Commerce-Specific Features

- **Buyer Journey framework** with 10 stages: Need Aware, Solution Searching, Comparison Shopping, Store Discovery, Browse and Consider, Purchase, First Use, Review and Share, Repeat Purchase, Advocacy
- **5 e-commerce store patterns:** DTC Product Brand, Multi-Brand Retailer, Amazon Seller, Subscription Box, Digital Products
- **E-commerce platform discovery:** Shopify, Amazon, Klaviyo, Google Shopping, SMS tools, review platforms, loyalty programs, influencer partnerships
- **Product description approach** in brand voice guides: how to balance storytelling with specs for product copy
- **Morning routine with sales snapshot:** Optional daily check of revenue, orders, AOV, and top-selling products
- **Content rules with compliance awareness:** E-commerce-specific guidance on FTC endorsements, product claims, CAN-SPAM, GDPR/CCPA, price integrity, and review authenticity

## Example Businesses

The plugin includes two complete example sets that Claude uses as quality benchmarks:

1. **Ember and Oak** -- DTC hand-poured candle and home fragrance brand (product-based)
2. **TrailPeak Outfitters** -- Multi-brand curated outdoor gear retailer (curation/retail-based)

## Requirements

- Claude Cowork desktop app
- A store website or an aspirational store website to model from
- Google Calendar MCP connector (optional, for calendar in morning routine)

## Examples

**Starting fresh:**
> User: "Let's set up my workspace."
> Claude: Asks your name and whether you have an existing store or are building one, then begins collecting assets.

**Resuming a previous session:**
> User: "Continue setup."
> Claude: Reads progress.md, finds where you left off, and picks up from the next incomplete step.

**After completion:**
> User: "Good morning."
> Claude: Runs your personalized morning routine with weather, calendar, sales snapshot, tasks, and suggested actions.

**Getting growth ideas:**
> User: "Growth ideas" or "Show me the growth ideas."
> Claude: Displays your saved growth ideas organized by marketing objective (Awareness, Leads, Sales, Retention).

**Working on a task:**
> User: "/tasks"
> Claude: Shows your task list with copy-paste prompts. Pick a task, paste the prompt, and Claude executes it with full store context.

**Adding enhancements after setup:**
> User: "Enhance my workspace."
> Claude: Walks you through optional additions: store info, brand design guide, and content rules with compliance notes.

## Troubleshooting

**"Quick start isn't picking up where I left off."**
Check that `progress.md` exists in your workspace root. If it was accidentally deleted, the plugin will start fresh. Your core documents (offers, persona, voice) are still intact in the `core/` folder.

**"The morning routine doesn't include my calendar."**
The calendar section requires a Google Calendar MCP connector. If it's not connected, the routine skips that section and tells you. Reconnect the MCP tool and try again.

**"I want to redo a section of the setup."**
Open `progress.md` and uncheck the step you want to redo. The next time you say "continue setup," Claude will re-run that phase. Your existing files will be used as a starting draft.

**"The growth ideas feel too generic."**
Growth ideas are only as specific as the context you provided during setup. The more assets you shared (website, product pages, email campaigns, social profiles), the more targeted the ideas. You can regenerate ideas anytime by saying "generate new growth ideas" after adding more context to your core documents.

**"I want to change my brand voice."**
Edit `core/brand-voice.md` directly, or say "let's update my voice guide" and Claude will walk you through it. Paste in a new writing sample for the best results.

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0.0 | March 2026 | Initial e-commerce release. Forked from Growth OS Quick Start v1.2 with full e-commerce customization: Buyer Journey framework with 10 e-commerce-specific stages, 5 store type patterns, e-commerce example businesses (DTC brand + multi-brand retailer), customer persona with shopping-specific pain points, brand voice with product description approach, morning routine with sales snapshot, and content rules with FTC/CAN-SPAM/GDPR compliance awareness. |
