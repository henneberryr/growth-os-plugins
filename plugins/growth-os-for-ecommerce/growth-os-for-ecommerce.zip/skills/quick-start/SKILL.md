---
name: quick-start-ecommerce
description: >
  This skill should be used when the user says "run the quick start",
  "quick start", "set up my workspace", "set up Growth OS for E-Commerce",
  "continue setup", "get started", "build my workspace", or any variation of
  starting or continuing the Growth OS for E-Commerce guided setup. Also
  triggers on "good morning" or session start if progress.md shows the Quick
  Start is incomplete.
version: 1.0.0
---

# Growth OS for E-Commerce -- Quick Start v1.0

Build a working AI marketing workspace for your online store in one session. Guided setup that collects store assets, creates core documents, delivers a personalized morning routine with scheduled automation, generates tailored customer growth ideas, and builds the first working workflow.

## How It Works

The Quick Start has two tiers:

- **Tier 1 (Required):** Asset intake, product catalog document, customer persona document, brand voice guide, morning routine (with scheduling), CLAUDE.md, growth ideas, first workflow. Completing these means the Quick Start is DONE.
- **Tier 2 (Optional Enhancements):** Store info, brand design, content rules with e-commerce compliance notes. These make the workspace better but are not required.

The user hits "congratulations" after Tier 1. Do not gate completion on Tier 2 items.

## Progress & Tone

**Progress indicators:** At the start of each phase, show a branded progress line:

```
Step [N] of 7: [Phase Name]
```

The seven steps are:
1. Getting to Know Your Store
2. Mapping Your Product Catalog
3. Defining Your Ideal Customer
4. Capturing Your Brand Voice
5. Building Your Daily Store Gameplan
6. Wiring It All Together
7. Growth Ideas for Your Store

**Sell the Step.** Before EVERY phase, tell the user what this step unlocks for THEM. Not "we're building your product catalog." Instead: "Once I know what you sell, I can write product descriptions, draft launch emails, and build landing pages that match your actual products and pricing." First person as Claude. Concrete. What will they be able to DO once this step is done?

**Transitions between phases:** One-line acknowledgment of what they built + one sentence selling the next step. Warm and real, not hype-y.

Good: "Your product catalog is locked in. Every email, ad, and product page I write will reference the real products you sell. Next up: your ideal customer."
Bad: "Product catalog created successfully." or "AMAZING work! You're absolutely crushing it!"

**Step 1 is required.** Getting to Know Your Store must be completed. Steps 2-7 each offer a skip option.

**Skip option on Steps 2-7.** Always include "Skip for now." If skipped, mark in progress.md and say: "No problem. We can always come back." Use Step 1 context as fallback for later steps.

**The overall tone:** You are an enthusiastic, capable colleague from theCLICK who understands e-commerce marketing. Warm, direct, keep things moving. Real confidence in the outcome, not fake excitement. Aware of e-commerce's unique considerations (conversion optimization, customer acquisition costs, retention, seasonality) without being preachy about them.

## Before You Begin

1. Check if a `progress.md` file exists in the workspace root. If it does, read it to determine where the user left off and resume from there. Do not restart steps already marked complete.
2. If no progress.md exists, this is a fresh start. Create it from the template in `references/progress-template.md`.
3. **Upgrade detection.** If progress.md exists AND the Quick Start shows complete, determine which version by checking for `growth-ideas.md` and `TASKS.md`:
   - Neither `TASKS.md` nor `growth-ideas.md` exists: v1.0 workspace without growth ideas. Run "Upgrading from v1.0" below.
   - `TASKS.md` exists but `growth-ideas.md` does not: workspace with tasks but no growth ideas. Run "Upgrading from v1.1" below.
   - Both exist: already current. No upgrade needed.
4. Read the example files in `references/` to understand what good output looks like. There are two example sets: one for a multi-brand retailer (curation/retail-based) and one for a DTC product brand. Match to whichever is closest to the user's store during intake.

## Upgrading from v1.0

This is a v1.0 workspace (no TASKS.md, no growth-ideas.md). Run the v1.1 additions first, then chain into the v1.1 upgrade.

1. **Tell the user what's happening.** "Your workspace was built with an earlier version of Growth OS for E-Commerce. I'm going to add growth ideas, a task list, and a /tasks command. Everything you've already built stays exactly as-is."

2. **Create the /tasks slash command.** Copy the template from `references/tasks-command-template.md` to `.claude/commands/tasks.md`.

3. **Clean up orphaned files.** If `dashboard.jsx` or `dashboard.html` exists in the workspace root, ask the user: "I found an old dashboard file from the previous version. OK to remove it?" Delete only if confirmed.

4. **Patch CLAUDE.md.** Read the user's existing CLAUDE.md. Do NOT regenerate it. Instead:
   - If a "Dashboard Maintenance" section exists, remove it
   - Add the "Task Management" section from `references/claude-md-template.md` (the block between `## Task Management` and the next `---`)
   - Add `growth-ideas.md` and `TASKS.md` to the folder structure if not already there
   - Add `.claude/commands/tasks.md` to the folder structure if not already there

5. Now run the "Upgrading from v1.1" steps below (which generate growth ideas and seed TASKS.md).

## Upgrading from v1.1

This is a v1.1 workspace (has TASKS.md but no growth-ideas.md). The big addition is the Growth Ideas experience.

1. **Tell the user what's happening** (skip if chaining from v1.0 upgrade). "Growth OS for E-Commerce has a new feature: Growth Ideas. It analyzes your store, customer persona, and products to generate specific ideas for growing your revenue, organized by marketing objective."

2. **Generate growth ideas.** Read `references/customer-journey-framework.md`, then read the user's existing `core/offers.md`, `core/persona.md`, `core/brand-voice.md`, and Marketing Channels from progress.md. Follow the full idea generation protocol from Phase 7 (see below) to produce 12-20 numbered, store-specific ideas organized by the 4 marketing objectives.

3. **Save to `growth-ideas.md`** at the workspace root.

4. **Present the ideas** and ask which ones the user wants to work on (by number).

5. **Re-seed TASKS.md** with the selected ideas. Preserve any existing Done items. Replace Up Next / This Week / Someday with tasks generated from the user's selected ideas, each with an actionable prompt.

6. **Patch CLAUDE.md** (if not already done in v1.0 chain):
   - Add `growth-ideas.md` to the folder structure
   - Add to the Quick Reference / decoder section: `growth ideas = saved list of customer growth ideas organized by objective (growth-ideas.md)` and `show me the growth ideas = display the growth ideas document`

7. **Update progress.md.** Add growth-ideas sub-checkboxes under Phase 7 and check them off.

8. **Present the result.** Show a brief summary: "Growth OS just added [N] growth ideas and [N] tasks to your workspace. Say 'show me the growth ideas' to revisit the full list, or '/tasks' to see your task list."

After upgrade, normal session behavior resumes. The upgrade steps only run once (`growth-ideas.md` existing prevents re-triggering).

Users can also trigger this manually by typing `/upgrade` or saying "upgrade my plugin."

## Folder Structure

Create this structure at the start, before any interviews. Use placeholders for files not yet filled.

```
[workspace root]/
├── CLAUDE.md
├── TASKS.md
├── growth-ideas.md
├── progress.md
├── core/
│   ├── offers.md                  (products and pricing)
│   ├── persona.md                 (ideal customer persona)
│   ├── brand-voice.md             (brand communication guide)
│   ├── business-info.md           # Tier 2 (store info)
│   ├── brand-design.md            # Tier 2
│   └── content-rules.md           # Tier 2 (includes compliance notes)
├── routines/
│   └── morning-routine.md
├── workflows/                     # First workflow built in Phase 7 (if applicable)
├── memory/
│   └── glossary.md
└── .claude/
    └── commands/
        ├── morning-routine.md
        └── tasks.md
```

For files not yet completed: `<!-- Placeholder: This file will be created during setup. -->`

## Done Beats Perfect

If the user hesitates on any step, remind them: "Whatever you give me now is a starting point. Growth OS gets smarter the more you use it. We can refine anything, anytime. Let's keep moving."

## Behavioral Modes

Two independent preference axes are set during Phase 1, Step 3. Read them from progress.md at the start of every session.

**Setup Mode (speed vs. precision):**

| Behavior | Speed | Precision |
|---|---|---|
| Follow-up questions | 1 per step max. Accept good-enough answers. | Ask clarifying questions until confident. |
| Draft review | Show summary, ask "looks good?", move on quickly. | Show summary, invite specific feedback, offer revision. |
| Revision rounds | 1 round max, then save and move on. | Up to 3 rounds per step. |
| Skip prompts | Offer proactively: "Want to skip this for now?" | Offer but don't push: "Skip for now?" at the end. |
| Asset collection | Accept what's given. Don't push for more. | Probe: "Anything else? The more I have, the better." |

**Explain Mode (transparent vs. just do it):**

| Behavior | Transparent | Just Do It |
|---|---|---|
| Sell the Step intros | Include the full "sell the step" explanation. | Skip or shorten to one sentence. |
| System explanations | Explain what each file does and why it exists. | Create files silently, present results only. |
| Architecture notes | "This persona doc is what I'll reference every time I write a product description, email, or ad for you." | Skip. Just build and show the output. |
| Transitions | Include "what you built" + "what comes next and why." | Short: "Done. Next up: [step name]." |

Modes combine independently. **Default if not set:** Speed + Just Do It.

## Phase 1: Getting to Know Your Store

Show: `Step 1 of 7: Getting to Know Your Store`

### Step 1: Welcome Message

Before asking any questions, set the tone:

> "Welcome to Growth OS for E-Commerce. This was built specifically for online stores like yours, not adapted from a generic business template. By the time we're done, you'll have an AI that knows your products, your ideal customer, and your brand voice. I'll greet you every morning with a game plan, suggest marketing actions based on what's actually happening in your store, and help you produce content that sounds like your brand. Everything I generate will be grounded in e-commerce best practices: conversion, retention, and the channels that actually drive revenue. Let's build it."

### Step 2: Name and Path Selection

Ask two things using AskUserQuestion:

1. **Your name** (so I can greet you properly)
2. **Do you already have an online store, or are you building one?**

If **existing store:** "Great. I'm going to learn everything I can about your store so I can be useful from day one. Let's start by gathering your assets."

If **building a store:** "Perfect. Think of an online store or brand that's already doing something close to what you want to build. Someone you admire or want to emulate. I'll use them as a starting point and we'll adapt everything to fit what you're building."

Set a context flag in progress.md: `source_context: own_store` or `source_context: aspirational_store`.

### Step 3: Preferences

Two questions that shape how the entire setup runs. Ask both using AskUserQuestion (single-select each):

**Question 1 -- Speed or Precision:**
"Quick question before we dive in: are you more of a 'done is better than perfect' person, or do you want to get everything dialed in before we move on?"

Options: "Done is better than perfect (Recommended)" / "I want to get this really right"

**Question 2 -- Transparency or Just Do It:**
"One more: do you want to know how the system works as we build it, or would you rather I just do the work and show you the results?"

Options: "Show me how it works" / "Just do the work (Recommended)"

Store both in progress.md:
- `setup_mode: speed` or `setup_mode: precision`
- `explain_mode: transparent` or `explain_mode: just_do_it`

After capturing preferences, say:

> "Nothing we build here is permanent. Everything can be changed, refined, and improved as you go. If you're not sure about an answer, give me your best guess or skip it. We can always come back."

These preferences control behavior throughout setup. See the **Behavioral Modes** section for the full rules.

### Step 4: Website Crawl

Ask for the store URL (theirs or the aspirational store).

Crawl using WebFetch. WebFetch returns the page at the URL provided. For deeper context, ask the user for specific page URLs (About, Shop/Collections, Best Sellers, FAQ) rather than assuming you can crawl the full site. Collect:
- What the store sells (products, collections, pricing if visible)
- Who the store serves (audience language, lifestyle positioning)
- How the store describes itself (tagline, mission, about copy)
- Brand signals (tone of voice, visual aesthetic, photography style)
- Platform signals (Shopify, WooCommerce, BigCommerce, Amazon)
- Shipping and returns information
- Any loyalty or rewards programs

**If the crawl fails or returns thin results:** Say: "The website didn't give me much to work with, which is totally fine. We'll build from what you can share directly." Move to asset collection.

Store crawl findings in memory. Do not show raw crawl to the user.

### Step 5: E-Commerce Platform and Channel Discovery

INFER which platforms and channels this store likely uses, ordered by likelihood for THIS specific store type. Common e-commerce platforms and channels include Shopify, Amazon, Instagram, Facebook, TikTok, Pinterest, Google Shopping, email marketing (Klaviyo, Mailchimp), SMS (Postscript, Attentive), and YouTube.

Present using AskUserQuestion with multiSelect: "Which of these platforms are you active on?"

Also ask: "Do you use any of these e-commerce tools?" Present a second multiSelect with options like: Shopify apps, Amazon Seller Central, Klaviyo or email platform, SMS marketing, Affiliate program, Influencer partnerships, Google Shopping / Merchant Center, Review collection tool (Judge.me, Okendo, etc.), Loyalty/rewards program.

For each selected platform, ask for the URL and attempt to crawl with WebFetch. Record ALL platforms in progress.md under "Marketing Channels & Tactics," even if Claude can't access them. This feeds into workflow suggestions later.

### Step 6: Asset Upload Prompt

INFER what assets this specific store is likely to have. Tailor suggestions to the store type:
- **DTC brand:** Product photos, brand guidelines, past ad creative, email campaigns, social content
- **Multi-brand retailer:** Product catalog, vendor list, buying guides, category pages
- **Amazon seller:** Listing screenshots, A+ content, Brand Story page, PPC reports
- **Subscription box:** Unboxing content, past box themes, retention data
- **Digital products:** Sales pages, course outlines, lead magnets, webinar recordings

Present using AskUserQuestion with multiSelect plus "Something else." Tell the user: "Drop files right into this chat. I can read PDFs, look at screenshots, and pull text from just about anything."

Process each file and record any marketing channels discovered in progress.md under "Marketing Channels & Tactics."

### Step 7: The "Anything Else?" Loop

After processing each batch: "Got it. Anything else you want me to see? Past email campaigns, ad creative, best-selling product pages, customer reviews? The more context I have, the better everything downstream is going to be."

Repeat until the user signals they are done: "That's everything" / "No, let's move on" / "I'm done" / or selects a "That's everything" option.

**Gate:** "OK, I've got a solid picture of your store. Let me process everything and start building your workspace."

### Step 8: Asset Processing

Consolidate all collected information into a structured brief: what the store sells, who it serves, how it describes itself, brand signals, pricing strategy, claims/proof points, writing style observations, marketing channels, and platform details. Store in progress.md's Asset Inventory table.

If source_context is aspirational_store, flag which elements are from the model store. Frame Phases 2-4 as planning exercises: "Based on [store name], here's a starting point. Adjust anything that doesn't fit your vision."

Create the full folder structure with placeholders.

## Phase 2: Mapping Your Product Catalog

Show: `Step 2 of 7: Mapping Your Product Catalog`

**Sell the step:** "Now let's document what you sell. This is the foundation. Once I have your products mapped out, I can write product descriptions, draft launch emails, build collection pages, and create campaigns that match your actual inventory and pricing. Every piece of marketing starts here."

**Reference:** Read the closest matching example from references (retailer or DTC brand).

### Steps:

1. Draft `core/offers.md` using ALL collected assets (not just website crawl). For e-commerce, structure products by:
   - Collections or categories (e.g., Best Sellers, New Arrivals, Sale)
   - Individual products or product lines within each collection
   - Pricing strategy (full price, sale, bundles, subscriptions)
   - Flagship/hero products vs. supporting products
   - Lead magnets or free offers (discount codes, guides, quiz results)

2. **If aspirational store:** Frame as "Based on [store name], here's a starting point for what you could sell. What would you change, add, or remove?"

3. **If own store:** Frame as "Here's what I found across your website and the assets you shared. Does this capture your product catalog?"

4. **Summary rule applies.** Show key products with name, price, and one-line positioning. Ask: "Does this capture what you sell? Anything missing or wrong?"

5. Use AskUserQuestion for anything unclear. Keep questions specific: "I found three main collections on your site: Candles, Home Fragrance, and Gift Sets. Is that the full picture, or are there others?"

6. Write the final `core/offers.md` in clean markdown with sections for each collection or product line.

## Phase 3: Defining Your Ideal Customer

Show: `Step 3 of 7: Defining Your Ideal Customer`

**Sell the step:** "This is where things get powerful. Once I know who your ideal customer is, what motivates them to buy, and what frustrates them about shopping online, I can write copy that resonates. Product descriptions, emails, ads, social posts. All of it gets sharper when I know exactly who we're talking to."

**Reference:** Read the closest matching example from references.

### Steps:

1. Using ALL collected assets and the product catalog, draft an initial customer persona:
   - Name (a first name that represents the archetype)
   - Demographics (age range, lifestyle, shopping habits)
   - One-line description
   - What they want (goals, aspirations, shopping motivations)
   - What frustrates them (barriers to purchase, shopping pain points)
   - How they discover and choose products (decision factors)

2. If aspirational store: "This persona is based on [store name]'s customers. Who do YOU want to sell to? How is your ideal customer the same or different?"

3. **Summary rule applies.** Show the name, one-liner, and top goals/frustrations. Ask: "Does this sound like your ideal customer? What would you change?"

4. **Pain point selection (multi-select).** Generate 6-10 likely customer pain points from context. These should reflect real e-commerce consumer frustrations: finding quality products, trusting an unfamiliar brand, comparing options across stores, shipping costs and speed, return hassles, impersonal shopping experiences, ad fatigue, and category-specific concerns. Present using AskUserQuestion with multiSelect so the user checks all that apply.

5. **Build pain/pleasure quote tables.** For each selected pain point, write a pain quote (struggling, first person) and pleasure quote (solved, first person). Before building, explain: "For each pain point, I'll write quotes in your customer's voice. I'll pull from these every time I write an ad, email, product description, or social post for you."

6. **Show 2-3 sample quotes for feedback.** "Does this sound like your customer?" If approved, write the full doc.

7. Write the final `core/persona.md`.

## Phase 4: Capturing Your Brand Voice

Show: `Step 4 of 7: Capturing Your Brand Voice`

**Sell the step:** "Here's where I learn to sound like your brand. Once I have your voice dialed in, everything I write will sound like it came from your team, not from a template. Product descriptions, emails, social captions, ad copy. Your customers will feel the same vibe they get when they visit your store."

### Steps:

1. Ask using AskUserQuestion: "Do you have a piece of writing that sounds like your brand at its best? A product description, an email, a social caption, an About page, or a package insert. Paste it in or upload it."

2. **If the user provides a sample:** Analyze for sentence length patterns, vocabulary preferences, rhetorical habits, tone markers, and things they avoid. Pay special attention to how they describe products (emotional vs. functional), their relationship with the customer (friend vs. curator vs. expert), and how they handle calls to action.

3. Also ask using AskUserQuestion:
   - "What tone do you want to AVOID? (e.g., corporate speak, overly salesy, generic, luxury pretentious)"
   - "In 3-5 words, how would you describe your brand's voice?"

4. Draft `core/brand-voice.md` with sections for: voice summary, vocabulary preferences (including product description approach), sentence patterns, things to avoid, and a before/after example showing generic e-commerce copy vs. the store's voice.

5. **If no writing sample:** "No worries. I'll build a voice guide from everything else I've collected, including your website copy and any materials you shared. You can always refine it later by showing me something your team has written." Generate a best-guess voice doc from website copy, social posts, or any text assets collected during intake.

6. **Summary rule applies.** Show the voice summary and one before/after example. "Does this sound like your brand?"

7. Write the final `core/brand-voice.md`.

## Phase 5: Building Your Daily Store Gameplan

Show: `Step 5 of 7: Building Your Daily Store Gameplan`

**Sell the step:** "This might be my favorite part. Instead of starting your day wondering what to work on, I'll greet you every morning with a briefing: what's happening in your store, what tasks are open, and what I'd suggest you tackle today. Like having a marketing-savvy chief of staff who already read through everything."

**Reference:** Read `references/example-morning-routine.md` for the format.

### Steps:

1. Use AskUserQuestion to learn preferences:
   - "What does a productive morning look like for you? What information do you need first thing?" (options: Calendar overview, Weather, Task list, Sales/revenue check, New reviews check, Industry news, Custom)
   - "What city are you in? (for weather)"

2. Build the morning routine with applicable sections: Greeting (always), Day/date (always), Weather (if requested), Calendar (if connected), Sales snapshot (if requested), Tasks (if they have a system), New reviews (if requested), Industry news (if requested), and Suggested Tasks (ALWAYS include: 3 specific daily suggestions based on workspace state, persona, and active workflows).

3. Write as instructions FOR Claude, not documentation for the user.

4. Write to `routines/morning-routine.md`.

5. Create the slash command at `.claude/commands/morning-routine.md`:

   ```markdown
   ---
   description: Run your morning briefing routine
   allowed-tools: Read, WebSearch, WebFetch, Bash
   ---

   Read and execute the morning routine at routines/morning-routine.md.
   ```

6. Tell the user: "Say 'good morning' or type /morning-routine and Growth OS will run your daily briefing."

### Scheduling Prompt

7. Ask: "Want me to schedule this to run automatically every morning?"

8. If yes, use AskUserQuestion for time (7:00/7:30/8:00/8:30/9:00 AM) and days (Weekdays/Every day).

9. Use `create_scheduled_task` with taskId "morning-routine", prompt "Read and execute the morning routine at routines/morning-routine.md", description "Daily morning briefing", and cron based on answers (e.g., `0 8 * * 1-5`).

10. Confirm: "Done. Your morning routine will run at [time] [days]. You can also say 'good morning' or type /morning-routine anytime."

## Phase 6: Wiring It All Together

Show: `Step 6 of 7: Wiring It All Together`

**Sell the step:** "Now I'm going to wire everything together. I'm creating the file I read at the start of every session so I always know your store, your customers, your voice, and your daily rhythm. After this, every time you open a new conversation, I'll already know everything we've built."

### Steps:

1. Generate `CLAUDE.md` at the workspace root using the template in `references/claude-md-template.md`. Fill all Tier 1 sections with actual data. Mark Tier 2 sections as "Not yet configured" with a note on how to add them.

2. Generate `memory/glossary.md` with a quick-decoder section mapping store terms, product names, collection names, platform-specific shorthand, and e-commerce terminology to plain definitions.

3. Present the congratulations message:

   ```
   Your Growth OS for E-Commerce workspace is live.

   Here's what you've built:
   - Product catalog with your [N] products/collections
   - Customer persona with [N] pain/pleasure quote pairs
   - Brand voice guide so I always sound like your brand
   - Morning routine (scheduled for [time] [days])
   - CLAUDE.md that ties it all together

   From now on, every time you start a conversation, I'll already know
   your store, your customers, and your voice. You're not starting
   from scratch anymore.

   One more step: Growth OS has been analyzing everything you shared, and it has ideas for how to grow your store.

   (Later, you can say "enhance my workspace" to add store info,
   brand design, and content rules with compliance notes.)
   ```

4. Proceed directly to Phase 7. Do not ask if they want to continue. This is the natural capstone.

## Phase 7: Growth Ideas for Your Store

Show: `Step 7 of 7: Growth Ideas for Your Store`

**Sell the step:** "Now here's the payoff. I've spent the last six steps learning your store, your customers, and your voice. Growth OS didn't just absorb that information. It used it to generate ideas for how to grow your revenue and customer base. Want to see what I came up with?"

### Step 1: The Pitch

Present this framing. Keep it tight. Do not lecture. The goal is to orient, not teach a framework.

> "Every online store grows by doing four things well: getting discovered by the right shoppers, capturing their interest, converting them into buyers, and keeping them coming back. I've organized my ideas around those four objectives:
>
> - **Awareness** -- Getting your store in front of the right customers
> - **Leads** -- Turning browsers into subscribers, followers, and prospects
> - **Sales** -- Converting interested shoppers into paying customers
> - **Retention** -- Keeping customers buying more, buying again, and telling others
>
> I've got [N] ideas tailored to your store. Want to see them?"

Use AskUserQuestion: "Want to see the growth ideas I came up with for [store name]?"
Options: "Yes, show me" / "Not right now"

If "Not right now": save the ideas to `growth-ideas.md` anyway and say: "No problem. I saved them to your workspace. You can say 'show me the growth ideas' anytime." Mark Phase 7 complete and skip to the task tracking prompt (Step 5).

### Step 2: Generate the Growth Ideas Document

**Before generating:** Re-read `core/offers.md`, `core/persona.md`, `core/brand-voice.md`, and the Marketing Channels & Tactics table from progress.md. Also read `references/customer-journey-framework.md` for the generation engine. Every idea must reference something specific from the core files. No generic ideas.

**Use the Buyer Journey framework** as the generation engine. The framework has 10 buyer journey stages mapped to the 4 marketing objectives. Claude uses all 10 stages internally to ensure full-funnel coverage, but the user-facing output is organized by the 4 objectives only.

**Generation rules:**

1. Generate 12-20 ideas total. Aim for 3-5 per objective. Fewer is fine if the store doesn't have enough context. Never pad with generic filler.

2. **Every idea MUST pass the specificity test.** It must reference at least one of:
   - A specific product, collection, or offer from `core/offers.md`
   - A specific pain point or desire from `core/persona.md`
   - A specific marketing channel the store actually uses
   - A specific seasonal moment, competitor gap, or customer behavior from the intake

   "Create social media content" fails the test. "Write a 'How to Choose the Right Candle for Any Room' gift guide targeting Jordan's desire to buy confidently" passes.

3. **Each idea gets:**
   - A number (sequential, 1 through N)
   - A bold title (action-oriented, 8 words or fewer)
   - 1-2 sentences explaining what it is and why it matters for THIS store
   - The buyer journey stage it maps to (shown in parentheses: e.g., "Need Aware", "Comparison Shopping", "Repeat Purchase")

4. **Organize by the 4 objectives** with a one-line description of each:

   ```
   ## Awareness
   Getting [persona name] to discover [store name].

   ## Leads
   Turning visitors into subscribers and prospects.

   ## Sales
   Converting interested shoppers into paying customers.

   ## Retention
   Keeping customers buying more, buying again, and telling others.
   ```

5. **Mix of quick wins and bigger plays.** At least half should be things the user could start today or this week with Claude's help. The rest can be larger projects.

6. **Channel-aware.** If the store uses Instagram and email but not TikTok, don't suggest TikTok ideas unless there's a strong strategic reason (and flag it as a new channel opportunity).

7. **Persona-aware.** Write every idea as if speaking about their specific customer. Not "your audience" but "[persona name]" by name.

**Save the full ideas document** to `growth-ideas.md` at the workspace root. This is a keepsake document the user can return to. Title the file: `# Growth Ideas for [Store Name]`

**Present in chat:** Show the full numbered list. Do NOT use AskUserQuestion for this. The list needs to be readable and scrollable, not crammed into a UI widget. Keep the format clean:

```
Growth OS generated [N] ideas for growing [store name], organized by marketing objective:

## Awareness
Getting [persona name] to discover [store name].

1. **[Idea title]** -- [Why it matters for THIS store]. ([Buyer Journey stage])

2. **[Idea title]** -- [Why it matters for THIS store]. ([Buyer Journey stage])

...
```

### Step 3: User Picks Favorites

After presenting the list:

> "Which of these ideas do you want to work on? Give me the numbers. Pick as many or as few as you want. The ones you don't pick aren't going anywhere. They'll stay in your growth ideas file for later."

Wait for the user to respond with numbers. Accept any format: "1, 3, 7, 12" or "1 and 3 and 7" or "the first three and number 12." Parse flexibly.

### Step 4: Build the First Workflow

Look at the selected ideas. Identify which one (or which cluster) would benefit most from a repeatable workflow: a weekly email campaign, a product launch sequence, a seasonal promotion calendar, a social content pipeline, a review collection system.

If a clear workflow candidate exists among the selected ideas:

> "Idea [N] is something you'll want to do regularly, not just once. Want me to build it as a workflow you can trigger with a phrase? For example, you'd say '[trigger phrase]' and I'd handle the rest."

If the user says yes, build the workflow:

```
workflows/[name]/
├── WORKFLOW.md        # Description, numbered steps, inputs, outputs
├── skills/
│   └── [name]/
│       └── SKILL.md   # YAML frontmatter (name, description, version), imperative instructions
└── outputs/
```

The SKILL.md needs valid YAML frontmatter with name, description (including trigger phrases), and version. Write imperative instructions with clear inputs/outputs. Update CLAUDE.md to reference the new workflow and skill.

After building: "Your first Growth OS for E-Commerce workflow is live. Say '[trigger phrase]' to fire it up."

If no clear workflow candidate exists, or the user declines: skip. Not every store needs a workflow on day one.

### Step 5: Task Tracking Setup

This is where the user shapes their own system instead of getting one imposed.

> "You've picked [N] ideas to work on. Want me to start keeping track of these for you? I can set up a task list so nothing falls through the cracks."

Use AskUserQuestion:
- Question: "How do you want to track your ideas and to-dos?"
- Options:
  - "Simple checklist (Recommended)" -- a clean markdown file organized by status
  - "Organized by marketing objective" -- grouped by Awareness / Leads / Sales / Retention
  - "I already use a tool for this" -- ask what tool, see if Claude can integrate
  - Other

**If "Simple checklist":** Create TASKS.md with sections: This Week, Up Next, Someday, Done. Populate "This Week" with the user's top 1-3 picks, "Up Next" with the rest, "Done" with setup milestones.

**If "Organized by marketing objective":** Create TASKS.md with sections: Awareness, Leads, Sales, Retention, Done. Populate each section with the relevant selected ideas.

**If "I already use a tool":** Ask what they use (Notion, Asana, Trello, etc.). If Claude has a connector, offer to set up sync. If not, create TASKS.md as a local backup and let them know they can copy items over.

**If "Other":** Ask what they have in mind. Adapt.

**For all options:** Each task in the file gets:
- A checkbox
- The bold idea title
- A 1-sentence description
- A blockquote prompt the user can copy/paste to execute it with Claude

Example:
```markdown
- [ ] **"How to Choose the Right Candle" gift guide** -- Targets Jordan's desire to buy confidently and drives organic traffic to the Candles collection.
  > `Write a blog post titled "How to Choose the Right Candle for Any Room (A Gift-Giver's Guide)." Reference our Candles and Gift Sets collections. Target Jordan. Use my brand voice.`
```

### Step 6: Create the /tasks Command

Copy `references/tasks-command-template.md` to `.claude/commands/tasks.md` in the user's workspace. This gives them quick-add and status check from day one.

### Step 7: Present and Close

> "Your Growth OS for E-Commerce workspace is ready to work. Here's what you've got:
> - [N] growth ideas saved to your workspace (say 'show me the growth ideas' to revisit)
> - [N] tasks ready to work on (say '/tasks' to check your list)
> - [Workflow name, if built] (say '[trigger phrase]' to run it)
>
> Pick any task and let's go. Or say 'good morning' tomorrow and Growth OS will have your briefing ready."

Update progress.md to mark Phase 7 complete.

## Tier 2: Optional Enhancements

When the user says "enhance my workspace", run the relevant enhancement. Each is independent; any order.

### Enhancement: Store Info

1. Draft `core/business-info.md` using all collected assets.
2. Present a summary and ask for gaps (mission, team, tech stack/platform, channels, fulfillment details, supplier relationships).
3. Write final file.
4. Update progress.md and regenerate CLAUDE.md sections.

### Enhancement: Brand Design

1. Pull from website and assets: colors, fonts, logo, photography style, packaging aesthetic.
2. Draft `core/brand-design.md` with: color palette (hex codes), typography, photography direction, layout preferences, packaging style, usage rules.
3. E-commerce design note: emphasize product photography consistency, mobile-first layout considerations, and brand cohesion across marketplace listings, social media, and email.
4. Update progress.md and CLAUDE.md.

### Enhancement: Content Rules

1. Ask: "Are there any writing rules your brand always follows? Words to avoid, formatting requirements, compliance considerations, style preferences?"
2. Draft `core/content-rules.md` with global rules. Include an e-commerce-specific section covering:
   - FTC endorsement guidelines: always disclose material connections in influencer and affiliate content
   - Product claims: no fabricated reviews, testimonials, or performance statistics
   - Email and SMS compliance: CAN-SPAM and TCPA opt-in language, unsubscribe requirements
   - Customer data privacy: GDPR/CCPA notice when collecting customer data, cookie consent awareness
   - Return/refund transparency: always represent return policies accurately in marketing content
   - Price comparison: never misrepresent "compare at" or "was/now" pricing without legitimate basis
3. Update progress.md and CLAUDE.md.

## Session Continuity

This skill MUST support multi-session completion. On any new session:

1. Read progress.md to determine current state
2. Resume from the first incomplete step
3. Do not re-ask questions for completed steps
4. If the user says "continue setup" or "where was I", read progress.md and pick up

**After completing each step:** Update progress.md immediately. Check the step's checkbox, add any new entries to the Asset Inventory or Marketing Channels tables, and log the session.

## Writing Guidelines

- **Summaries, not full docs.** Show a tight summary when presenting drafts. Ask "Does this look right?" Do not dump full documents into the chat. (Phases 2-4 reference this as "Summary rule applies.")
- **Revision loop.** If the user approves, save and move on. If they request changes, revise and re-present. Revision rounds follow the setup mode (speed: 1, precision: 3, default: 2). Then save and note remaining adjustments in progress.md.
- **AskUserQuestion for everything.** Never dump a wall of questions as plain text. Keep to 1-2 questions per interaction.
- **Store-aware suggestions.** Tailor asset suggestions, platform prompts, and workflow ideas to the specific store type. No generic checklists.
- **Track marketing channels.** When the user mentions or uploads any marketing material, record the channel/tactic in progress.md.
- **Website crawl as draft.** Present as "Here's what I found. Does this look right?" Never assume the crawl is authoritative.
- **Aspirational framing.** When source_context is aspirational_store, frame outputs as starting points: "Based on [store name], here's a starting point. What would you change?"
- **Documents are for Claude.** Write clean, structured references, not marketing copy.
- **No em dashes.** Use periods, commas, colons, or break into two sentences.
- **Examples, not blanks.** Refer to the reference examples. Never show empty templates.
- **E-commerce language awareness.** Use "store" not "business" in store-owner-facing contexts. Use "products" not "offers" when referring to physical goods. Use "collections" or "categories" for product groupings. When in doubt, match the language the store uses on their own website.

### E-Commerce Compliance Guardrails

These rules apply to ALL content generated during and after setup. They should be embedded in the CLAUDE.md and content-rules.md for ongoing enforcement.

- **Never fabricate customer reviews, testimonials, or sales figures.** Only use real quotes from real customers. Never invent product ratings, customer counts, or revenue claims.
- **FTC endorsement compliance.** All influencer and affiliate content must include clear, conspicuous disclosure of material connections. "#ad" or "#sponsored" at the beginning, not buried in hashtags.
- **Honest product claims.** Never promise specific results (weight loss, income, etc.) without substantiation. Product benefits should be accurate and verifiable. "Keeps drinks cold for 24 hours" is fine if tested. "Will change your life" needs qualification.
- **Email and SMS compliance.** All email marketing must include physical address and unsubscribe link (CAN-SPAM). SMS requires explicit opt-in consent (TCPA). Never send marketing messages to contacts who haven't opted in.
- **Customer data privacy.** When suggesting marketing tactics that collect customer data (quizzes, giveaways, loyalty programs), note the need for privacy policy disclosure and consent mechanisms. Be aware of GDPR for international customers and CCPA for California residents.
- **Price integrity.** Never suggest "compare at" pricing, fake scarcity ("only 3 left!"), or countdown timers for non-existent deadlines. If suggesting urgency tactics, they must be based on real constraints (limited inventory, seasonal deadline, cohort capacity).
- **Review authenticity.** When suggesting review collection strategies, emphasize genuine, uncompensated reviews. Never suggest incentivizing positive reviews or suppressing negative ones. Offering a discount for leaving "a review" (not "a positive review") is acceptable.
- **Subscription transparency.** If the store uses subscriptions or auto-ship, marketing content must clearly communicate terms, frequency, and cancellation process.

## References

All example files are in `references/`:

**Content examples:** `example-offers-service.md`, `example-offers-product.md`, `example-persona-service.md`, `example-persona-product.md`, `example-morning-routine.md`, `example-brand-voice.md`, `example-brand-design.md` (Tier 2), `example-business-info.md` (Tier 2).

**Templates:** `progress-template.md`, `claude-md-template.md`, `tasks-template.md`, `tasks-command-template.md`.

**Frameworks:** `customer-journey-framework.md` (internal reference for Phase 7 idea generation; uses an e-commerce-specific Buyer Journey model).
