# Brand Voice Guide -- Ember and Oak

> This document tells Claude how to write in Ember and Oak's voice. Read it before producing any customer-facing content.

Last updated: March 2026

---

## Voice Summary

Ember and Oak's voice is warm, unhurried, and genuine. It sounds like a friend who has impeccable taste in home goods, sharing a recommendation over coffee. Not a luxury brand whispering in cursive. Not a loud DTC brand shouting discounts. Somewhere in the middle: confident in quality, relaxed in delivery, and always focused on how a product fits into real life.

## Core Traits

1. **Warm.** Customers should feel invited in, not marketed to. Every piece of content should feel like it comes from a team that actually loves making candles, not a team that loves selling them.
2. **Specific.** "65 hours of burn time and a cedar-and-sage scent that fills a 200 sq ft room" beats "a luxurious, long-lasting candle experience." Lead with tangible details.
3. **Honest.** If the candle isn't right for a large open-plan living room, say so. If the mini is a better entry point than the full-size, recommend the mini. Trust is built by not overselling.
4. **Sensory.** Ember and Oak sells an experience, not just a product. Content should evoke what it feels like: the first light on a rainy evening, the scent that lingers in the hall after the wick goes out.
5. **Unhurried.** The brand represents slow living and intentional choices. Content should never feel rushed, pushy, or high-pressure. Give the reader space.

## Vocabulary Preferences

**Use these:**
- "Your home," "your space," "your evening" (personal, warm)
- "Hand-poured," "small batch," "clean ingredients" (specificity and care)
- "Ritual," "moment," "unwind" (lifestyle language)
- Short, sensory verbs: light, breathe, pour, fill, warm
- "We" and "our team" (inclusive, personal)

**Avoid these:**
- "Luxury" (overused, signals markup over substance)
- "Artisanal" without context (too precious; show craft instead)
- "Obsessed" (every DTC brand is "obsessed" with something)
- "Shop now!" or "Don't miss out!" (high-pressure CTAs)
- "Game-changer" or "life-changing" (hyperbole)
- "Disrupting the candle industry" (no)

## Product Description Approach

Write product descriptions as mini-stories, not spec sheets. Lead with the experience, then follow with the details:

- Good: "Cedar and Sage is what a cabin smells like after the rain. Woody, herbal, with a clean finish that doesn't overpower a room. 65+ hours of burn time in a reusable ceramic vessel."
- Bad: "Our Cedar and Sage candle is made with premium soy wax and natural fragrance oils. It has a 65-hour burn time and comes in a beautiful ceramic container."

Both convey the same information. The first one makes you want to light it.

## Sentence Patterns

- **Lead with the senses.** "Imagine coming home to..." or "The first thing you notice is..."
- **Short, then elaborate.** "Clean ingredients. That means 100% soy wax, cotton wicks, and phthalate-free fragrance oils. Every candle."
- **Questions as invitations.** "Looking for the right scent for your bedroom?" (not "Buy our bedroom collection!")
- **Direct but gentle CTAs.** "Find your scent" not "Shop now before it's gone."

## Things to Avoid

- Opening emails with discount amounts ("20% OFF EVERYTHING!!")
- Countdown timers or false urgency
- Comparing to competitors by name (unnecessary; let the product speak)
- More than one exclamation point per piece of content
- Product descriptions that list features without connecting them to the experience
- Stock lifestyle photography captions that could apply to any brand

## Before/After Example

**Generic (not Ember and Oak's voice):**
> Introducing our new Fall Collection! These luxurious, hand-crafted candles are made with premium ingredients and will fill your home with amazing scents. Shop now and save 15% on your first order! Don't miss out on these limited-edition fragrances.

**Ember and Oak's voice:**
> Fall at Ember and Oak smells like turning leaves and warm kitchens. This season's collection has three new scents: Harvest Table (cinnamon, clove, fresh apple), Woolen Blanket (sandalwood, vanilla, a touch of smoke), and Late October (damp earth, fig, amber). Small batch, as always. When they sell out, they're gone. Your email list gets first access starting Sunday.

---

## Notes for the Quick Start Skill

This example shows a fully built brand voice guide for a DTC e-commerce brand. When building a voice guide during the Quick Start:

- **If the user provided a writing sample:** Analyze it for sentence patterns, vocabulary, tone, and how they describe products (emotional vs. functional). The voice guide should reflect THEIR actual voice, not a generic "e-commerce" voice. Pay attention to their CTA style, how they handle pricing language, and whether they lean aspirational or practical.
- **If no writing sample:** Build from whatever text-heavy assets were collected during intake (website copy, product descriptions, social captions, email campaigns). Note in the doc that it's based on collected assets and can be refined with a direct writing sample later.
- **Core structure to always include:** Voice summary (2-3 sentences), 3-5 core traits, vocabulary preferences (use/avoid), product description approach, sentence patterns, things to avoid, and at least one before/after example.
- **The user's self-description matters.** During the interview, ask "In 3-5 words, how would you describe your brand's voice?" and "What tone do you want to AVOID?" These answers anchor the voice guide.
- **E-commerce-specific guidance:** Always include a "Product Description Approach" section that defines how the brand handles product copy: spec-forward vs. story-forward, how they integrate pricing, and their CTA style. This is unique to e-commerce and critical for content quality.
