---
description: Manage your task list
---

Read TASKS.md. Based on the user's request, do one of the following:

**If the user said "/tasks" with no additional context:**
Show a brief summary: count of tasks in each section, then list the Up Next tasks by name.

**If the user said "/tasks add [description]":**
Add the described task to Up Next with a generated prompt. Update the "Last updated" date.

**If the user said "/tasks done [task name or number]":**
Mark the matching task as complete, move it to Done with today's date. Update the "Last updated" date.

**If the user said "/tasks someday [description]":**
Add the described task to the Someday section with a generated prompt. Update the "Last updated" date.

**After any change, confirm briefly:** "Added to Up Next" or "Marked as done" with the task name. Don't show the entire file unless asked.
