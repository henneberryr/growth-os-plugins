# Store Information -- Ember and Oak

> This document is referenced by skills and workflows that need store context. Keep it updated when anything material changes.

Last updated: March 2026

---

## Store Identity

- **Brand name:** Ember and Oak
- **Tagline:** Slow-crafted home fragrance for intentional living.
- **Legal entity:** Ember and Oak, LLC (North Carolina, founded 2023)
- **Founded by:** Mira Patel
- **Website:** https://emberandoak.com
- **Support email:** hello@emberandoak.com

## What We Do

Ember and Oak creates hand-poured soy candles and home fragrance products using clean ingredients. Everything is made in small batches at our studio in Asheville, NC. We sell direct-to-consumer through our Shopify store and at select local retailers.

## Mission

We believe your home should smell like something you chose, not something a factory decided. We exist to make high-quality, clean-ingredient home fragrance accessible to people who care about what they bring into their space. No mystery ingredients, no artificial shortcuts, no mass production.

## Target Customer

Our ideal customer is Jordan, the Intentional Homebody. Full persona details are in `core/persona.md`.

## Products & Offers

See `core/offers.md` for full details. Product lines: Candles (flagship Hearthside Candle, Discovery Sets), Home Fragrance (Room Spray, Reed Diffuser), Gift Sets, and Seasonal Drops. Key entry point: Discovery Set ($36, 3-pack sampler).

## Key Platforms & Channels

| Channel | Purpose |
|---|---|
| Website (Shopify) | Primary storefront, all DTC sales |
| Instagram | Brand storytelling, product photography, community building |
| Pinterest | Lifestyle and home decor discovery, product pins |
| Email (Klaviyo) | Weekly newsletter, product launches, seasonal drops, cart recovery |
| SMS (Postscript) | Flash sale alerts, drop notifications, cart recovery |
| Google Shopping | Product feed for search visibility |

## Brand Voice

Warm, unhurried, and genuine. Ember and Oak writes like a friend with great taste sharing a recommendation, not like a brand selling a product. See `core/brand-voice.md` for the full guide.

## Tech Stack

| Tool | Role |
|---|---|
| Shopify | E-commerce platform, storefront, checkout |
| Klaviyo | Email marketing, flows, segmentation |
| Postscript | SMS marketing |
| Google Merchant Center | Shopping feed |
| Judge.me | Product reviews |
| Canva | Social media graphics, email design |
| Later | Social media scheduling |
| Claude (Cowork) | AI workspace for content and marketing operations |
| ShipStation | Order fulfillment and shipping |

## Fulfillment

- Ships from Asheville, NC studio
- Standard shipping: 3-5 business days (USPS Priority Mail)
- Free shipping threshold: $75+
- Packaging: Recycled kraft boxes, tissue paper, branded sticker seal
- Holiday shipping cutoff: December 15 for Christmas delivery

## Key Metrics

- Monthly revenue: ~$28,000
- Average order value: $52
- Repeat customer rate: 34%
- Email subscribers: ~4,200
- SMS subscribers: ~1,100
- Instagram followers: ~8,500
- Monthly website visitors: ~6,000

---

## Notes for the Quick Start Skill

This is a Tier 2 enhancement, not part of the core Quick Start. When a user asks to "enhance my workspace" with store info:

1. Draft from ALL collected assets (website crawl, social profiles, uploads, and the already-completed offers and persona docs).
2. Ask about anything missing: mission, team, tech stack/platform, channels, fulfillment details, supplier relationships.
3. This file is a reference for Claude, not a marketing document. Write it as clean, factual reference material.
4. Cross-reference `core/offers.md` and `core/persona.md` rather than duplicating content.
5. **E-commerce-specific:** Always include platform/tech stack, fulfillment details (shipping times, free shipping threshold, packaging), key metrics (AOV, repeat rate, email list size), and channel breakdown. These are critical for e-commerce stores and frequently referenced in marketing content.
