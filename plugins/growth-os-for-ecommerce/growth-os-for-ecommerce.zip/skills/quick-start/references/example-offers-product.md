# Products & Offers -- Ember and Oak

> This document is the reference Claude reads whenever it needs to understand what we sell, who it's for, and how to position it. Keep it updated when pricing or inventory changes.

Last updated: March 2026

---

## Product Line: Candles

Our core line of hand-poured soy candles made with clean ingredients and cotton wicks. Every scent is developed in-house, tested in real homes, and poured in small batches.

### Flagship Product: The Hearthside Candle (12 oz)

**What it is:** A hand-poured soy wax candle in a reusable ceramic vessel with a cotton wick and 65+ hour burn time.

**Who it's for:** Home decor enthusiasts who care about clean ingredients and want a candle that looks as good as it smells.

**Pricing:** $38 (retail)

**What makes it different:**
- 100% soy wax, no paraffin blends
- Cotton wicks (no lead, no zinc)
- Phthalate-free fragrance oils
- Ceramic vessel designed for reuse (planter, pencil cup, cocktail glass)
- 8 signature scents, rotated seasonally

**Best seller.** Accounts for 45% of total revenue. "Cedar and Sage" is the top scent year-round.

---

### The Discovery Set (3-pack sampler)

**What it is:** Three mini candles (4 oz each) in seasonal scent pairings, packaged in a gift-ready box.

**Who it's for:** New customers trying the brand for the first time, or gift-givers looking for a safe, beautiful option.

**Pricing:** $36 (bundle) / individual minis not sold separately

**Positioning:** "Not sure which scent is yours? Try three." Gift-friendly. Strong Q4 performer and email signup incentive.

---

## Product Line: Home Fragrance

Extending the brand beyond candles with complementary products for the whole home.

### Room Spray (8 oz)

**What it is:** A fine-mist room spray in signature Ember and Oak scents.

**Pricing:** $22

**Positioning:** "Instant refresh between burns." Cross-sell from candle customers.

### Reed Diffuser

**What it is:** A long-lasting diffuser with natural rattan reeds and Ember and Oak signature scents. 90-day lifespan.

**Pricing:** $44

**Positioning:** "Set it and forget it. Scent that lasts all season." Strong in gift sets and as an upsell.

---

## Product Line: Gift Sets

Curated bundles for gifting occasions. Highest AOV product line.

### The Cozy Night In Set

**What it is:** One Hearthside Candle, one Room Spray, and a branded matchbox in a gift box.

**Pricing:** $68

### The Host Gift Set

**What it is:** Two Discovery Sets (6 minis total) in an Ember and Oak tote bag.

**Pricing:** $78

**Positioning:** "The gift they'll actually use." Promoted heavily in Q4.

---

## Seasonal Drops

**What it is:** Limited-edition seasonal scents released quarterly. Past drops: Autumn Harvest Collection, Winter Cabin Collection, Spring Garden Collection.

**Who it's for:** Existing customers and collectors. Drives repeat purchases and urgency.

**Pricing:** $42 (premium over standard Hearthside)

**Positioning:** Small batch. When they sell out, they're gone. Email list gets first access. Drops announced via email 48 hours before public launch.

---

## Free Offer (Lead Magnet / Top of Funnel)

### The Slow Living Letter

**What it is:** A free weekly email with home styling tips, scent pairing guides, behind-the-scenes peeks at new products, and seasonal living inspiration.

**Who it's for:** Home decor enthusiasts who value intentional living and appreciate the story behind the products they buy.

**Frequency:** Weekly (Sundays)

**Positioning:** Not a product catalog. Every issue is something worth reading even if you never buy a candle. Products are woven in naturally. Seasonal drops are announced to the list first.

**CTA to products:** "Shop what's new" link at the bottom. Seasonal drops announced via email first, 48 hours before the public.

---

## Offer Hierarchy

```
The Slow Living Letter (free) -> Discovery Set ($36) -> Hearthside Candle ($38) -> Gift Sets ($68-$78) -> Seasonal Drops ($42)
```

Content builds trust and lifestyle aspiration first. Product recommendations are earned through storytelling and aesthetic consistency. The email list gets first access to everything.

---

## Key Metrics to Reference

- Average order value: $52
- Repeat customer rate: 34%
- Email-attributed revenue: 40% of total
- Best acquisition channel: Instagram (organic) + email
- Seasonal drop sell-through rate: 85% within 72 hours
- Top-selling scent: Cedar and Sage (all-year), Spiced Pumpkin (Q4)
