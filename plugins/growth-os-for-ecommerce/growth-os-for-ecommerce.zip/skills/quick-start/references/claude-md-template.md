# Growth OS for E-Commerce -- Project Instructions

> This is the operational guide Claude reads on every session. It tells Claude where everything is, what's been set up, and what rules to follow.

Last updated: [DATE]

---

## What This Workspace Is

This is the Growth OS for E-Commerce workspace for **[STORE_NAME]**. It contains store context, customer profiles, brand voice rules, and routines that Claude uses to produce content, answer questions, and support daily marketing operations.

The owner is **[USER_NAME]**.

---

## Core Documents

| File | What It Contains | Status |
|---|---|---|
| `core/offers.md` | Products, collections, pricing, and positioning | [STATUS] |
| `core/persona.md` | Ideal customer persona with pain/pleasure quotes | [STATUS] |
| `core/brand-voice.md` | Brand writing style guide | [STATUS] |
| `core/business-info.md` | Store identity, mission, team, channels | [STATUS] |
| `core/brand-design.md` | Visual identity (colors, fonts, photography) | [STATUS] |
| `core/content-rules.md` | Global writing standards with compliance notes | [STATUS] |

---

## Routines

| Routine | Trigger | File |
|---|---|---|
| Morning Routine | "good morning", "gm", "morning" | `routines/morning-routine.md` |

When [USER_NAME] says "good morning" (or any variation like "gm", "morning", "buenos dias"), immediately run the morning routine. Do not ask for confirmation.

---

## Workflows

| Workflow | What It Does | Location |
|---|---|---|
| [WORKFLOW_NAME] | [DESCRIPTION] | `workflows/[path]/` |

> The first workflow is built during Quick Start Step 7. Additional workflows can be added anytime.

### Skills

| Skill | What It Does | Trigger Phrases | Location |
|---|---|---|---|
| [SKILL_NAME] | [DESCRIPTION] | "[phrase1]", "[phrase2]" | `workflows/[path]/skills/[name]/` |

---

## Quick Reference

- **Store:** [STORE_NAME]
- **Platform:** [PLATFORM] (Shopify, WooCommerce, etc.)
- **Primary product:** [PRIMARY_PRODUCT_NAME] ([PRICE])
- **Customer:** [PERSONA_NAME] -- [ONE_LINE_DESCRIPTION]
- **Website:** [WEBSITE_URL]
- **Voice:** [VOICE_SUMMARY_ONE_LINE]

---

## Memory (Quick Decoder)

[GLOSSARY_ENTRIES]

growth ideas = saved list of marketing ideas organized by objective (`growth-ideas.md`). Say "show me the growth ideas" to revisit.
show me the growth ideas = display the growth-ideas.md document

---

## Folder Structure

```
[workspace root]/
├── CLAUDE.md                 <- THIS FILE
├── TASKS.md                  <- Task list with prompts
├── growth-ideas.md           <- Growth ideas by marketing objective
├── progress.md               <- Setup progress tracker
├── core/
│   ├── offers.md             <- Products and pricing
│   ├── persona.md            <- Ideal customer persona
│   ├── brand-voice.md        <- Brand voice guide
│   ├── business-info.md      <- Store identity and context
│   ├── brand-design.md       <- Visual identity
│   └── content-rules.md      <- Global writing rules
├── routines/
│   └── morning-routine.md    <- Daily briefing
├── workflows/
│   └── [workflow-name]/
│       ├── WORKFLOW.md
│       ├── skills/
│       │   └── [skill-name]/
│       │       └── SKILL.md
│       └── outputs/
├── memory/
│   └── glossary.md           <- Quick decoder
└── .claude/
    └── commands/
        ├── morning-routine.md
        └── tasks.md
```

---

## Global Rules

1. Read `core/persona.md` before writing any customer-facing content.
2. Use the brand voice defined in `core/brand-voice.md` for all content.
3. No em dashes in any content. Use periods, commas, colons, semicolons, or break into two sentences.
4. (Additional rules added when content-rules.md is configured in Tier 2)

---

## Task Management

TASKS.md is the Growth OS task list for this workspace. Read it at the start of every session.

### When to update TASKS.md:
- After completing any task: move it to Done with `[x]` and today's date
- After starting work on a task: move it to In Progress
- When new tasks emerge from conversation: add to Up Next with a prompt
- During the morning routine: review tasks, reorder by priority, surface stale ones

### Be proactive:
- When a task-worthy idea comes up in conversation, ask: "Want me to add that to your task list?"
- After completing work that has a natural next step, offer to add the follow-up
- If you notice a gap (missing product description, untapped channel, seasonal opportunity), suggest adding it to Someday
- Ask once. If declined, move on.

### Task format:
- [ ] **Task name** -- Short description
  > `Short prompt that moves this task forward (1-2 sentences max)`

### Prompt rules:
- Every task must have a prompt
- Keep prompts short: 1-2 sentences. Just enough to unstick someone.
- Prompts reference workspace files ("Use my product catalog", "Target my persona")
- Prompts should be specific enough that any Claude session can execute them
- Write prompts as if the user is pasting them into a brand new conversation
- For tasks tied to a skill, the prompt can be just the trigger phrase

### Sections:
- **Up Next**: 3-5 tasks max (too many = overwhelming)
- **In Progress**: 0-2 tasks
- **Someday**: Bigger projects and ideas, no hard limit
- **Done**: Last 10 items (archive older ones by removing them)

### Housekeeping:
- If a task has been in Up Next for more than 2 weeks with no activity, ask if it should move to Someday or be removed
- Periodically review Someday and ask if anything is ready to move to Up Next
- Update the "Last updated" date on every change

---

## Growth Prompts

Growth OS is designed to keep your store moving forward. At natural pause points (end of a task, end of a conversation, after delivering a file), suggest one next action that moves the store forward. Keep it casual and specific, not generic. Pick from:

- **Run a workflow:** "Want me to run [workflow name] while we're here?"
- **Build something new:** "You mentioned [topic]. Want me to draft a [content type] for that?"
- **Extend the workspace:** "We could add a [routine/workflow/skill] for [pattern you noticed]. Want to build one?"
- **Knock out a task:** "I see [task] on the list. Want to tackle that next?"

Rules:
- One suggestion max per pause. Do not stack multiple prompts.
- Only suggest actions that are grounded in real context (a task, a recent conversation, a pattern). Never suggest generic busywork.
- If the user declines or ignores it, drop it. Do not re-suggest the same thing.
- Frame suggestions as offers, not instructions. "Want me to..." not "You should..."

---

## Setup Status

Quick Start Tier 1: [COMPLETE/IN PROGRESS]
Enhancements configured: [LIST_OF_COMPLETED_TIER_2_ITEMS]

To continue setup or add enhancements, say "enhance my workspace" or "continue setup."

---

## How to Update

To modify this file, say "update my workspace" or edit it directly. Claude reads this file at the start of every session.
