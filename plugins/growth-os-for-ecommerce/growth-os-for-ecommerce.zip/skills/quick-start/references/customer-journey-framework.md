# Buyer Journey Framework
## Internal Reference for E-Commerce Growth Idea Generation

> This file is read by Claude during Phase 7 idea generation. It is NOT shown to the user.
> It provides the thinking structure for generating e-commerce-specific growth ideas.

---

## The Four Marketing Objectives

Every e-commerce marketing activity serves one of four objectives. Use these as the organizing categories for user-facing output.

| Objective | Store Goal | What Success Looks Like |
|-----------|-----------|------------------------|
| **Awareness** | Get discovered by people who need your products | More of the right shoppers know your store exists and understand what you sell |
| **Leads** | Turn browsers into subscribers and prospects | Growing email list, SMS list, social following, quiz completions, wishlist signups |
| **Sales** | Convert prospects into paying customers | Revenue from first-time purchases, higher conversion rate, improved AOV |
| **Retention** | Keep customers buying more, buying again, and promoting | Repeat purchases, subscription revenue, referrals, reviews, higher LTV |

---

## The 10 Buyer Journey Stages

Each stage maps to one objective. Use ALL 10 stages as a checklist when generating ideas to ensure full-funnel coverage. The user sees the 4 objectives; you use the 10 stages internally.

### AWARENESS (Stages 1-4)

**Stage 1: Need Aware**
The customer recognizes they have a need, want, or problem that a product could solve.

- Idea types: Educational content that names the need or desire. Blog posts, videos, social content that spark "I need that" or "that's exactly my problem" recognition. Gift guides, lifestyle content, problem-solution articles.
- Key question: What does [persona] search for when they first realize they need something you sell? What question do they ask friends?
- Channel fit: SEO/blog, YouTube, social media (Instagram, TikTok, Pinterest), Google Shopping.
- E-commerce examples: "5 Signs Your Skincare Routine Needs an Upgrade," "The Best Gifts for People Who Love Camping," "Why Your Kitchen Candles Are Giving You Headaches."

**Stage 2: Solution Searching**
The customer starts researching product categories and types (not specific brands yet).

- Idea types: Buying guides, comparison content, "best [product category] for [use case]" posts, educational videos about product materials/features/quality.
- Key question: What product categories is [persona] researching? What comparisons are they making? What misconceptions do they have?
- Channel fit: Blog, YouTube, Pinterest, email nurture, Google Shopping.
- E-commerce examples: "Soy vs. Beeswax Candles: Which Burns Better?," "How to Choose a Backpack for Day Hikes vs. Overnights," "What Thread Count Actually Means for Sheets."

**Stage 3: Comparison Shopping**
The customer is actively comparing specific products and brands. Price, reviews, features, and shipping are all in play.

- Idea types: Product comparison pages, "why choose us" content, detailed product pages with rich media, customer review showcases, UGC (user-generated content) galleries, social proof campaigns.
- Key question: What criteria does [persona] use to choose between your store and competitors? What would tip the scale?
- Channel fit: Google Shopping, retargeting ads, review platforms, product pages, comparison blog posts.
- E-commerce examples: Detailed product pages with 360-degree photos and customer reviews, "Why Our Leather Is Different" sourcing story, comparison grid of your product vs. top alternatives.

**Stage 4: Store Discovery**
The customer finds YOUR specific store and begins evaluating whether to buy from you.

- Idea types: Brand story content, founder story, "about us" page optimization, social media brand presence, PR, influencer partnerships, marketplace listings (Amazon, Etsy), Google Shopping feed optimization.
- Key question: Where does [persona] first encounter your store? What makes them click through vs. scroll past?
- Channel fit: Social media ads, influencer partnerships, Google Shopping, marketplace listings, PR, social organic.
- E-commerce examples: Instagram Reels showing behind-the-scenes product creation, influencer unboxing videos, optimized Amazon A+ content, Google Shopping feed with high-quality images.

### LEADS (Stages 5-6)

**Stage 5: Browse and Consider**
The customer is on your site, browsing products, adding to wishlist, but hasn't committed. They may need a reason to come back.

- Idea types: Email capture popups (discount, quiz, early access), SMS opt-in, wishlist features, "back in stock" notifications, browse abandonment emails, retargeting ads, quiz or product finder tools.
- Key question: What would [persona] trade their email address for? What makes them save your site vs. close the tab?
- Channel fit: Website popups, landing pages, social CTAs, retargeting, email welcome sequences.
- E-commerce examples: "Take our scent quiz and get 10% off your first order," SMS signup for early access to seasonal drops, "Save your favorites" wishlist with email capture.

**Stage 6: Purchase**
The customer is ready to buy. Cart is loaded, checkout is in progress. The focus is removing friction and closing the sale.

- Idea types: Cart abandonment recovery (email, SMS, retargeting), checkout optimization, free shipping thresholds, urgency/scarcity (real only), bundle offers, payment plan options (Shop Pay, Afterpay), guest checkout, trust badges.
- Key question: What friction exists between "add to cart" and "order confirmed"? How do we make checkout effortless?
- Channel fit: Cart abandonment emails/SMS, retargeting ads, checkout page optimization.
- E-commerce examples: 3-email cart abandonment sequence with product photo and review, free shipping at $75 threshold with progress bar, "Complete your order" SMS with direct cart link.

### SALES (Stage 7)

**Stage 7: First Use**
The customer receives the product, unboxes it, and forms their first impression. This moment determines whether they become a one-time buyer or a repeat customer.

- Idea types: Shipping notifications with brand personality, unboxing experience design, package inserts with instructions or surprise touches, post-purchase email sequences (how to use, care instructions, styling tips), first-use check-in.
- Key question: What happens when [persona] opens the package? What would make them think "this was worth every penny"?
- Channel fit: Post-purchase email, SMS, package inserts, unboxing content on social.
- E-commerce examples: Branded shipping box with a handwritten-style thank you card, "How to get the best burn from your candle" email 24 hours after delivery, product care guide as a PDF insert.

### RETENTION (Stages 8-10)

**Stage 8: Review and Share**
The customer has used the product and is ready to share their experience, whether prompted or organically.

- Idea types: Automated review request emails (timed after delivery + usage period), UGC campaigns, photo review incentives, social sharing prompts, hashtag campaigns, community building.
- Key question: What would make [persona] excited to post about this product? What makes the experience worth talking about?
- Channel fit: Post-purchase email, SMS, social media, review platforms (Judge.me, Okendo, Trustpilot, Amazon reviews).
- E-commerce examples: Review request email 14 days after delivery with product photo, "Share your setup and tag us" social campaign, loyalty points for photo reviews.

**Stage 9: Repeat Purchase**
The customer buys again. They trust the brand and see ongoing value. This is where LTV starts compounding.

- Idea types: Replenishment reminders, cross-sell campaigns, new product announcements, subscription/auto-ship offers, loyalty programs, VIP tiers, seasonal re-engagement, win-back campaigns for lapsed customers.
- Key question: What's the natural next purchase for [persona] after their first order? What brings them back before they need to be reminded?
- Channel fit: Email sequences, SMS, loyalty program, in-site recommendations, retargeting.
- E-commerce examples: "Time to restock?" email 45 days after candle purchase, "You loved the Basecamp Bottle, meet the Trail Kit" cross-sell, VIP early access to seasonal drops, win-back email for customers inactive 90+ days.

**Stage 10: Advocacy**
The customer becomes an advocate who actively refers others and promotes the brand.

- Idea types: Referral programs, affiliate programs, ambassador programs, customer spotlight features, UGC campaigns, review incentives, community building, exclusive events or early access.
- Key question: What would make [persona] tell a friend "you have to buy from this store"? What makes the experience worth recommending?
- Channel fit: Email referral prompts, social media, loyalty programs, ambassador programs, word of mouth.
- E-commerce examples: "Give $10, Get $10" referral program, brand ambassador program for superfans, customer spotlight series on Instagram, handwritten thank-you note for repeat purchasers.

---

## Idea Generation Protocol

When generating ideas for a specific online store, follow this process:

### 1. Read the Context Files
- `core/offers.md` -- what they sell, pricing, collections, hero products
- `core/persona.md` -- who they sell to, pain points, desires, shopping behavior
- `core/brand-voice.md` -- how they communicate
- Marketing Channels table from progress.md -- where they're active

### 2. Walk Through All 10 Stages
For each stage, ask:
- Does this store have ANYTHING addressing this stage right now?
- If yes: can it be improved, expanded, or repurposed?
- If no: what's the highest-impact thing they could create for this stage?
- Is there a specific customer pain point from the persona that maps to this stage?
- Is there a specific product or collection that fits this stage?

### 3. Apply the Specificity Test
Every idea must reference at least one of:
- A specific product, collection, or offer from offers.md
- A specific pain point or quote from persona.md
- A specific marketing channel the store uses
- A specific seasonal moment, audience behavior, or market gap from intake

If an idea doesn't pass this test, rewrite it until it does or discard it.

### 4. Balance the Mix
- At least half the ideas should be executable this week with Claude's help
- Include a mix of content creation (blog, social, email), conversion optimization (product pages, checkout, cart recovery), and system building (sequences, automation, workflows)
- Don't over-index on one channel. Spread across the channels the store actually uses.
- Include at least one idea per objective. Aim for 3-5 per objective.

### 5. Prioritize by Impact
Within each objective, lead with the highest-impact idea. Impact = (size of the gap) x (ease of execution) x (relevance to persona's most acute pain point).

### 6. Apply E-Commerce Compliance Filters
Before finalizing any idea, run it through these checks:

- **Review authenticity:** Does this idea suggest incentivizing specifically positive reviews? If yes, redesign to incentivize all reviews equally. Offering a discount for "a review" is fine; offering one for "a 5-star review" is not.
- **FTC endorsement:** Does this idea involve influencers, affiliates, or sponsored content? If yes, include a note about required disclosure (#ad, #sponsored, material connection statement).
- **Price integrity:** Does this idea use urgency or scarcity? If yes, ensure it's based on real constraints (actual limited inventory, real deadline). Never suggest fake countdown timers or artificial scarcity.
- **Product claims:** Does this idea make specific performance, health, or outcome claims? If yes, add qualifiers or reframe as customer-reported experience rather than guaranteed results.
- **Data privacy:** Does this idea collect customer data (quizzes, giveaways, loyalty signups)? If yes, note the need for privacy policy disclosure and consent mechanisms.
- **Subscription transparency:** Does this idea involve subscriptions or auto-ship? If yes, note that terms, frequency, and cancellation must be clearly communicated.

Ideas that fail these filters should be rewritten to comply, not discarded. Most can be saved with proper framing.

---

## E-Commerce Store Patterns

Use these as pattern-matching guides, not templates. Adapt to the specific store.

### DTC Product Brand
- Awareness: brand storytelling, founder story, behind-the-scenes content, influencer seeding, SEO product guides
- Leads: quiz/product finder, discount-for-email, SMS signup for early access, seasonal gift guides
- Sales: cart abandonment sequences, product page optimization, bundle offers, limited-edition launches
- Retention: post-purchase education, replenishment reminders, loyalty program, referral rewards, VIP drops

### Multi-Brand Retailer
- Awareness: buying guides, category expertise content, brand curation stories, Google Shopping optimization
- Leads: "new arrivals" email signup, brand quiz, curated collections by use case, seasonal lookbooks
- Sales: comparison pages, staff picks, brand spotlights, free shipping threshold, cross-sell at checkout
- Retention: loyalty points across brands, personalized recommendations, seasonal re-engagement, exclusive pre-sales

### Amazon Seller
- Awareness: Amazon SEO (title, bullets, backend keywords), A+ Content, Brand Story, external traffic campaigns
- Leads: Amazon Brand Follow, "Subscribe and Save" enrollment, product insert with QR to email list (compliant with TOS)
- Sales: coupon stacking, Lightning Deals, product bundling, Enhanced Brand Content, review velocity
- Retention: Subscribe and Save optimization, brand follow notifications, product line expansion, variation strategy

### Subscription Box / Recurring
- Awareness: unboxing content, social media reveals, influencer partnerships, "what's in the box" previews
- Leads: gift subscriptions, trial boxes, "build your own" box configurator, waitlist for limited slots
- Sales: annual plan discount, gifting campaigns, seasonal themes, retention-focused onboarding
- Retention: surprise and delight moments, member community, customization options, skip-a-month flexibility, member referral bonuses

### Digital Products
- Awareness: free content that demonstrates expertise, SEO content, webinars, podcast guesting, social proof
- Leads: free mini-course, template downloads, challenges, free community access, sample lessons
- Sales: launch sequences, webinar funnels, payment plans, limited-time bonuses, testimonial-driven content
- Retention: alumni community, advanced courses, certification, coaching upsell, affiliate program, course updates
