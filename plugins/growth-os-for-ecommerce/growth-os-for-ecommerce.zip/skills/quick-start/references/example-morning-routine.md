You are running the store owner's morning routine. Execute each step below in order, presenting everything in a single warm, flowing response.

## Step 1: Greeting
Greet the user by name with a warm, energized good morning. Keep it natural and uplifting. Vary the greeting so it doesn't feel robotic day to day.

## Step 2: Day and Date
Tell the user what day of the week it is, the full date, and the current time. Use the Bash tool to run `TZ='America/New_York' date` to get the accurate current day, date, and time in Eastern Time.

## Step 3: Affirmation
Transition with something like "Before we dive in, take a breath and read this out loud:" Then present the following affirmation in a clean, readable format:

---

I'm building something people love. Every order is someone choosing my brand over a thousand other options. I trust my products, I trust my instincts, and consistent effort in marketing compounds over time. Today I will focus on what moves the store forward and let go of what doesn't.

---

After the affirmation, add one brief encouraging line, then move on.

**Note for the Quick Start Skill:** This affirmation is written to work across e-commerce store types (DTC brands, multi-brand retailers, Amazon sellers, digital product creators). When building the morning routine during setup, personalize it based on the store's mission and the user's language. A subscription box founder might prefer "Every box I ship makes someone's day." An Amazon seller might prefer something about winning the Buy Box and outpacing competitors. Adapt to fit.

## Step 4: Today's Weather
Use the WebSearch tool to search for "weather today [City] [State]" and then use WebFetch on a detailed forecast page to get specifics. Present today's weather as a clean summary:

- High / Low
- Feels like
- Sky conditions
- Chance of precipitation
- Wind

Use short, scannable lines. Just the data.

## Step 5: Calendar Overview
Use any available Google Calendar MCP tools to pull calendar events. Present:

**Today's Schedule:**
List each meeting/event with time, title, and attendees. If no events, say "No meetings today."

**Tomorrow's Schedule:**
Same format. If nothing, say so.

If Google Calendar tools are not available, skip this step and let the user know the calendar connector may need to be reconnected.

## Step 6: Sales Snapshot
If the user has connected their e-commerce platform (Shopify, WooCommerce, etc.) via MCP or API, pull key metrics:
- Yesterday's revenue
- Orders placed
- Average order value
- Top-selling product

If no platform connection is available, skip and note: "Sales snapshot skipped. Connect your Shopify or e-commerce platform for daily sales data."

## Step 7: Task Briefing
Check for any task files in the workspace. If a TASKS.md or similar exists, present the top open items. If not, skip this section.

Present open tasks sorted by priority, with due dates highlighted if any are today or overdue.

## Step 8: Suggested Tasks
Read all files in the workspace (core docs, any workflows, any recent outputs). Based on the current state of the store's marketing, the customer persona's pain points, any active workflows, and what hasn't been done recently, suggest 3 specific tasks the user could tackle today. Present them as numbered options, each with a one-sentence description of what it is and why it matters right now.

E-commerce-specific suggestion categories to rotate through:
- **Product content:** Product descriptions, collection pages, photography direction, A+ content
- **Email marketing:** Campaign drafts, flow optimization, welcome sequence, abandoned cart tweaks
- **Social content:** Instagram posts, TikTok scripts, Pinterest pins, UGC campaigns
- **Conversion optimization:** Product page improvements, checkout friction reduction, bundle offers
- **Customer retention:** Review requests, loyalty program updates, win-back campaigns, cross-sell sequences
- **Seasonal planning:** Upcoming holiday prep, seasonal product launches, sale planning

These should feel like a smart marketing colleague saying "here's what I'd work on today if I were you." Vary the suggestions day to day. Don't repeat the same three every morning.

## Step 9: Wrap-Up
Close with a quick summary: "[N] meetings today, [N] open tasks, 3 suggested tasks above. What do you want to start with?"

---

## Notes for the Quick Start Skill

This example shows a fully built morning routine for an e-commerce store owner. When building a routine during the Quick Start, adapt based on what the user told you:

- **Affirmation section** is optional. Only include if the user requested it.
- **Weather section** uses the city they provided. Swap the timezone in the Bash command to match.
- **Calendar section** only works if Google Calendar MCP tools are connected. If not connected, note that and skip.
- **Sales Snapshot** is e-commerce-specific. Include it by default for store owners. Ask during setup: "Want me to pull your daily sales numbers each morning?" If the user's platform isn't connected, note it and offer to revisit when it is.
- **Task section** only works if task files exist. For new workspaces, this section will be empty on day one but becomes useful as the workspace grows.
- **Suggested Tasks** section is always included. Even on day one, Claude can suggest tasks based on what was set up during the Quick Start. Rotate through e-commerce-specific categories: product content, email, social, conversion, retention, and seasonal planning.
- **Scheduling:** After building the routine, offer to schedule it using `create_scheduled_task`. Example cron for 8am weekdays in the user's local timezone: `0 8 * * 1-5`. The cron is evaluated in the user's local machine timezone, not UTC.
