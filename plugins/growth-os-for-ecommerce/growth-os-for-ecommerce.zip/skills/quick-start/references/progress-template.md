# Growth OS for E-Commerce -- Quick Start Progress

> This file tracks your setup progress across sessions. Claude reads it at the start of every session to know where you left off.

Started: [DATE]
Last updated: [DATE]

---

## Setup Info

- **User name:** [NAME]
- **Store name:** [STORE_NAME]
- **Source context:** [own_store / aspirational_store]
- **Aspirational store (if applicable):** [STORE_NAME_OR_N/A]
- **Setup mode:** [speed / precision]
- **Explain mode:** [transparent / just_do_it]

---

## Tier 1: Core Setup (Required)

- [ ] **Getting to Know Your Store**
  - [ ] Preferences set (setup mode + explain mode)
  - [ ] Website crawled
  - [ ] E-commerce platforms and channels discovered
  - [ ] Assets uploaded and processed
  - [ ] Marketing channels recorded
- [ ] **Mapping Your Product Catalog** -- Products, collections, pricing, and positioning (`core/offers.md`)
- [ ] **Defining Your Ideal Customer** -- Ideal customer with pain/pleasure quotes (`core/persona.md`)
- [ ] **Capturing Your Brand Voice** -- Brand writing style guide from sample or assets (`core/brand-voice.md`)
- [ ] **Building Your Daily Store Gameplan** -- Personalized daily briefing (`routines/morning-routine.md`)
  - [ ] Scheduled via `create_scheduled_task` (time: [TIME], days: [DAYS])
- [ ] **Wiring It All Together** -- CLAUDE.md operational guide ties it all together
- [ ] **Growth Ideas for Your Store** -- Growth ideas generated, favorites selected, task tracking set up
  - [ ] Growth ideas generated and presented
  - [ ] User selected favorites
  - [ ] First workflow built (if applicable)
  - [ ] Task tracking set up (format: [checklist/objective/external])
  - [ ] TASKS.md created and seeded
  - [ ] /tasks slash command created
- [ ] **Quick Start Complete** -- All Tier 1 items finished

## Tier 2: Enhancements (Optional)

- [ ] **Store Info** -- Full store context (`core/business-info.md`)
- [ ] **Brand Design** -- Visual identity guide (`core/brand-design.md`)
- [ ] **Content Rules** -- Global writing standards with compliance notes (`core/content-rules.md`)

---

## Asset Inventory

Track what was collected during intake so later phases can reference it.

| Asset | Source | Notes |
|---|---|---|
| Website crawl | [URL] | [what was found] |
| [Social profile 1] | [URL or N/A] | [what was found] |
| [Social profile 2] | [URL or N/A] | [what was found] |
| [uploaded file 1] | User upload | [what it contained] |
| [uploaded file 2] | User upload | [what it contained] |

---

## Marketing Channels & Tactics

Track every marketing channel and tactic discovered during setup, whether from the website crawl, social profiles, uploaded assets, or conversation. Even if Claude cannot access the platform, record that the store uses it. This feeds into workflow suggestions (Phase 7) and the CLAUDE.md.

| Channel / Tactic | Source | Notes |
|---|---|---|
| [e.g., Instagram] | Website crawl | [link found in footer] |
| [e.g., Klaviyo email] | User mentioned | [primary email platform] |
| [e.g., Google Shopping] | Social discovery | [product feed active] |
| [e.g., SMS / Postscript] | User mentioned | [cart recovery + drops] |

---

## Growth Ideas (from Phase 7)

The user selected these ideas from the growth ideas list. Others are saved in `growth-ideas.md` for future reference.

| # | Idea | Objective | Status |
|---|------|-----------|--------|
| [N] | [Idea title] | [Awareness/Leads/Sales/Retention] | [Selected / Workflow built / Task created] |

---

## Session Log

| Date | Steps Completed | Status | Notes |
|---|---|---|---|
| [DATE] | [e.g., Steps 1-3] | [In Progress / Complete] | [What happened, any items deferred] |
