# Ideal Customer Persona -- Ember and Oak

> This document defines who we create content for, what language resonates with them, and what motivates them to act. Claude reads this before writing any customer-facing content.

Last updated: March 2026

---

## Meet Jordan

**Full archetype:** Jordan, the Intentional Homebody

**Demographics:** 28-42 years old. Urban or suburban professional. Household income $65K-$130K. Rents or owns a home/apartment they take pride in. Follows home decor accounts on Instagram and Pinterest. Buys based on aesthetics and values, not just price. Active online shopper, primarily mobile.

**One-line description:** A design-conscious home enthusiast who researches products carefully, reads reviews before buying, and gravitates toward brands with a clear point of view and clean ingredients.

---

## What Jordan Wants

- A home that feels curated and intentional, not cluttered or generic
- Products made with clean, transparent ingredients (no mystery chemicals)
- To discover brands that feel personal, not corporate
- Gift options that are thoughtful and reliable (not another gift card)
- A shopping experience that feels easy, beautiful, and trustworthy

## What Frustrates Jordan

- Mass-produced candles that smell artificial and burn unevenly
- Brands that look great on Instagram but disappoint in real life (packaging over substance)
- Not knowing what's actually in the products they bring into their home
- Paying premium prices for products that don't last or don't deliver on their promise
- Generic product descriptions that say nothing useful ("our candle will transform your space!")
- Shopping experiences cluttered with popups, upsells, and pressure tactics

---

## Pain Points with Quote Tables

Each pain point includes quotes written in Jordan's voice, showing what they say when struggling (pain) and what they would say once the problem is solved (pleasure).

### Pain Point 1: Quality and ingredient transparency

| Pain Quote | Pleasure Quote |
|---|---|
| "I bought a $45 candle that smelled amazing for 10 minutes, then nothing. Sixty-five hours my burn time." | "My Ember and Oak candle is on hour 40 and the scent fills the whole room. Finally, a candle that delivers." |
| "I flipped the label and it just said 'fragrance blend.' What does that even mean?" | "Soy wax, cotton wick, phthalate-free fragrance. I know exactly what I'm burning in my living room." |
| "Every candle brand says 'clean' and 'natural' but none of them list their actual ingredients." | "They list every ingredient on the website and explain why each one matters. That's how you earn trust." |
| "I've wasted so much money on candles that look good on the shelf but burn terribly." | "The ceramic vessel is so beautiful I reuse them as planters. Nothing goes to waste." |

### Pain Point 2: Finding brands that aren't generic

| Pain Quote | Pleasure Quote |
|---|---|
| "Every candle on Amazon looks the same. White label, 'luxury scent,' no personality." | "Ember and Oak has a vibe. You can tell real people make this stuff. The newsletter reads like a letter from a friend." |
| "I want to support small brands but it's so hard to find ones that are actually good." | "I found them through an Instagram ad and I've ordered four times since. They're my go-to now." |
| "DTC brands all blend together. Same fonts, same website template, same hollow 'brand story.'" | "Their brand story is genuine. You can tell they care about what they make, not just what they sell." |
| "I want my home to reflect my taste, not look like everyone else's Target haul." | "When friends come over, they always ask about the candle. It's become my thing." |

### Pain Point 3: Gift-giving anxiety

| Pain Quote | Pleasure Quote |
|---|---|
| "I need a housewarming gift and I've been scrolling for an hour. Nothing feels right." | "The Discovery Set is my go-to gift. Beautiful packaging, three great scents, never fails." |
| "Gift cards feel lazy but I never know what people actually want." | "I sent the Cozy Night In set to my sister and she texted me photos of it lit that same evening." |
| "I'm tired of giving things that end up in a drawer." | "Everyone uses candles. It's the one gift that always works, especially when the quality is this good." |

### Pain Point 4: Online shopping trust

| Pain Quote | Pleasure Quote |
|---|---|
| "I hate ordering from a brand I've never heard of. What if it's terrible?" | "The reviews were genuine and detailed. Real people, real photos. That's what convinced me to try it." |
| "Shipping took three weeks and the customer service email bounced. Never again." | "Order shipped same day, arrived in two days, and the unboxing experience was beautiful." |
| "Returns are always such a hassle with small brands." | "They have a no-questions-asked return policy. I've never had to use it, but knowing it's there matters." |
| "Every website says 'handmade with love.' Show me, don't tell me." | "Their Instagram stories show the actual pouring process. You can see the hands making your candle." |

### Pain Point 5: Sustainability guilt

| Pain Quote | Pleasure Quote |
|---|---|
| "I feel guilty buying candles that come in containers I'll just throw away." | "The ceramic vessel is designed to be reused. Mine is a succulent planter now." |
| "I want to buy sustainable but I can't afford to pay 3x the price for everything." | "$38 for 65 hours of burn time and a reusable vessel? That's actually a better deal than the cheap ones." |
| "Soy, beeswax, coconut? I don't even know which is better for the environment." | "They explain their material choices on the website without being preachy about it. Informed, not guilt-tripped." |

---

## Decision Factors (How Jordan Chooses a Product)

1. **Visual first impression** -- Product photography, website design, and Instagram aesthetic must feel curated and intentional
2. **Ingredient transparency** -- Clear, honest labeling. No "fragrance blend" without explanation
3. **Reviews with photos** -- Looks for customer photos and detailed written reviews, not just star ratings
4. **Price-to-value ratio** -- Willing to pay premium for quality, but the value must be demonstrable (burn time, reusable vessel, etc.)
5. **Brand personality** -- Gravitates toward brands with a distinct voice and genuine story
6. **Gifting potential** -- Considers whether the packaging and presentation are gift-worthy

## Language Notes

- Jordan says "vibe" and "aesthetic" not "brand identity" or "product positioning"
- Jordan says "clean" to mean free of harmful ingredients, not minimalist design
- Responds to lifestyle language: "cozy," "intentional," "ritual," "slow living"
- Values authenticity; allergic to corporate-speak and buzzwords like "disrupting" or "revolutionary"
- Shops on Instagram and Pinterest. Checks reviews on the product page. Reads email newsletters from brands they love.
- Follows home decor, slow living, and design accounts. Reads Apartment Therapy, The Kitchn, Cup of Jo.
