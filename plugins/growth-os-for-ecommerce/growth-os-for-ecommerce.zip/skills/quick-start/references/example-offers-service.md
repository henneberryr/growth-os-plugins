# Products & Offers -- TrailPeak Outfitters

> This document is the reference Claude reads whenever it needs to understand what we sell, who it's for, and how to position it. Keep it updated when inventory or pricing changes.

Last updated: March 2026

---

## About the Store

TrailPeak Outfitters is a curated multi-brand online retailer specializing in outdoor gear and apparel for weekend adventurers. We don't manufacture products. We curate: hand-picking gear from trusted brands and presenting it alongside expert buying advice so customers can make confident choices.

---

## Collection: Hiking Essentials

Our bread-and-butter category. Core gear for day hikes and weekend trips.

### Key Products

- **Day packs (8 brands)** -- Osprey, Deuter, Gregory, and others. Range: $65-$180. Best seller: Osprey Daylite Plus ($85).
- **Hiking boots and trail runners (6 brands)** -- Salomon, Merrell, Hoka, KEEN. Range: $90-$200.
- **Trekking poles** -- Black Diamond and Leki. Range: $40-$130.
- **Hydration** -- Water bottles (Hydro Flask, Nalgene), filtration (Sawyer, LifeStraw). Range: $12-$55.

**Who it's for:** Weekend hikers and trail walkers who want reliable gear without spending hours researching.

**Positioning:** "We did the research so you don't have to." Product pages include buying guides, comparison tables, and "TrailPeak Pick" editor's choice badges.

---

## Collection: Camp & Cook

Car camping and backpacking kitchen gear.

### Key Products

- **Camp stoves** -- Jetboil, MSR, Snow Peak. Range: $35-$250.
- **Cooksets and utensils** -- Stanley, Sea to Summit, GSI Outdoors. Range: $15-$85.
- **Camp furniture** -- Helinox, REI Co-op. Chairs and tables. Range: $50-$180.
- **Coolers** -- YETI, RTIC, Igloo Trailmate. Range: $40-$350.

**Who it's for:** Car campers and weekend trip planners who want the right setup without overbuying.

---

## Collection: Apparel & Layers

Performance clothing curated for trail and camp.

### Key Products

- **Base layers** -- Smartwool, Patagonia, icebreaker. Range: $45-$120.
- **Rain gear** -- Outdoor Research, Marmot, Arc'teryx. Range: $80-$300.
- **Fleece and insulation** -- Patagonia, The North Face, Cotopaxi. Range: $60-$200.

**Positioning:** "Layer smart, not heavy." Seasonal layering guides drive traffic and educate buyers.

---

## Collection: Trail Tech

Electronics and gadgets for the trail.

### Key Products

- **GPS and navigation** -- Garmin. Range: $150-$500.
- **Headlamps** -- Petzl, Black Diamond, BioLite. Range: $25-$80.
- **Solar chargers and power banks** -- Goal Zero, Anker. Range: $30-$150.
- **Satellite communicators** -- Garmin inReach. Range: $300-$400.

---

## TrailPeak Starter Kit (Curated Bundle)

**What it is:** A curated beginner kit assembled by the TrailPeak team: one day pack, one water bottle, one headlamp, and a trail snack sampler, packaged with a printed "Your First Trail" getting-started guide.

**Who it's for:** New hikers or gift-givers buying for someone getting into hiking.

**Pricing:** $149 (saves ~$25 vs. buying individually)

**Positioning:** "Everything you need for your first trail. Zero decision fatigue." Gift-friendly. Promoted in Q4 and spring.

---

## Free Offer (Lead Magnet / Top of Funnel)

### The Trail Report

**What it is:** A free weekly email with gear reviews, trail recommendations, seasonal packing lists, and community adventure stories.

**Who it's for:** Outdoor enthusiasts who want curated gear advice they can trust, from a team that actually hikes.

**Frequency:** Weekly (Thursdays)

**Positioning:** Not a product catalog. Every issue teaches something useful about gear or trails. Products are featured through real-use reviews and honest recommendations, not hard sells.

**CTA to products:** "Shop the gear from this issue" link at the bottom. New gear drops and exclusive bundles announced to the list first.

---

## Offer Hierarchy

```
The Trail Report (free) -> TrailPeak Starter Kit ($149) -> Individual products ($12-$500) -> Seasonal bundles
```

Content drives discovery through buying guides, gear reviews, and trail recommendations. Trust is built by being honest about products (including mentioning competitors when they are better for a specific use case). The email list gets early access to bundles and limited releases.

---

## Key Metrics to Reference

- Average order value: $87
- Repeat customer rate: 22%
- Email-attributed revenue: 28% of total
- Best acquisition channel: Google organic (buying guide SEO) + email
- Top traffic driver: "Best [product] for [use case]" blog posts
- Review count: 1,200+ across products (4.6 avg)
