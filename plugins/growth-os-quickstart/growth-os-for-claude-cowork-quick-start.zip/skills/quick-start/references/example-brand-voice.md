# Brand Voice Guide -- Greenline Digital

> This document tells Claude how to write in Jamie's voice. Read it before producing any audience-facing content.

Last updated: February 2026

---

## Voice Summary

Jamie's writing voice is direct, practical, and slightly irreverent. It sounds like a smart friend who happens to know a lot about B2B marketing, talking to you over coffee. Not a professor. Not a guru. Not a corporate blog.

## Core Traits

1. **Direct.** Get to the point. No throat-clearing. The first sentence should hit.
2. **Practical.** Every post should teach something you can use this week. Theory is only useful when it leads to action.
3. **Slightly irreverent.** Willing to poke fun at marketing conventions, call out what doesn't work, and break from the expected. Not edgy for the sake of it, just honest.
4. **Specific.** Use real numbers, real examples, real tools. "We got 47 demos from 12 LinkedIn posts" beats "content marketing drives results."
5. **Conversational.** Write like you talk. Contractions, short sentences, sentence fragments when they land. Formal grammar is less important than clarity and rhythm.

## Vocabulary Preferences

**Use these:**
- Pipeline, demos, revenue (concrete business language)
- "Here's what worked" / "Here's what didn't"
- "Let me show you" / "Try this"
- Short, punchy verbs: ship, build, test, cut, fix

**Avoid these:**
- "Leverage," "synergy," "ecosystem" (corporate fluff)
- "In today's fast-paced digital landscape" (cliche openers)
- "Unlocking," "supercharging," "game-changing" (hype words)
- "Dear reader" or "you guys" (too formal or too casual)

## Sentence Patterns

- **Lead with the point.** "LinkedIn posts don't generate pipeline. LinkedIn conversations do."
- **Short, then long.** Alternate between punchy single-clause sentences and longer ones that develop the idea.
- **Fragment for emphasis.** "Thirty blog posts. Zero demos. Sound familiar?"
- **Questions as transitions.** "So what actually works?" to bridge between sections.

## Things to Avoid

- Opening with a generic statement about the state of the industry
- Using more than one exclamation point per post
- Hedging with "I think" or "in my opinion" when stating a position (just state it)
- Lists longer than 5 items (if it's more, group or prioritize)
- Paragraphs longer than 4 sentences

## Before/After Example

**Generic (not Jamie's voice):**
> At Greenline Digital, we believe that SaaS founders can significantly improve their pipeline generation by implementing a structured content marketing approach. Our coaching methodology helps clients develop thought leadership strategies that attract qualified prospects and drive meaningful business outcomes.

**Jamie's voice:**
> Most SaaS founders treat content like homework: write a blog post, check the box, hope someone reads it. That's not a strategy. That's a lottery ticket. Here's what I tell every founder in my coaching program: one channel, one format, three posts a week, for 90 days. No "thought leadership." No "brand awareness." Just content that answers the exact question your buyer is Googling right before they book a demo. One client went from zero to 47 demos in 12 weeks doing exactly this.

---

## Notes for the Quick Start Skill

This example shows a fully built brand voice guide for a service-based business. When building a voice guide during the Quick Start:

- **If the user provided a writing sample:** Analyze it for sentence patterns, vocabulary, tone, and rhetorical habits. The voice guide should reflect THEIR actual voice, not a generic "professional" voice. The before/after example should use a generic version of their content versus the improved version.
- **If no writing sample:** Build from whatever text-heavy assets were collected during intake (website copy, social posts, email campaigns). Note in the doc that it's based on collected assets and can be refined with a direct writing sample later.
- **Core structure to always include:** Voice summary (2-3 sentences), 3-5 core traits, vocabulary preferences (use/avoid), sentence patterns, things to avoid, and at least one before/after example.
- **The user's self-description matters.** During the interview, ask "In 3-5 words, how would you describe your writing style?" and "What tone do you want to AVOID?" These answers anchor the voice guide.
