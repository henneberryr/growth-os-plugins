# Products & Offers -- Nomad Gear Co.

> This document is the reference Claude reads whenever it needs to understand what we sell, who it's for, and how to position it. Keep it updated when pricing or inventory changes.

Last updated: March 2026

---

## Product Line: Trail Essentials

Our core line of outdoor accessories designed for weekend adventurers. Everything is lightweight, durable, and tested on real trips before it ships.

### Flagship Product: The Basecamp Bottle (32 oz)

**What it is:** A double-walled insulated water bottle with a magnetic lid system and built-in carabiner loop.

**Who it's for:** Weekend hikers, car campers, and outdoor enthusiasts who want gear that works without fussing with it.

**Pricing:** $42 (retail)

**What makes it different:**
- Magnetic lid snaps shut one-handed (no threading while wearing gloves)
- Keeps drinks cold 24 hours, hot 12 hours
- Powder-coated in 6 nature-inspired colors
- Lifetime warranty against manufacturing defects

**Best seller.** Accounts for 40% of total revenue.

---

### The Trail Kit (accessories bundle)

**What it is:** A curated set of three accessories: insulated bottle sleeve, collapsible cup, and waterproof dry bag (3L).

**Who it's for:** Customers who already own the Basecamp Bottle or are buying for someone who loves the outdoors.

**Pricing:** $68 (bundle) / $28-$32 individually

**Positioning:** "Everything you forgot to pack." Gift-friendly. Strong Q4 performer.

---

### Seasonal Drops

**What it is:** Limited-edition colorways and collaborations released quarterly. Past drops: National Parks Collection, Artist Series with local illustrators.

**Who it's for:** Existing customers and collectors. Drives repeat purchases and urgency.

**Pricing:** $48-$58 (premium over standard)

**Positioning:** Limited runs. When they sell out, they are gone. Announced to email list first.

---

## Free Offer (Lead Magnet / Top of Funnel)

### The Weekend Dispatch

**What it is:** A free weekly email with trail recommendations, gear tips, and adventure stories from the Nomad Gear community.

**Who it's for:** Outdoor enthusiasts who buy gear based on trust and community, not just price.

**Frequency:** Weekly (Fridays)

**Positioning:** Not a product catalog. Every issue is something worth reading even if you never buy a thing. Products are woven in naturally, not pitched.

**CTA to products:** "Shop the gear mentioned in this issue" link at the bottom. Seasonal drops announced via email first.

---

## Offer Hierarchy

```
The Weekend Dispatch (free) -> Basecamp Bottle ($42) -> Trail Kit ($68) -> Seasonal Drops ($48-$58)
```

Content should build trust and community first. Product recommendations are earned through useful content, not pushed through discounts. The email list gets first access to everything.

---

## Key Metrics to Reference

- Average order value: $54
- Repeat customer rate: 28%
- Email-attributed revenue: 35% of total
- Best acquisition channel: Instagram (organic) + email
