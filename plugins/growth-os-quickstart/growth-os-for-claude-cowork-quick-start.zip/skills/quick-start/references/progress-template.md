# Growth OS for Claude Cowork -- Quick Start Progress

> This file tracks your setup progress across sessions. Claude reads it at the start of every session to know where you left off.

Started: [DATE]
Last updated: [DATE]

---

## Setup Info

- **User name:** [NAME]
- **Business name:** [BUSINESS_NAME]
- **Source context:** [own_business / aspirational_business]
- **Aspirational business (if applicable):** [BUSINESS_NAME_OR_N/A]
- **Setup mode:** [speed / precision]
- **Explain mode:** [transparent / just_do_it]

---

## Tier 1: Core Setup (Required)

- [ ] **Getting to Know Your Business**
  - [ ] Preferences set (setup mode + explain mode)
  - [ ] Website crawled
  - [ ] Social profiles discovered
  - [ ] Assets uploaded and processed
  - [ ] Marketing channels recorded
- [ ] **Mapping What You Sell** -- Products/services, pricing, and positioning (`core/offers.md`)
- [ ] **Defining Who You Sell To** -- Ideal customer with pain/pleasure quotes (`core/persona.md`)
- [ ] **Capturing Your Voice** -- Writing style guide from sample or assets (`core/brand-voice.md`)
- [ ] **Building Your Daily Gameplan** -- Personalized daily briefing (`routines/morning-routine.md`)
  - [ ] Scheduled via `create_scheduled_task` (time: [TIME], days: [DAYS])
- [ ] **Wiring It All Together** -- CLAUDE.md operational guide ties it all together
- [ ] **Growth OS Has Ideas to Grow Your Business** -- Growth ideas generated, favorites selected, task tracking set up
  - [ ] Growth ideas generated and presented
  - [ ] User selected favorites
  - [ ] First workflow built (if applicable)
  - [ ] Task tracking set up (format: [checklist/objective/external])
  - [ ] TASKS.md created and seeded
  - [ ] /tasks slash command created
- [ ] **Quick Start Complete** -- All Tier 1 items finished

## Tier 2: Enhancements (Optional)

- [ ] **Business Info** -- Full business context (`core/business-info.md`)
- [ ] **Brand Design** -- Visual identity guide (`core/brand-design.md`)
- [ ] **Content Rules** -- Global writing standards (`core/content-rules.md`)

---

## Asset Inventory

Track what was collected during intake so later phases can reference it.

| Asset | Source | Notes |
|---|---|---|
| Website crawl | [URL] | [what was found] |
| [Social profile 1] | [URL or N/A] | [what was found] |
| [Social profile 2] | [URL or N/A] | [what was found] |
| [uploaded file 1] | User upload | [what it contained] |
| [uploaded file 2] | User upload | [what it contained] |

---

## Marketing Channels & Tactics

Track every marketing channel and tactic discovered during setup, whether from the website crawl, social profiles, uploaded assets, or conversation. Even if Claude cannot access the platform, record that the business uses it. This feeds into workflow suggestions (Phase 7) and the CLAUDE.md.

| Channel / Tactic | Source | Notes |
|---|---|---|
| [e.g., Facebook] | Website crawl | [link found in footer] |
| [e.g., Email newsletter] | User mentioned | [uses Mailchimp] |
| [e.g., Direct mail] | Uploaded brochure | [postcard for seasonal promos] |
| [e.g., YouTube] | Social discovery | [URL, what was found] |

---

## Growth Ideas (from Phase 7)

The user selected these ideas from the growth ideas list. Others are saved in `growth-ideas.md` for future reference.

| # | Idea | Objective | Status |
|---|------|-----------|--------|
| [N] | [Idea title] | [Awareness/Leads/Sales/Retention] | [Selected / Workflow built / Task created] |

---

## Session Log

| Date | Steps Completed | Status | Notes |
|---|---|---|---|
| [DATE] | [e.g., Steps 1-3] | [In Progress / Complete] | [What happened, any items deferred] |
