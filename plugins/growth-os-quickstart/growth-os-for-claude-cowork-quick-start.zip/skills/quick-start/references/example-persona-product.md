# Ideal Customer Persona -- Nomad Gear Co.

> This document defines who we create content for, what language resonates with them, and what motivates them to act. Claude reads this before writing any audience-facing content.

Last updated: March 2026

---

## Meet Maya

**Full archetype:** Maya, the Stuck-at-Plateau Store Owner

**Demographics:** 28-42 years old. Runs a direct-to-consumer e-commerce brand (Shopify or similar). Revenue between $200K-$1.5M/year. Small team: herself plus 1-3 contractors. Primarily sells online. Product category: outdoor/adventure gear and accessories.

**One-line description:** An e-commerce founder with a product people love but a marketing engine that runs on hustle, not systems.

---

## What Maya Wants

- Consistent revenue that does not spike and crash with every promotion
- An email and social system that sells without her manually posting every day
- Repeat customers who buy more than once (not just one-and-done bargain hunters)
- A way to stand out in a crowded DTC market without racing to the bottom on price

## What Frustrates Maya

- Spends 3 hours a day on Instagram and can't tell if it moves the needle
- Email marketing feels spammy and she doesn't know how often to send
- Paid ads worked until they didn't, and now CAC is eating the margin
- Every marketing "expert" sells a course but none of them have run a real store
- AI tools write product descriptions that sound like every other brand on the internet

---

## Pain Points with Quote Tables

Each pain point includes quotes written in Maya's voice, showing what she says when struggling (pain) and what she would say once the problem is solved (pleasure).

### Pain Point 1: Revenue depends entirely on the founder's daily effort

| Pain Quote | Pleasure Quote |
|---|---|
| "If I don't post on Instagram today, sales drop tomorrow. It's exhausting." | "I batched two weeks of content on Sunday and sales stayed steady the whole time." |
| "I took a long weekend and revenue dropped 40%. That's not a business, that's a job." | "We went to Baja for a week and had our best Tuesday ever while I was offline." |
| "I'm the photographer, the copywriter, the customer service rep, and the shipping department." | "My content system handles the marketing so I can focus on product development." |
| "There's no 'off' switch. If I stop hustling, the store stops selling." | "Revenue is predictable now. I know within 10% what next month looks like." |

### Pain Point 2: Email list exists but doesn't convert

| Pain Quote | Pleasure Quote |
|---|---|
| "I have 8,000 subscribers and my last email made $47." | "Our weekly email averages $1,200 in revenue. It's the most reliable channel we have." |
| "I don't know what to write that isn't just 'hey, buy this.'" | "Each email teaches something useful about the outdoors and naturally leads to a product. People actually thank me for sending them." |
| "I send a newsletter when I remember to, which is maybe twice a month." | "Tuesday emails go out every week. The system drafts them, I review and send." |
| "My open rate is 18% and dropping. I think people forgot they signed up." | "Open rates are at 42% because every email has something worth reading, not just a discount code." |

### Pain Point 3: Standing out in a sea of similar brands

| Pain Quote | Pleasure Quote |
|---|---|
| "There are 500 brands selling the same water bottle with different logos." | "People buy from us because they feel like they know us. The brand voice does that." |
| "I can't compete on price with Chinese factories selling direct on Amazon." | "We don't compete on price. We compete on story, community, and the way our content makes people feel." |
| "Our product is better but nobody can tell from the listing." | "Every product page reads like a campfire story, not a spec sheet. Conversion rate went from 1.8% to 3.4%." |
| "AI-generated product descriptions make us sound like every other brand in the category." | "Claude writes in our voice. Customers say our emails feel like getting a note from a friend who happens to sell great gear." |

### Pain Point 4: Paid ads are a money pit

| Pain Quote | Pleasure Quote |
|---|---|
| "Facebook ads used to be printing money. Now I spend $3,000 a month and barely break even." | "Organic content handles awareness. We only run ads for retargeting, and ROAS is 6x." |
| "I don't know if my ad spend is working or if I'm just buying vanity metrics." | "I can tell you exactly which piece of content brought each customer in." |
| "My CAC went from $18 to $45 in two years. The math barely works." | "Our blended CAC dropped to $12 once organic content started pulling its weight." |
| "Every agency I've hired just burned through the ad budget and sent me a report full of impressions." | "I finally understand which dollars are working. The dashboard shows me real revenue per channel, not vanity metrics." |

### Pain Point 5: No system, just reactive hustle

| Pain Quote | Pleasure Quote |
|---|---|
| "My marketing strategy is 'whatever I feel like doing today.'" | "Monday is email, Wednesday is social batch, Friday is community. It runs itself." |
| "I have 14 browser tabs open and no plan for what to post this week." | "I open Claude, say 'good morning,' and it tells me exactly what to work on." |
| "Every time I try to plan ahead, something urgent pulls me back to firefighting." | "The routine keeps me proactive instead of reactive. Biggest mindset shift of the year." |

---

## Language Notes

- Maya says "revenue" and "sales" not "pipeline" or "demos" (DTC vocabulary)
- Maya says "customers" and "subscribers" not "prospects" or "MQLs"
- Maya thinks in terms of CAC, AOV, LTV, and conversion rate
- She is practical and scrappy, respects founders who have built real stores
- She reads Nik Sharma's newsletter, follows DTC Twitter, listens to Shopify Masters
- Visual thinker, product-oriented, values aesthetics and brand feel
