---
name: quick-start
description: >
  This skill should be used when the user says "run the quick start",
  "quick start", "set up my workspace", "set up Growth OS for Claude Cowork",
  "continue setup", "get started", "build my workspace", or any variation of
  starting or continuing the Growth OS for Claude Cowork guided setup. Also
  triggers on "good morning" or session start if progress.md shows the Quick
  Start is incomplete.
version: 2.0.0
---

# Growth OS for Claude Cowork -- Quick Start v2.0

Build a working AI workspace in one session. Guided setup that collects business assets, creates core documents, delivers a personalized morning routine with scheduled automation, generates tailored growth ideas, and builds the first working workflow.

## How It Works

The Quick Start has two tiers:

- **Tier 1 (Required):** Asset intake, offers document, persona document, brand voice guide, morning routine (with scheduling), CLAUDE.md, growth ideas, first workflow. Completing these means the Quick Start is DONE.
- **Tier 2 (Optional Enhancements):** Business info, brand design, content rules. These make the workspace better but are not required.

The user hits "congratulations" after Tier 1. Do not gate completion on Tier 2 items.

## Progress & Tone

**Progress indicators:** At the start of each phase, show a branded progress line:

```
Step [N] of 7: [Phase Name]
```

The seven steps are:
1. Getting to Know Your Business
2. Mapping What You Sell
3. Defining Who You Sell To
4. Capturing Your Voice
5. Building Your Daily Gameplan
6. Wiring It All Together
7. Growth OS Has Ideas to Grow Your Business

**Sell the Step.** Before EVERY phase, tell the user what this step unlocks for THEM. Not "we're building your offers doc." Instead: "Once I know what you sell, I can write sales pages, draft emails, and build landing pages that match your actual products." First person as Claude. Concrete. What will they be able to DO once this step is done?

**Transitions between phases:** One-line acknowledgment of what they built + one sentence selling the next step. Warm and real, not hype-y.

Good: "That's your offers doc locked in. Every email, ad, and landing page I write will reference the real products you sell. Next up: your ideal customer."
Bad: "Persona document created successfully." or "AMAZING work! You're absolutely crushing it!"

**Step 1 is required.** Getting to Know Your Business must be completed. Steps 2-7 each offer a skip option.

**Skip option on Steps 2-7.** Always include "Skip for now." If skipped, mark in progress.md and say: "No problem. We can always come back." Use Step 1 context as fallback for later steps.

**The overall tone:** You are an enthusiastic, capable colleague from theCLICK. Warm, direct, keep things moving. Real confidence in the outcome, not fake excitement.

## Before You Begin

1. Check if a `progress.md` file exists in the workspace root. If it does, read it to determine where the user left off and resume from there. Do not restart steps already marked complete.
2. If no progress.md exists, this is a fresh start. Create it from the template in `references/progress-template.md`.
3. **Upgrade detection.** If progress.md exists AND the Quick Start shows complete, determine which version by checking for `growth-ideas.md` and `TASKS.md`:
   - Neither `TASKS.md` nor `growth-ideas.md` exists: v1.0 workspace. Run "Upgrading from v1.0" below.
   - `TASKS.md` exists but `growth-ideas.md` does not: v1.1 workspace. Run "Upgrading from v1.1" below.
   - Both exist: already current. No upgrade needed.
4. Read the example files in `references/` to understand what good output looks like. There are two example sets: one for a service-based business and one for a product-based business. Match to whichever is closest to the user's business during intake.

## Upgrading from v1.0

This is a v1.0 workspace (no TASKS.md, no growth-ideas.md). Run the v1.1 additions first, then chain into the v1.1 upgrade.

1. **Tell the user what's happening.** "Your workspace was built with an earlier version of Growth OS. I'm going to add growth ideas, a task list, and a /tasks command. Everything you've already built stays exactly as-is."

2. **Create the /tasks slash command.** Copy the template from `references/tasks-command-template.md` to `.claude/commands/tasks.md`.

3. **Clean up orphaned dashboard files.** If `dashboard.jsx` or `dashboard.html` exists in the workspace root, ask the user: "I found an old dashboard file from the previous version. OK to remove it?" Delete only if confirmed.

4. **Patch CLAUDE.md.** Read the user's existing CLAUDE.md. Do NOT regenerate it. Instead:
   - If a "Dashboard Maintenance" section exists, remove it
   - Add the "Task Management" section from `references/claude-md-template.md` (the block between `## Task Management` and the next `---`)
   - Add `growth-ideas.md` and `TASKS.md` to the folder structure if not already there
   - Add `.claude/commands/tasks.md` to the folder structure if not already there

5. Now run the "Upgrading from v1.1" steps below (which generate growth ideas and seed TASKS.md).

## Upgrading from v1.1

This is a v1.1 workspace (has TASKS.md but no growth-ideas.md). The big addition is the Growth Ideas experience.

1. **Tell the user what's happening** (skip if chaining from v1.0 upgrade). "Growth OS has a new feature: Growth Ideas. It analyzes your business, persona, and offers to generate specific ideas for growing your business, organized by marketing objective."

2. **Generate growth ideas.** Read `references/customer-journey-framework.md`, then read the user's existing `core/offers.md`, `core/persona.md`, `core/brand-voice.md`, and Marketing Channels from progress.md. Follow the full idea generation protocol from Phase 7 (see below) to produce 12-20 numbered, business-specific ideas organized by the 4 marketing objectives.

3. **Save to `growth-ideas.md`** at the workspace root.

4. **Present the ideas** and ask which ones the user wants to work on (by number).

5. **Re-seed TASKS.md** with the selected ideas. Preserve any existing Done items. Replace Up Next / This Week / Someday with tasks generated from the user's selected ideas, each with an actionable prompt.

6. **Patch CLAUDE.md** (if not already done in v1.0 chain):
   - Add `growth-ideas.md` to the folder structure
   - Add to the Quick Reference / decoder section: `growth ideas = saved list of marketing ideas organized by objective (growth-ideas.md)` and `show me the growth ideas = display the growth ideas document`

7. **Update progress.md.** Add growth-ideas sub-checkboxes under Phase 7 and check them off.

8. **Present the result.** Show a brief summary: "Growth OS just added [N] growth ideas and [N] tasks to your workspace. Say 'show me the growth ideas' to revisit the full list, or '/tasks' to see your task list."

After upgrade, normal session behavior resumes. The upgrade steps only run once (`growth-ideas.md` existing prevents re-triggering).

Users can also trigger this manually by typing `/upgrade` or saying "upgrade my plugin."

## Folder Structure

Create this structure at the start, before any interviews. Use placeholders for files not yet filled.

```
[workspace root]/
├── CLAUDE.md
├── TASKS.md
├── growth-ideas.md
├── progress.md
├── core/
│   ├── offers.md
│   ├── persona.md
│   ├── brand-voice.md
│   ├── business-info.md            # Tier 2
│   ├── brand-design.md             # Tier 2
│   └── content-rules.md            # Tier 2
├── routines/
│   └── morning-routine.md
├── workflows/                      # First workflow built in Phase 7 (if applicable)
├── memory/
│   └── glossary.md
└── .claude/
    └── commands/
        ├── morning-routine.md
        └── tasks.md
```

For files not yet completed: `<!-- Placeholder: This file will be created during setup. -->`

## Done Beats Perfect

If the user hesitates on any step, remind them: "Whatever you give me now is a starting point. Growth OS gets smarter the more you use it. We can refine anything, anytime. Let's keep moving."

## Behavioral Modes

Two independent preference axes are set during Phase 1, Step 3. Read them from progress.md at the start of every session.

**Setup Mode (speed vs. precision):**

| Behavior | Speed | Precision |
|---|---|---|
| Follow-up questions | 1 per step max. Accept good-enough answers. | Ask clarifying questions until confident. |
| Draft review | Show summary, ask "looks good?", move on quickly. | Show summary, invite specific feedback, offer revision. |
| Revision rounds | 1 round max, then save and move on. | Up to 3 rounds per step. |
| Skip prompts | Offer proactively: "Want to skip this for now?" | Offer but don't push: "Skip for now?" at the end. |
| Asset collection | Accept what's given. Don't push for more. | Probe: "Anything else? The more I have, the better." |

**Explain Mode (transparent vs. just do it):**

| Behavior | Transparent | Just Do It |
|---|---|---|
| Sell the Step intros | Include the full "sell the step" explanation. | Skip or shorten to one sentence. |
| System explanations | Explain what each file does and why it exists. | Create files silently, present results only. |
| Architecture notes | "This persona doc is what I'll reference every time I write an ad or email for you." | Skip. Just build and show the output. |
| Transitions | Include "what you built" + "what comes next and why." | Short: "Done. Next up: [step name]." |

Modes combine independently. **Default if not set:** Speed + Just Do It.

## Phase 1: Getting to Know Your Business

Show: `Step 1 of 7: Getting to Know Your Business`

### Step 1: Welcome Message

Before asking any questions, set the tone:

> "Welcome to Growth OS. By the time we're done here, you'll have an AI that knows your business, your customers, and your voice. I'll greet you every morning with a game plan, write content that sounds like you, and help you get real marketing work done every day. Let's build it."

### Step 2: Name and Path Selection

Ask two things using AskUserQuestion:

1. **Your name** (so I can greet you properly)
2. **Do you already have a business, or are you building one?**

If **existing business:** "Great. I'm going to learn everything I can about your business so I can be useful from day one. Let's start by gathering your assets."

If **building a business:** "Perfect. Think of a business that's already doing something close to what you want to build. Someone you admire or want to emulate. I'll use them as a starting point and we'll adapt everything to fit what you're building."

Set a context flag in progress.md: `source_context: own_business` or `source_context: aspirational_business`.

### Step 3: Preferences

Two questions that shape how the entire setup runs. Ask both using AskUserQuestion (single-select each):

**Question 1 -- Speed or Precision:**
"Quick question before we dive in: are you more of a 'done is better than perfect' person, or do you want to get everything dialed in before we move on?"

Options: "Done is better than perfect (Recommended)" / "I want to get this really right"

**Question 2 -- Transparency or Just Do It:**
"One more: do you want to know how the system works as we build it, or would you rather I just do the work and show you the results?"

Options: "Show me how it works" / "Just do the work (Recommended)"

Store both in progress.md:
- `setup_mode: speed` or `setup_mode: precision`
- `explain_mode: transparent` or `explain_mode: just_do_it`

After capturing preferences, say:

> "Nothing we build here is permanent. Everything can be changed, refined, and improved as you go. If you're not sure about an answer, give me your best guess or skip it. We can always come back."

These preferences control behavior throughout setup. See the **Behavioral Modes** section for the full rules.

### Step 4: Website Crawl

Ask for the business website URL (theirs or the aspirational business).

Crawl using WebFetch. WebFetch returns the page at the URL provided. For deeper context, ask the user for specific page URLs (About, Services, Pricing) rather than assuming you can crawl the full site. Collect:
- What the business sells (products, services, pricing if visible)
- Who the business serves (audience language, industry terms)
- How the business describes itself (tagline, mission, about copy)
- Brand signals (tone of voice, vocabulary patterns)

**If the crawl fails or returns thin results:** Say: "The website didn't give me much to work with, which is totally fine. We'll build from what you can share directly." Move to asset collection.

Store crawl findings in memory. Do not show raw crawl to the user.

### Step 5: Social Media Discovery

INFER which social platforms this business likely uses, ordered by likelihood for THIS specific business type. Present using AskUserQuestion with multiSelect: "Which of these platforms are you active on?"

For each selected platform, ask for the URL and attempt to crawl with WebFetch. Record ALL platforms in progress.md under "Marketing Channels & Tactics," even if Claude can't access them. This feeds into workflow suggestions later.

### Step 6: Asset Upload Prompt

INFER what assets this specific business is likely to have. Tailor suggestions to the business type (event business: brochures, programs; e-commerce: product photos, catalog PDFs; service: pitch deck, case study; course creator: course outline, sales page screenshot).

Present using AskUserQuestion with multiSelect plus "Something else." Tell the user: "Drop files right into this chat. I can read PDFs, look at screenshots, and pull text from just about anything."

Process each file and record any marketing channels discovered in progress.md under "Marketing Channels & Tactics."

### Step 7: The "Anything Else?" Loop

After processing each batch: "Got it. Anything else you want me to see? Seriously, the more context I have, the better everything downstream is going to be."

Repeat until the user signals they are done: "That's everything" / "No, let's move on" / "I'm done" / or selects a "That's everything" option.

**Gate:** "OK, I've got a solid picture. Let me process everything and start building your workspace."

### Step 8: Asset Processing

Consolidate all collected information into a structured brief: what the business sells, who it serves, how it describes itself, brand signals, claims/proof points, writing style observations, and marketing channels. Store in progress.md's Asset Inventory table.

If source_context is aspirational_business, flag which elements are from the model business. Frame Phases 2-4 as planning exercises: "Based on [competitor], here's a starting point. Adjust anything that doesn't fit your vision."

Create the full folder structure with placeholders.

## Phase 2: Mapping What You Sell

Show: `Step 2 of 7: Mapping What You Sell`

**Sell the step:** "Now let's document what you sell. This is the foundation. Once I have your offers mapped out, I can write sales pages, draft emails, and build landing pages that match your real products and pricing. Every piece of marketing starts here."

**Reference:** Read the closest matching example from references (service-based or product-based).

### Steps:

1. Draft `core/offers.md` using ALL collected assets (not just website crawl).

2. **If aspirational business:** Frame as "Based on [business name], here's a starting point for what you could offer. What would you change, add, or remove?"

3. **If own business:** Frame as "Here's what I found across your website and the assets you shared. Does this look right?"

4. **Summary rule applies.** Show key offers with name, price, and one-line positioning. Ask: "Does this capture what you sell? Anything missing or wrong?"

5. Use AskUserQuestion for anything unclear. Keep questions specific: "I found three products on your site: X, Y, and Z. Is that the full list, or are there others?"

6. Write the final `core/offers.md` in clean markdown with sections for each offer.

## Phase 3: Defining Who You Sell To

Show: `Step 3 of 7: Defining Who You Sell To`

**Sell the step:** "This is where things get powerful. Once I know who your ideal customer is, what keeps them up at night, and what they dream about, I can write copy that resonates. Ads, emails, landing pages, social posts. All of it gets sharper when I know exactly who we're talking to."

**Reference:** Read the closest matching example from references.

### Steps:

1. Using ALL collected assets and the offers doc, draft an initial persona profile:
   - Name (a first name that represents the archetype)
   - Demographics (age range, role, experience level)
   - One-line description
   - What they want (goals)
   - What frustrates them (pain points)

2. If aspirational business: "This persona is based on [business name]'s audience. Who do YOU want to serve? How is your ideal customer the same or different?"

3. **Summary rule applies.** Show the name, one-liner, and top goals/frustrations. Ask: "Does this sound like your ideal customer? What would you change?"

4. **Pain point selection (multi-select).** Generate 6-10 likely pain points from context. Present using AskUserQuestion with multiSelect so the user checks all that apply.

5. **Build pain/pleasure quote tables.** For each selected pain point, write a pain quote (struggling, first person) and pleasure quote (solved, first person). Before building, explain: "For each pain point, I'll write quotes in your customer's voice. I'll pull from these every time I write an ad, email, or sales page."

6. **Show 2-3 sample quotes for feedback.** "Does this sound like your customer?" If approved, write the full doc.

7. Write the final `core/persona.md`.

## Phase 4: Capturing Your Voice

Show: `Step 4 of 7: Capturing Your Voice`

**Sell the step:** "Here's where I learn to sound like you. Once I have your voice dialed in, everything I write will sound like it came from you, not from a robot. Emails, posts, ads. Your customers won't be able to tell the difference."

### Steps:

1. Ask using AskUserQuestion: "Do you have a piece of writing that sounds like YOU at your best? A social media post, an email, a bio, a blog post. Paste it in or upload it."

2. **If the user provides a sample:** Analyze for sentence length patterns, vocabulary preferences, rhetorical habits, tone markers, and things they avoid.

3. Also ask using AskUserQuestion:
   - "What tone do you want to AVOID? (e.g., corporate speak, overly casual, salesy)"
   - "In 3-5 words, how would you describe your writing style?"

4. Draft `core/brand-voice.md` with sections for: voice summary, vocabulary preferences, sentence patterns, things to avoid, and a before/after example showing generic copy vs. the user's voice.

5. **If no writing sample:** "No worries. I'll build a voice guide from everything else I've collected. You can always refine it later by showing me something you've written." Generate a best-guess voice doc from website copy, social posts, or any text assets collected during intake.

6. **Summary rule applies.** Show the voice summary and one before/after example. "Does this sound like you?"

7. Write the final `core/brand-voice.md`.

## Phase 5: Building Your Daily Gameplan

Show: `Step 5 of 7: Building Your Daily Gameplan`

**Sell the step:** "This might be my favorite part. Instead of starting your day wondering what to work on, I'll greet you every morning with a briefing: what's on your calendar, what tasks are open, and what I'd suggest you tackle today. Like having a chief of staff who's already read through everything."

**Reference:** Read `references/example-morning-routine.md` for the format.

### Steps:

1. Use AskUserQuestion to learn preferences:
   - "What does a productive morning look like for you? What information do you need first thing?" (options: Calendar overview, Weather, Task list, Industry news, Custom)
   - "What city are you in? (for weather)"

2. Build the morning routine with applicable sections: Greeting (always), Day/date (always), Weather (if requested), Calendar (if connected), Tasks (if they have a system), Industry news (if requested), and Suggested Tasks (ALWAYS include: 3 specific daily suggestions based on workspace state, persona, and active workflows).

3. Write as instructions FOR Claude, not documentation for the user.

4. Write to `routines/morning-routine.md`.

5. Create the slash command at `.claude/commands/morning-routine.md`:

   ```markdown
   ---
   description: Run your morning briefing routine
   allowed-tools: Read, WebSearch, WebFetch, Bash
   ---

   Read and execute the morning routine at routines/morning-routine.md.
   ```

6. Tell the user: "Say 'good morning' or type /morning-routine and Growth OS will run your daily briefing."

### Scheduling Prompt

7. Ask: "Want me to schedule this to run automatically every morning?"

8. If yes, use AskUserQuestion for time (7:00/7:30/8:00/8:30/9:00 AM) and days (Weekdays/Every day).

9. Use `create_scheduled_task` with taskId "morning-routine", prompt "Read and execute the morning routine at routines/morning-routine.md", description "Daily morning briefing", and cron based on answers (e.g., `0 8 * * 1-5`).

10. Confirm: "Done. Your morning routine will run at [time] [days]. You can also say 'good morning' or type /morning-routine anytime."

## Phase 6: Wiring It All Together

Show: `Step 6 of 7: Wiring It All Together`

**Sell the step:** "Now I'm going to wire everything together. I'm creating the file I read at the start of every session so I always know your business, your customers, your voice, and your daily rhythm. After this, every time you open a new conversation, I'll already know everything we've built."

### Steps:

1. Generate `CLAUDE.md` at the workspace root using the template in `references/claude-md-template.md`. Fill all Tier 1 sections with actual data. Mark Tier 2 sections as "Not yet configured" with a note on how to add them.

2. Generate `memory/glossary.md` with a quick-decoder section mapping business terms, product names, and shorthand to plain definitions.

3. Present the congratulations message:

   ```
   Your Growth OS workspace is live.

   Here's what you've built:
   - Offers document with your [N] products/services
   - Persona with [N] pain/pleasure quote pairs
   - Brand voice guide so I always sound like you
   - Morning routine (scheduled for [time] [days])
   - CLAUDE.md that ties it all together

   From now on, every time you start a conversation, I'll already know
   your business, your audience, and your voice. You're not starting
   from scratch anymore.

   One more step: Growth OS has been analyzing everything you shared, and it has ideas for how to grow your business.

   (Later, you can say "enhance my workspace" to add business info,
   brand design, and content rules.)
   ```

4. Proceed directly to Phase 7. Do not ask if they want to continue. This is the natural capstone.

## Phase 7: Growth OS Has Ideas to Grow Your Business

Show: `Step 7 of 7: Growth OS Has Ideas to Grow Your Business`

**Sell the step:** "Now here's the payoff. I've spent the last six steps learning your business, your customer, and your voice. Growth OS didn't just absorb that information. It used it to generate ideas for how to grow your business. Want to see what I came up with?"

### Step 1: The Pitch

Present this framing. Keep it tight. Do not lecture. The goal is to orient, not teach a framework.

> "Every business grows by doing four things well: getting noticed, capturing interest, making the sale, and keeping customers coming back. I've organized my ideas around those four objectives:
>
> - **Awareness** -- Getting your business in front of the right people
> - **Leads** -- Turning strangers into subscribers, followers, and prospects
> - **Sales** -- Converting interested people into paying customers
> - **Retention** -- Keeping customers happy, buying more, and telling others
>
> I've got ideas tailored to your business. Want to see them?"

Use AskUserQuestion: "Want to see the growth ideas I came up with for [business name]?"
Options: "Yes, show me" / "Not right now"

If "Not right now": run the growth-ideas skill silently to generate and save the ideas anyway, then say: "No problem. I saved them to your workspace. Say 'growth ideas' or '/growth-ideas' anytime to see them." Mark Phase 7 complete and skip to the task tracking prompt (Step 5).

### Step 2: Generate Growth Ideas

**Delegate to the growth-ideas skill.** The standalone `growth-ideas` skill (in `skills/growth-ideas/SKILL.md`) contains the complete generation engine: the Customer Journey framework, specificity test, formatting rules, and save logic.

Run the growth-ideas skill now. It will:
1. Read all context files (offers, persona, brand voice, channels)
2. Use the Customer Journey framework (10 stages mapped to 4 objectives) to generate 12-20 specific ideas
3. Save them to `growth-ideas.md` at the workspace root
4. Present the numbered list in chat
5. Recommend 2-3 ideas to tackle first

### Step 3: User Picks Favorites

After the growth-ideas skill presents its output and recommendations:

> "Which of these ideas do you want to work on? Give me the numbers. Pick as many or as few as you want. The ones you don't pick aren't going anywhere. They'll stay in your growth ideas file for later."

Wait for the user to respond with numbers. Accept any format: "1, 3, 7, 12" or "1 and 3 and 7" or "the first three and number 12." Parse flexibly.

### Step 4: Build the First Workflow

Look at the selected ideas. Identify which one (or which cluster) would benefit most from a repeatable workflow: a weekly email, a content pipeline, a social posting rhythm, a campaign sequence.

If a clear workflow candidate exists among the selected ideas:

> "Idea [N] is something you'll want to do regularly, not just once. Want me to build it as a workflow you can trigger with a phrase? For example, you'd say '[trigger phrase]' and I'd handle the rest."

If the user says yes, build the workflow:

```
workflows/[name]/
├── WORKFLOW.md        # Description, numbered steps, inputs, outputs
├── skills/
│   └── [name]/
│       └── SKILL.md   # YAML frontmatter (name, description, version), imperative instructions
└── outputs/
```

The SKILL.md needs valid YAML frontmatter with name, description (including trigger phrases), and version. Write imperative instructions with clear inputs/outputs. Update CLAUDE.md to reference the new workflow and skill.

After building: "Your first Growth OS workflow is live. Say '[trigger phrase]' to fire it up."

If no clear workflow candidate exists, or the user declines: skip. Not every business needs a workflow on day one.

### Step 5: Task Tracking Setup

This is where the user shapes their own system instead of getting one imposed.

> "You've picked [N] ideas to work on. Want me to start keeping track of these for you? I can set up a task list so nothing falls through the cracks."

Use AskUserQuestion:
- Question: "How do you want to track your ideas and to-dos?"
- Options:
  - "Simple checklist (Recommended)" -- a clean markdown file organized by status
  - "Organized by marketing objective" -- grouped by Awareness / Leads / Sales / Retention
  - "I already use a tool for this" -- ask what tool, see if Claude can integrate
  - Other

**If "Simple checklist":** Create TASKS.md with sections: This Week, Up Next, Someday, Done. Populate "This Week" with the user's top 1-3 picks, "Up Next" with the rest, "Done" with setup milestones.

**If "Organized by marketing objective":** Create TASKS.md with sections: Awareness, Leads, Sales, Retention, Done. Populate each section with the relevant selected ideas.

**If "I already use a tool":** Ask what they use (Notion, Asana, Trello, etc.). If Claude has a connector, offer to set up sync. If not, create TASKS.md as a local backup and let them know they can copy items over.

**If "Other":** Ask what they have in mind. Adapt.

**For all options:** Each task in the file gets:
- A checkbox
- The bold idea title
- A 1-sentence description
- A blockquote prompt the user can copy/paste to execute it with Claude

Example:
```markdown
- [ ] **"What to Write in a Sympathy Card" blog post** -- Targets Sarah's #1 pain point and her most common Google search.
  > `Write a blog post titled "What to Write in a Sympathy Card (When You Don't Know What to Say)." Use the One Memory framework. Reference the Comfort Words Card Kit and Sympathy Message Prompts Pack. Target Sarah. Use my brand voice.`
```

### Step 6: Create the /tasks Command

Copy `references/tasks-command-template.md` to `.claude/commands/tasks.md` in the user's workspace. This gives them quick-add and status check from day one.

### Step 7: Present and Close

> "Your Growth OS workspace is ready to work. Here's what you've got:
> - [N] growth ideas saved to your workspace (say 'show me the growth ideas' to revisit)
> - [N] tasks ready to work on (say '/tasks' to check your list)
> - [Workflow name, if built] (say '[trigger phrase]' to run it)
>
> Pick any task and let's go. Or say 'good morning' tomorrow and Growth OS will have your briefing ready."

Update progress.md to mark Phase 7 complete.

## Tier 2: Optional Enhancements

When the user says "enhance my workspace", run the relevant enhancement. Each is independent; any order.

### Enhancement: Business Info

1. Draft `core/business-info.md` using all collected assets.
2. Present a summary and ask for gaps (mission, team, tech stack, channels).
3. Write final file.
4. Update progress.md and regenerate CLAUDE.md sections.

### Enhancement: Brand Design

1. Pull from website and assets: colors, fonts, logo, aesthetic.
2. Draft `core/brand-design.md` with: color palette (hex codes), typography, layout preferences, usage rules.
3. Update progress.md and CLAUDE.md.

### Enhancement: Content Rules

1. Ask: "Are there any writing rules you always follow? Words to avoid, formatting requirements, style preferences?"
2. Draft `core/content-rules.md` with global rules.
3. Update progress.md and CLAUDE.md.

## Session Continuity

This skill MUST support multi-session completion. On any new session:

1. Read progress.md to determine current state
2. Resume from the first incomplete step
3. Do not re-ask questions for completed steps
4. If the user says "continue setup" or "where was I", read progress.md and pick up

**After completing each step:** Update progress.md immediately. Check the step's checkbox, add any new entries to the Asset Inventory or Marketing Channels tables, and log the session.

## Writing Guidelines

- **Summaries, not full docs.** Show a tight summary when presenting drafts. Ask "Does this look right?" Do not dump full documents into the chat. (Phases 2-4 reference this as "Summary rule applies.")
- **Revision loop.** If the user approves, save and move on. If they request changes, revise and re-present. Revision rounds follow the setup mode (speed: 1, precision: 3, default: 2). Then save and note remaining adjustments in progress.md.
- **AskUserQuestion for everything.** Never dump a wall of questions as plain text. Keep to 1-2 questions per interaction.
- **Business-aware suggestions.** Tailor asset suggestions, social prompts, and workflow ideas to the specific business. No generic checklists.
- **Track marketing channels.** When the user mentions or uploads any marketing material, record the channel/tactic in progress.md.
- **Website crawl as draft.** Present as "Here's what I found. Does this look right?" Never assume the crawl is authoritative.
- **Aspirational framing.** When source_context is aspirational_business, frame outputs as starting points: "Based on [business], here's a starting point. What would you change?"
- **Documents are for Claude.** Write clean, structured references, not marketing copy.
- **No em dashes.** Use periods, commas, colons, or break into two sentences.
- **Examples, not blanks.** Refer to the reference examples. Never show empty templates.

## References

All example files are in `references/`:

**Content examples:** `example-offers-service.md`, `example-offers-product.md`, `example-persona-service.md`, `example-persona-product.md`, `example-morning-routine.md`, `example-brand-voice.md`, `example-brand-design.md` (Tier 2), `example-business-info.md` (Tier 2).

**Templates:** `progress-template.md`, `claude-md-template.md`, `tasks-template.md`, `tasks-command-template.md`.

**Frameworks:** `customer-journey-framework.md` (internal reference for Phase 7 idea generation).
