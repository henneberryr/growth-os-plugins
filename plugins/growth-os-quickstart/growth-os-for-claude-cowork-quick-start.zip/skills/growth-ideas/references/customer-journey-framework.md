# Customer Journey Framework
## Internal Reference for Idea Generation

> This file is read by Claude during Phase 7 idea generation. It is NOT shown to the user.
> It provides the thinking structure for generating business-specific growth ideas.

---

## The Four Marketing Objectives

Every marketing activity serves one of four objectives. Use these as the organizing categories for user-facing output.

| Objective | Business Goal | What Success Looks Like |
|-----------|--------------|------------------------|
| **Awareness** | Get discovered by the right people | More of the right people know you exist and understand what you do |
| **Leads** | Turn strangers into subscribers and prospects | Growing email list, social following, consultation bookings, trial signups |
| **Sales** | Convert prospects into paying customers | Revenue from first-time purchases |
| **Retention** | Keep customers buying, ascending, and promoting | Repeat purchases, upsells, referrals, reviews, advocacy |

---

## The 10 Customer Journey Stages

Each stage maps to one objective. Use ALL 10 stages as a checklist when generating ideas to ensure full-funnel coverage. The user sees the 4 objectives; you use the 10 stages internally.

### AWARENESS (Stages 1-4)

**Stage 1: Problem Aware**
The customer recognizes they have a problem or need.

- Idea types: Educational content that names the problem. Blog posts, videos, social content that spark "that's me" recognition.
- Key question: What does [persona] Google at 2am when they can't sleep? What question do they type into a search bar?
- Channel fit: SEO/blog, YouTube, social media, podcast appearances.

**Stage 2: Solution Aware**
The customer starts discovering possible solutions (not specific brands yet).

- Idea types: How-to guides, comparison content, "X ways to solve [problem]" posts, webinars explaining options.
- Key question: What solutions is [persona] evaluating? What's the consideration set?
- Channel fit: Blog, YouTube, webinars, email nurture.

**Stage 3: Brand Aware**
The customer learns that YOUR business exists and offers a solution.

- Idea types: Brand introduction content, thought leadership, display/social ads, PR, partnerships, guest appearances.
- Key question: Where does [persona] hang out, and how do we show up there?
- Channel fit: Social media ads, influencer/partnership, PR, guest posting, podcast guesting.

**Stage 4: Position Aware**
The customer understands how your brand differs from alternatives and why you might be the best fit.

- Idea types: Comparison pages, "why us" content, case studies, USP-driven landing pages, testimonial campaigns.
- Key question: What makes this business the obvious choice for [persona]? What's the differentiator?
- Channel fit: Website, landing pages, email, retargeting ads.

### LEADS (Stages 5-6)

**Stage 5: Subscribe**
The prospect opts in to ongoing communication (email, SMS, social follow, community join).

- Idea types: Lead magnets (PDFs, checklists, templates, quizzes), newsletter signup, free community, content upgrades.
- Key question: What would [persona] trade their email address for? What's irresistible enough to opt in?
- Channel fit: Website popups, landing pages, social CTAs, content upgrades on blog posts.

**Stage 6: Try**
The prospect samples the product/service at low or no cost to reduce risk.

- Idea types: Free trials, demos, consultations, tripwire offers, sample packs, mini-courses, challenges.
- Key question: What's the lowest-risk way [persona] can experience the value before committing?
- Channel fit: Email sequences, retargeting, website, sales calls.

### SALES (Stage 7)

**Stage 7: Buy**
The customer purchases the core offer. Trust has been built through prior stages.

- Idea types: Sales pages, launch campaigns, limited-time offers, objection-handling content, testimonial-driven emails, cart recovery.
- Key question: What's stopping [persona] from buying right now? What objection needs to be resolved?
- Channel fit: Email, sales pages, retargeting ads, phone/chat sales.

### RETENTION (Stages 8-10)

**Stage 8: Succeed**
The customer achieves the promised outcome from their purchase.

- Idea types: Onboarding sequences, how-to content, success check-ins, community support, implementation guides.
- Key question: What does [persona] need to DO after buying to get the result they were promised?
- Channel fit: Email onboarding, in-app messages, community, support content.

**Stage 9: Ascend**
The customer purchases additional products, upgrades, or buys more frequently.

- Idea types: Cross-sell campaigns, upsell sequences, loyalty programs, bundles, annual plan conversions, VIP tiers.
- Key question: What else does [persona] need now that they've solved the first problem? What's the natural next purchase?
- Channel fit: Post-purchase email, in-product prompts, account management.

**Stage 10: Promote**
The customer becomes an advocate who refers others to the business.

- Idea types: Referral programs, review/testimonial requests, affiliate programs, user-generated content campaigns, case studies.
- Key question: What would make [persona] excited to tell a friend about this business?
- Channel fit: Post-purchase email, loyalty program, social media, review platforms.

---

## Idea Generation Protocol

When generating ideas for a specific business, follow this process:

### 1. Read the Context Files
- `core/offers.md` -- what they sell, pricing, positioning
- `core/persona.md` -- who they sell to, pain points, desires
- `core/brand-voice.md` -- how they communicate
- Marketing Channels table from progress.md -- where they're active

### 2. Walk Through All 10 Stages
For each stage, ask:
- Does this business have ANYTHING addressing this stage right now?
- If yes: can it be improved, expanded, or repurposed?
- If no: what's the highest-impact thing they could create for this stage?
- Is there a specific pain point from the persona that maps to this stage?
- Is there a specific product/offer that fits this stage?

### 3. Apply the Specificity Test
Every idea must reference at least one of:
- A specific product, service, or offer name from offers.md
- A specific pain point or quote from persona.md
- A specific marketing channel the business uses
- A specific seasonal moment, audience behavior, or market gap from intake

If an idea doesn't pass this test, rewrite it until it does or discard it.

### 4. Balance the Mix
- At least half the ideas should be executable this week with Claude's help
- Include a mix of content creation, campaign design, and infrastructure (sequences, pages, systems)
- Don't over-index on one channel. Spread across the channels the business actually uses.
- Include at least one idea per objective. Aim for 3-5 per objective.

### 5. Prioritize by Impact
Within each objective, lead with the highest-impact idea. Impact = (size of the gap) x (ease of execution) x (relevance to persona's most acute pain point).

---

## Business Model Patterns

Use these as pattern-matching guides, not templates. Adapt to the specific business.

### Service Business
- Awareness: thought leadership, educational content, local SEO, speaking/podcasting
- Leads: free consultation, assessment tool, email course, case study downloads
- Sales: proposal templates, objection-handling sequences, testimonial campaigns
- Retention: check-in cadence, upsell to retainer, referral incentives, quarterly reviews

### E-Commerce / Product Business
- Awareness: SEO product roundups, social media visual content, influencer partnerships
- Leads: discount-for-email, quiz/gift finder, seasonal guides, SMS signup
- Sales: cart abandonment sequences, product comparison pages, limited-time bundles
- Retention: post-purchase follow-up, replenishment reminders, loyalty program, review requests, seasonal re-engagement

### Software / SaaS Business
- Awareness: comparison content, integration directories, developer content, industry reports
- Leads: free trial, freemium tier, interactive demo, ROI calculator
- Sales: case studies, onboarding-focused sales calls, annual plan incentives
- Retention: feature adoption campaigns, success check-ins, expansion revenue plays, community

### Info Product / Course Business
- Awareness: free workshops, YouTube/podcast content, guest teaching, social proof campaigns
- Leads: free mini-course, challenge/bootcamp, cheat sheet, community access
- Sales: launch sequences, webinar funnels, payment plans, bonuses, urgency/scarcity
- Retention: alumni community, certification, advanced courses, coaching upsell, affiliate program
