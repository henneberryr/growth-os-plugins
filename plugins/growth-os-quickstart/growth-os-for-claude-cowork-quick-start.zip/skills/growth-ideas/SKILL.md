---
name: growth-ideas
description: >
  Generates business-specific growth ideas organized by four marketing objectives
  (Awareness, Leads, Sales, Retention) using the Customer Journey framework.
  Considers existing business context, persona, offers, and recent work.
  Trigger: "growth ideas", "give me growth ideas", "brainstorm growth ideas",
  "what should I work on", "more growth ideas", "new ideas for the business",
  "refresh growth ideas", "start fresh with ideas", "growth idea brainstorm"
version: 1.0.0
---

# Growth Ideas Skill

Generate business-specific marketing and growth ideas using the Customer Journey framework. Ideas are grounded in the user's actual business context, persona, offers, and recent activity.

---

## When This Skill Triggers

This skill fires when the user asks for growth ideas in any form:

- "Give me growth ideas"
- "Brainstorm growth ideas"
- "What should I work on?"
- "More growth ideas"
- "I need ideas for growing the business"
- "Refresh my growth ideas"
- "Start fresh with ideas"
- `/growth-ideas` slash command

---

## Step 1: Read the Context

Before generating anything, read these files. Every idea must be grounded in real business context. No generic filler.

**Required reads (skip any that don't exist):**

| File | What You're Looking For |
|------|------------------------|
| `core/offers.md` | Products, services, pricing, positioning |
| `core/persona.md` | Ideal customer, pain points, desires, language |
| `core/brand-voice.md` | How the business communicates |
| `growth-ideas.md` | Existing ideas (if any). Avoid duplicates. |
| `TASKS.md` | What's currently in progress or recently completed |
| `progress.md` | Marketing channels, setup state |

**Also read:** `references/customer-journey-framework.md` for the generation engine.

**If core files don't exist:** The user hasn't completed the Quick Start setup. Say: "I need some business context before I can generate ideas. Want to run the Quick Start first? Just say 'quick start' to get set up." Stop here.

---

## Step 2: Determine the Mode

Check whether `growth-ideas.md` already exists at the workspace root.

### If growth-ideas.md exists (Append Mode -- default):

1. Read the existing file to understand what ideas are already there.
2. Generate NEW ideas that don't duplicate existing ones.
3. Aim for 8-12 new ideas. Focus on gaps: stages of the customer journey that are underrepresented, channels that are underutilized, or recent business changes that open new opportunities.
4. Append the new ideas to the existing file under a dated section header:

   ```markdown
   ---

   ## New Ideas — [Today's Date]

   Generated based on recent activity and updated business context.

   ### Awareness
   [new ideas...]

   ### Leads
   [new ideas...]
   ```

5. Present the new ideas in chat (not the full file, just the new batch).

### If the user says "start fresh" or "refresh growth ideas":

1. Generate a complete new set (12-20 ideas) using the full protocol.
2. Replace the entire `growth-ideas.md` file.
3. Present the complete new list in chat.

### If growth-ideas.md does NOT exist (First Run):

1. Generate a complete set (12-20 ideas) using the full protocol.
2. Create `growth-ideas.md` at the workspace root.
3. Present the complete list in chat.

---

## Step 3: Generate the Ideas

**Use the Customer Journey framework** as the generation engine. Walk through all 10 customer journey stages internally, but organize the output by the 4 marketing objectives.

### Generation Rules

1. **Generate 12-20 ideas** for a full set, 8-12 for an append. Aim for 3-5 per objective. Fewer is fine if the business doesn't have enough context for a given area. Never pad with generic filler.

2. **Every idea MUST pass the specificity test.** It must reference at least one of:
   - A specific product, service, or offer from `core/offers.md`
   - A specific pain point or desire from `core/persona.md`
   - A specific marketing channel the business actually uses
   - A specific seasonal moment, competitor gap, or audience behavior

   "Create social media content" fails the test. "Write a 'What to Write in a Sympathy Card' blog post targeting Sarah's top pain point" passes.

3. **Each idea gets:**
   - A number (sequential, 1 through N)
   - A bold title (action-oriented, 8 words or fewer)
   - 1-2 sentences explaining what it is and why it matters for THIS business
   - The customer journey stage it maps to (in parentheses: e.g., "Problem Aware", "Subscribe", "Ascend")

4. **Organize by the 4 objectives:**

   ```
   ## Awareness
   Getting [persona name] to discover [business name].

   ## Leads
   Turning visitors into subscribers and prospects.

   ## Sales
   Converting interested [persona name]s into paying customers.

   ## Retention
   Keeping customers happy, buying more, and referring others.
   ```

5. **Mix of quick wins and bigger plays.** At least half should be things the user could start today or this week with Claude's help. The rest can be larger projects.

6. **Channel-aware.** If the business uses Instagram and email but not LinkedIn, don't suggest LinkedIn ideas unless there's a strong strategic reason (and flag it as a new channel opportunity).

7. **Persona-aware.** Reference their specific customer by name. Not "your audience" but "[persona name]."

8. **Context-aware.** Factor in what's already in progress from TASKS.md and what's been recently completed. Don't suggest things they're already doing unless you're suggesting an improvement or expansion.

---

## Step 4: Save the Document

**File:** `growth-ideas.md` at the workspace root.

**Title:** `# Growth OS: Ideas to Grow [Business Name]`

**For first run or refresh:** Write the complete file with all ideas organized by objective.

**For append:** Add the new dated section to the existing file.

---

## Step 5: Present and Recommend

### Present the ideas in chat

Show the full numbered list (new ideas only if appending). Do NOT use AskUserQuestion for the list. It needs to be readable and scrollable.

Format:

```
Growth OS generated [N] [new ]ideas for growing [business name]:

## Awareness
Getting [persona] to discover [business name].

1. **"What to Write in a Sympathy Card" blog post** -- Targets Sarah's #1 pain point
   and her most common Google search. This is your highest-value SEO play. (Problem Aware)

2. **"Grief Doesn't Have a Timeline" editorial piece** -- Builds trust and brand authority.
   Sarah needs to hear this before she's ready to buy. (Solution Aware)

...
```

### Recommend next actions

After the list, recommend 2-3 ideas to tackle first. Base recommendations on:

- **What's already in progress:** Ideas that complement current work get priority.
- **Quick wins:** Ideas the user could execute today or this week with Claude's help.
- **Funnel gaps:** If Awareness is strong but Leads are weak, prioritize Lead ideas.
- **Recency:** If they just finished a project, what's the natural next step?

Format the recommendation as:

```
**Where I'd start:**

If I were picking three to tackle this week, I'd go with:

- **#[N] [Title]** -- [One sentence explaining why this one first. Connect it to
  something specific: a gap, a recent win, a quick execution time.]
- **#[N] [Title]** -- [Same.]
- **#[N] [Title]** -- [Same.]

Want to work on any of these? Give me a number and we'll get started.
```

---

## Step 6: What Happens Next

If the user picks an idea by number:

1. Check if the idea would benefit from a repeatable workflow (a weekly cadence, a content pipeline, a campaign sequence).
2. If yes, offer to build it as a workflow: "This is something you'll want to do regularly. Want me to build it as a workflow you can trigger with a phrase?"
3. If no, just start executing: draft the content, create the campaign plan, build the asset, whatever the idea calls for.
4. After completing the work, offer to add follow-up tasks to TASKS.md.

If the user doesn't pick anything right now: "No rush. Your ideas are saved in growth-ideas.md. Say 'show me the growth ideas' or '/growth-ideas' whenever you're ready to pick one."

---

## Rules

- **No fabrication.** Every idea must be grounded in the context files. If the files don't support a claim, don't make it.
- **No duplicate ideas.** When appending, read the existing file and skip anything that's essentially the same idea restated.
- **No em dashes.** Use periods, commas, colons, or break into two sentences.
- **Persona first.** Read `core/persona.md` before generating. Every idea should feel like it was written for this specific customer.
- **Respect the brand voice.** Ideas should sound like something the business would actually do, not generic marketing advice.
