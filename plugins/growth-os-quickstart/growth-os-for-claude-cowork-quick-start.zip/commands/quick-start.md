---
description: Run or continue the Growth OS Quick Start setup
allowed-tools: Read, Write, Edit, Bash, WebFetch, WebSearch, AskUserQuestion, TodoWrite
argument-hint: [resume]
---

Read and execute the Quick Start skill at `${CLAUDE_PLUGIN_ROOT}/skills/quick-start/SKILL.md`.

If the user passes "resume" as an argument, or if a `progress.md` file exists in the workspace root, pick up from the first incomplete step. Do not restart steps already marked complete.

If no `progress.md` exists, start fresh from Phase 1.
