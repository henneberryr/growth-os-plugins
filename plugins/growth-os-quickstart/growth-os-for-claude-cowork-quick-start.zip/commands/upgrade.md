---
description: Upgrade your Growth OS workspace to the latest plugin version
allowed-tools: Read, Write, Edit, Bash, AskUserQuestion, TodoWrite
---

Read the Quick Start skill at `${CLAUDE_PLUGIN_ROOT}/skills/quick-start/SKILL.md`.

Check whether `progress.md` exists in the workspace root:

- If progress.md does NOT exist, tell the user: "It looks like the Quick Start hasn't been run yet. Say 'quick start' or type /quick-start to get started."
- If progress.md exists but the Quick Start is NOT complete, tell the user: "Your Quick Start is still in progress. Say 'continue setup' or type /quick-start to pick up where you left off."
- If progress.md exists AND the Quick Start is complete, check for upgrade opportunities:

**Upgrade detection (check in order):**

1. **v1.0 workspace (no TASKS.md):** Run the "Upgrading from v1.0" section of the Quick Start SKILL.md to add task management.

2. **v1.1 workspace (has TASKS.md but no growth-ideas.md):** Run the "Upgrading from v1.1" section of the Quick Start SKILL.md to add the Growth Ideas feature.

3. **v1.2 workspace (has growth-ideas.md but growth-ideas skill is not standalone):** The growth-ideas skill is now a standalone repeatable capability. Tell the user: "Growth OS has a new feature: the Growth Ideas engine is now a standalone skill you can run anytime. Say 'growth ideas' or type `/growth-ideas` to generate fresh ideas on demand. It reads your current context, avoids duplicating existing ideas, and recommends where to start." Update the CLAUDE.md decoder entries to include the new growth-ideas triggers.

4. **Already up to date:** Tell the user: "Your workspace is already up to date. Nothing to upgrade."
