---
description: Generate business-specific growth ideas using the Customer Journey framework
---

Run the growth-ideas skill. Read the user's business context files (core/offers.md, core/persona.md, core/brand-voice.md, growth-ideas.md, TASKS.md, progress.md) and generate marketing growth ideas organized by four objectives: Awareness, Leads, Sales, Retention.

If growth-ideas.md already exists, generate new ideas that don't duplicate existing ones and append them. If it doesn't exist, generate a full set of 12-20 ideas.

After presenting the ideas, recommend 2-3 to tackle first based on current work, quick wins, and funnel gaps.
