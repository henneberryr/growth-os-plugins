# Growth OS for Claude Cowork -- Quick Start

Guided setup that builds your AI workspace from your existing business assets in one session, plus an ongoing growth ideas engine that generates business-specific marketing ideas on demand.

## What It Does

The Quick Start collects your business assets (website, LinkedIn, documents, screenshots), then walks you through creating your core operational files: offers document, persona with pain/pleasure quotes, brand voice guide, personalized morning routine with scheduled automation, and tailored growth ideas for your business. When it's done, Claude knows your business, your audience, your voice, and your daily rhythm.

The Growth Ideas skill is a standalone capability you can run anytime after setup. It uses the Customer Journey framework to generate fresh, business-specific ideas organized by four marketing objectives (Awareness, Leads, Sales, Retention), recommends where to start, and appends new ideas to your existing list so it grows over time.

## How to Use

1. Install the plugin in Claude Cowork
2. Say "quick start", "set up my workspace", or type `/quick-start`
3. Follow the guided interview. Claude will ask questions, crawl your website, process your uploads, and build each document with your input

The setup takes 30-60 minutes depending on how much context you provide. You can stop at any point and pick up later with "continue setup."

After setup, say "growth ideas" or type `/growth-ideas` anytime to generate new ideas.

## Components

| Component | Type | Description |
|-----------|------|-------------|
| quick-start | Skill | 7-phase guided workspace builder with asset intake, document creation, and workflow setup |
| growth-ideas | Skill | Standalone growth idea generator using the Customer Journey framework. Reads business context, generates ideas, recommends next actions. |
| /quick-start | Command | Starts or resumes the Quick Start process |
| /upgrade | Command | Adds new features to an existing workspace without re-running setup |
| /growth-ideas | Command | Generates new growth ideas on demand |

## Skills Included

### Quick Start

The core skill that powers the entire guided setup. It has 7 steps (Getting to Know Your Business, Mapping What You Sell, Defining Who You Sell To, Capturing Your Voice, Building Your Daily Gameplan, Wiring It All Together, Growth OS Has Ideas to Grow Your Business) plus optional Tier 2 enhancements (Business Info, Brand Design, Content Rules).

**Trigger phrases:** "quick start", "run the quick start", "set up my workspace", "build my workspace", "get started", "continue setup", "good morning" (if Quick Start is incomplete)

### Growth Ideas

A repeatable skill that generates business-specific growth ideas. Uses the Customer Journey framework (10 stages mapped to 4 marketing objectives) to produce actionable ideas grounded in the user's actual offers, persona, channels, and recent work. Appends new ideas to the existing list by default, or generates a fresh set on "start fresh." Recommends 2-3 ideas to tackle first based on current work and funnel gaps.

**Trigger phrases:** "growth ideas", "give me growth ideas", "brainstorm growth ideas", "what should I work on", "more growth ideas", "refresh growth ideas", "start fresh with ideas"

## Requirements

- Claude Cowork desktop app
- A business website or an aspirational business website to model from
- Google Calendar MCP connector (optional, for calendar in morning routine)

## Examples

**Starting fresh:**
> User: "Let's set up my workspace."
> Claude: Asks your name and whether you have an existing business or are building one, then begins collecting assets.

**Resuming a previous session:**
> User: "Continue setup."
> Claude: Reads progress.md, finds where you left off, and picks up from the next incomplete step.

**After completion:**
> User: "Good morning."
> Claude: Runs your personalized morning routine with weather, calendar, tasks, and suggested actions.

**Generating growth ideas:**
> User: "Give me growth ideas."
> Claude: Reads business context, generates 8-12 new ideas organized by marketing objective, and recommends where to start.

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 2.0.0 | March 2026 | New standalone Growth Ideas skill: repeatable idea generation using the Customer Journey framework. Runs on demand via "growth ideas" or `/growth-ideas`. Appends new ideas to existing list by default, or starts fresh. Recommends 2-3 ideas to tackle first based on current work and funnel gaps. Phase 7 of Quick Start now delegates to the standalone skill. New /growth-ideas slash command. |
| 1.2.0 | March 2026 | New Phase 7: "Growth OS Has Ideas to Grow Your Business" replaces "Your First Growth Engine." Uses Customer Journey framework to generate 12-20 business-specific growth ideas organized by marketing objective (Awareness, Leads, Sales, Retention). User picks favorites by number, optionally builds a workflow, and chooses their task tracking format. Adds growth-ideas.md as a permanent workspace artifact. Upgrade paths for both v1.0 and v1.1 workspaces. |
| 1.1.0 | March 2026 | TASKS.md task management system with copy-paste prompts, /tasks slash command, proactive task capture in CLAUDE.md, upgrade detection for v1.0 users. Behavioral preferences (speed/precision, transparent/just-do-it). Multi-source asset intake with brand voice from writing samples. UX overhaul: "Sell the Step" coaching, smart social discovery, context-aware suggestions, Growth Prompts. |
| 1.0.0 | February 2026 | Initial release with website crawl, offers, persona, morning routine, CLAUDE.md |
